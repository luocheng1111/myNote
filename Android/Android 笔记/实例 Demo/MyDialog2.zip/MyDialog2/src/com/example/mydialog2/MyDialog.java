package com.example.mydialog2;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

public class MyDialog {

	public static Dialog createDialog(Context context){
		Dialog dialog = new Dialog(context, R.style.MyDialog);
		View view = LayoutInflater.from(context).inflate(R.layout.dialog_, null);
		view.getBackground().setAlpha(130);
		final int viewWidth = dip2px(context, 220);
		view.setMinimumWidth(viewWidth);
		dialog.setContentView(view);
		return dialog;
	}
	
	
	/**获取屏幕分辨率宽计算dialog的宽度*/
	private static int dip2px(Context context, float dipValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dipValue * scale + 0.5f);
	}
	
	
}
