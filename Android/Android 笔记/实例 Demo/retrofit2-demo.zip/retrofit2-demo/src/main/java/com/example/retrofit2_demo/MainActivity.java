package com.example.retrofit2_demo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.retrofit2_demo.bean.CarBean;
import com.example.retrofit2_demo.bean.PostmanBean;
import com.example.retrofit2_demo.bean.UserBean;
import com.example.retrofit2_demo.bean.WeatherBean;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {

    TextView tv;
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView) findViewById(R.id.tv);
        iv = (ImageView) findViewById(R.id.iv);
    }


    //Get请求
    public void doGet(View v) {
        //1.构建Retrofit
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl("https://free-api.heweather.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        API api = retrofit2.create(API.class);
        //2.创建请求，设置请求参数
        Call<WeatherBean> call = api.getWeather("a93d0176c5394ed1b2020f9b97f42267","上海");

        //3.执行请求
        call.enqueue(new Callback<WeatherBean>() {
            @Override
            public void onResponse(Call<WeatherBean> call, Response<WeatherBean> response) {
                WeatherBean weatherBean = response.body();
                tv.setText(weatherBean.HeWeather6.get(0).basic.location+"");
            }

            @Override
            public void onFailure(Call<WeatherBean> call, Throwable t) {
                Log.d("cylog", "Error" + t.toString());
            }
        });
    }


    //Post请求
    public void doPost(View v) {
        //1.构建Retrofit
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl("https://postman-echo.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        API api = retrofit2.create(API.class);
        //2.创建请求，设置请求参数
        Call<PostmanBean> call = api.postData();

        //3.执行请求
        call.enqueue(new Callback<PostmanBean>() {
            @Override
            public void onResponse(Call<PostmanBean> call, Response<PostmanBean> response) {
                PostmanBean postmanBean = response.body();
                tv.setText(postmanBean.url);
            }

            @Override
            public void onFailure(Call<PostmanBean> call, Throwable t) {
                Log.d("cylog", "Error" + t.toString());
            }
        });

    }


    //Post请求 json数据提交
    public void doPostString(View v) {
        //1.构建Retrofit
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl("http://10.1.1.59:8080/tthparking/webresources/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        API api = retrofit2.create(API.class);
        //2.创建请求，设置请求参数
        Call<List<CarBean>> call = api.postString(new UserBean("15103743308"));

        //3.执行请求
        call.enqueue(new Callback<List<CarBean>>() {
            @Override
            public void onResponse(Call<List<CarBean>> call, Response<List<CarBean>> response) {
                List<CarBean> carList = response.body();
                tv.setText(carList.get(0).parkingName);
            }

            @Override
            public void onFailure(Call<List<CarBean>> call, Throwable t) {
                Log.d("cylog", "Error" + t.toString());
            }
        });
    }



}


