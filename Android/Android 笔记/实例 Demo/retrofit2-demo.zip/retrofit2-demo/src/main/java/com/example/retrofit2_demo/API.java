package com.example.retrofit2_demo;

import android.database.Observable;

import com.example.retrofit2_demo.bean.CarBean;
import com.example.retrofit2_demo.bean.PostmanBean;
import com.example.retrofit2_demo.bean.UserBean;
import com.example.retrofit2_demo.bean.WeatherBean;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

//https://free-api.heweather.com/s6/weather/forecast?location=%E4%B8%8A%E6%B5%B7&key=a93d0176c5394ed1b2020f9b97f42267

public interface API {

    //第一种写法 固定的请求路径
    @GET("/s6/weather/forecast?location=%E4%B8%8A%E6%B5%B7&key=a93d0176c5394ed1b2020f9b97f42267")
    Call<WeatherBean> getWeather();

    //第二种写法 使用@Query 动态设置请求参数 最常见
    @GET("/s6/weather/forecast")
    Call<WeatherBean> getWeather(@Query("key")String key, @Query("location")String location);

    //第三种写法 使用@QueryMap 动态设置请求参数 需要传递key和value
    @GET("/s6/weather/forecast")
    Call<WeatherBean> getWeather(@QueryMap Map<String,String> map);

    //第四种写法 动态请求路径替换
    @GET("/s6/{words}/forecast")
    Call<WeatherBean> getWeather(@Path("words")String words, @Query("key")String key, @Query("location")String location);



    //Post请求  @Body表示发送的请求体 传入实体,它会自行转化成Json
    @POST("/users/new")
    Call<WeatherBean> createUser(@Body WeatherBean user);

    @POST("/post")
    Call<PostmanBean> postData();

    @Headers({
            "Content-Type: application/json",
    })
    @POST("task/requestforanswer")
    Call<List<CarBean>> postString(@Body UserBean user);

    //Post请求  表单形式传递键值对
    //@FormUrlEncoded 表示以表单键值对形式传递
    @FormUrlEncoded
    @POST("/user/edit")
    Call<WeatherBean> updateUser(@Field("first_name") String first, @Field("last_name") String last);

    //@FieldMap注解标记的参数，传递一个Map集合，集合里面有多少个键值对
    @FormUrlEncoded
    @POST("/user/edit")
    Call<WeatherBean> updateUser(@FieldMap Map<String,String> users);

    //单文件上传
    //上传文件需要用到的注解是@Multipart，以及@Part，具体如下所示：
    //@Multipart表示能使用多个Part，而@Part注解则是对参数进行标记，RequestBody是一种类型，通过RequestBody.creat()方法进行创建
    //第一个参数是MediaType，是媒体类型，第二个参数可为String、byte、file等，
    @Multipart
    @POST("register")
    Call<WeatherBean> registerUser(@Part MultipartBody.Part photo, @Part("username") RequestBody username, @Part("password") RequestBody password);

    //多文件上传
    //上传文件需要用到的注解是@Multipart，以及@Part，具体如下所示：
    //@Multipart表示能使用多个Part，而@Part注解则是对参数进行标记，RequestBody是一种类型，通过RequestBody.creat()方法进行创建
    //第一个参数是MediaType，是媒体类型，第二个参数可为String、byte、file等，
    @Multipart
    @POST("/user/photo")
    Call<WeatherBean> upload(@PartMap Map<String, MultipartBody.Part> photos, @Part("description") RequestBody description);

    /**
     * 文件下载
     *
     * @param fileUrl
     * @return
     */
    @Streaming
    @GET
    Call<WeatherBean> downloadPicture(@Url String fileUrl);


    /**
     * 这里需要注意的是如果下载的文件较大，比如在10m以上，那么强烈建议你使用@Streaming进行注解，否则将会出现IO异常.
     *
     * @param fileUrl
     * @return
     */
    @Streaming
    @GET
    Observable<WeatherBean> downloadPicture2(@Url String fileUrl);

    @POST()
    @FormUrlEncoded
    Observable<WeatherBean> executePost(@FieldMap Map<String, Object> maps);



}