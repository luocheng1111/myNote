package com.example.retrofit2_demo.bean;

import java.util.List;

//https://free-api.heweather.com/s6/weather/forecast?location=%E4%B8%8A%E6%B5%B7&key=a93d0176c5394ed1b2020f9b97f42267

public class UserBean {

    public String userCd;


    public UserBean(String userCd) {
        this.userCd = userCd;
    }
}