package com.example.gaode_map;

import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.model.BitmapDescriptorFactory;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.LatLngBounds;
import com.amap.api.maps2d.model.Marker;
import com.amap.api.maps2d.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

public class MakerActivity extends AppCompatActivity implements AMap.OnMapClickListener{

    RadioGroup radioGroup;
    MapView mapView;
    private AMap aMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marker);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        mapView = (MapView) findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);// 此方法必须重写
        initMapConfigure();

        //设置地图点击监听
        aMap.setOnMapClickListener(this);
        aMap.setOnMapLoadedListener(mapLoadedListener);
        aMap.setInfoWindowAdapter(mapInfoWindowAdapter);

        //添加默认的标记点
        Marker chengduMarker = aMap.addMarker(new MarkerOptions()
                .position(new LatLng(30.679879, 104.064855)).title("成都市")
                .snippet("成都市:30.679879, 104.064855").draggable(true));

        Marker xianMarker = aMap.addMarker(new MarkerOptions()
                .position(new LatLng(34.341568, 108.940174)).title("西安")
                .snippet("略略略").draggable(true));
    }


    /**
     * 初始化AMap对象
     */
    private void initMapConfigure() {
        if (aMap == null) {
            aMap = mapView.getMap();
        }
//        aMap.setMyLocationStyle(getLocationStyle(0));//设置标记点的样式
//        aMap.getUiSettings().setMyLocationButtonEnabled(true);// 设置默认定位按钮是否显示
//        aMap.setMyLocationEnabled(true);// 设置为true表示显示定位层并可触发定位，false表示隐藏定位层并不可触发定位，默认是false
//        aMap.setOnMyLocationChangeListener(this);
//        aMap.moveCamera(CameraUpdateFactory.zoomTo(18)); // 设置地图的放大级别
    }


    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn11:
                aMap.clear();
                changeMarkerOption(true);
                break;
            case R.id.btn12:
                changeMarkerOption(false);
                break;
            case R.id.btn21:
                aMap.setInfoWindowAdapter(null);
                break;
            case R.id.btn22:
                aMap.setInfoWindowAdapter(mapInfoWindowAdapter);
                break;
            case R.id.btn23:
                aMap.setInfoWindowAdapter(mapInfoWindowAdapter);
                break;
        }
    }


    private void changeMarkerOption(boolean isDefalutStyle) {
        List<Marker> markerList = aMap.getMapScreenMarkers();
        if(!isDefalutStyle){
            for (Marker marker : markerList){
                marker.setIcon(BitmapDescriptorFactory.fromBitmap(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher)));
            }
        }else {
            for (Marker marker : markerList){
                //因为不知道默认的图标是哪一个,所以这个无法设置会原本的默认图标
//                marker.setIcon(null);
            }
        }
    };



    /**
     * 对单击地图事件回调
     */
    @Override
    public void onMapClick(LatLng point) {
        Log.e("amap", "点击位置， point=" + point);
//        LatLng latLng = new LatLng(point);

        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(point);
        markerOption.title("点击增加的点").snippet("啦啦啦:"+point);
        markerOption.draggable(true);//设置Marker可拖动
        Marker clickMarker = aMap.addMarker(markerOption);
    }


    AMap.InfoWindowAdapter mapInfoWindowAdapter = new AMap.InfoWindowAdapter(){

        @Override
        public View getInfoContents(Marker marker) {
            return null;
        }

        @Override
        public View getInfoWindow(Marker marker) {
            View infoWindow = null;
            if(radioGroup.getCheckedRadioButtonId() == R.id.btn22){
                infoWindow = getLayoutInflater().inflate(
                        R.layout.map_makerinfowindow_custom1, null);
                render(marker, infoWindow);
            }else if (radioGroup.getCheckedRadioButtonId() == R.id.btn23){
                infoWindow = getLayoutInflater().inflate(
                        R.layout.map_makerinfowindow_custom2, null);
            }
            return infoWindow;
        };
    };

    /**
     * 自定义infowinfow窗口
     */
    public void render(Marker marker, View view) {
        String title = marker.getTitle();
        TextView titleUi = ((TextView) view.findViewById(R.id.title));
        if (title != null) {
            SpannableString titleText = new SpannableString(title);
            titleText.setSpan(new ForegroundColorSpan(Color.RED), 0,
                    titleText.length(), 0);
            titleUi.setTextSize(15);
            titleUi.setText(titleText);

        } else {
            titleUi.setText("");
        }
        String snippet = marker.getSnippet();
        TextView snippetUi = ((TextView) view.findViewById(R.id.snippet));
        if (snippet != null) {
            SpannableString snippetText = new SpannableString(snippet);
            snippetText.setSpan(new ForegroundColorSpan(Color.GREEN), 0,
                    snippetText.length(), 0);
            snippetUi.setTextSize(20);
            snippetUi.setText(snippetText);
        } else {
            snippetUi.setText("");
        }
    }

    AMap.OnMapLoadedListener mapLoadedListener = new AMap.OnMapLoadedListener(){
        @Override
        public void onMapLoaded() {
            // 设置所有maker显示在当前可视区域地图中
            LatLngBounds bounds = new LatLngBounds.Builder()
                    .include(new LatLng(30.679879, 104.064855)).include(new LatLng(34.341568, 108.940174)).build();
            aMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 10));
        }
    };

    /**
     * 方法必须重写
     */
    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }


}
