package com.example.gsondemos;

import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.gson.Gson;

public class MainActivity extends Activity {

	String a = "{\"id\": 100,\"body\": \"It is my post\",\"number\": 0.13, \"created_at\": \"2014-05-22 19:12:38\"}";
	String b = "{\"id\": 100,\"body\": \"It is my post\",\"number\": 0.13, \"created_at\": \"2014-05-22 19:12:38\", \"foo2\": {\"id\": 200,\"name\": \"haha\"}}";
	String c = "[{ \"id\": 100,\"body\": \"It is my post1\",\"number\": 0.13, \"created_at\": \"2014-05-20 19:12:38\"},{ \"id\": 101,\"body\": \"It is my post2\", \"number\": 0.14,    \"created_at\": \"2014-05-22 19:12:38\"}]";
	
	TextView t1,t2,t3,t4,t5,t6,t7;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		t1 = (TextView) findViewById(R.id.tv_1);
		t2 = (TextView) findViewById(R.id.tv_2);
		t3 = (TextView) findViewById(R.id.tv_3);
		t4 = (TextView) findViewById(R.id.tv_4);
		t5 = (TextView) findViewById(R.id.tv_5);
		t6 = (TextView) findViewById(R.id.tv_6);
		t7 = (TextView) findViewById(R.id.tv_7);
		
		
		t1.setText("JSON: " + a);
		t3.setText("JSON: " + b);
		t5.setText("JSON: " + c);
		
		Demo demo = new Gson().fromJson(a, Demo.class);
		t2.setText("�������: " + demo.id + ", " + demo.body + ", " + demo.number + ", " + demo.created_at);
		
		Demo2 demo2 = new Gson().fromJson(b, Demo2.class);
		t4.setText("�������: " + demo2.id + "," + demo2.body + ", " + demo2.number + ", " + demo2.created_at + ", " + demo2.foo2.id + ", " + demo2.foo2.name);
		
		Demo[] demo3 = new Gson().fromJson(c, Demo[].class);
		List<Demo> demoList = Arrays.asList(demo3);
		Demo demo33 = demoList.get(1);
		t6.setText("�������: " + demo33.id + ", " + demo33.body + ", " + demo33.number + ", " + demo33.created_at);
		
		t7.setText("�ѵ�һ��Json��ת���Ķ�����Gsonת����Json��ʽ������: " + new Gson().toJson(demo3));
	}


	public class Demo{
		public int id;
		public String body;
		float number;
		String created_at;
	}
	
	public class Demo2{
		public int id;
		public String body;
		float number;
		String created_at;
		Foo3 foo2;
		
		public class Foo3{
			public int id;
			public String name;
		}
	}
	
}
