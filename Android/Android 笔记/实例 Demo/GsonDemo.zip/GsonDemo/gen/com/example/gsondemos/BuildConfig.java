/** Automatically generated file. DO NOT MODIFY */
package com.example.gsondemos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}