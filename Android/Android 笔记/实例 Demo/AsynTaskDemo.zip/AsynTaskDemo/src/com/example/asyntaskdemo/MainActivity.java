package com.example.asyntaskdemo;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends Activity {

	private SeekBar mpb;
	private ImageView miv;
//	private EditText url;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mpb = (SeekBar) findViewById(R.id.sk1);
		miv = (ImageView) findViewById(R.id.iv1);
//		url = (EditText) findViewById(R.id.et1);
		
		
	}
	
	
	public void onClick(View v){
		new MyAsyncTask(mpb, miv).execute("http://www.baidu.com/img/baidu_sylogo1.gif");
	}
	
	
	
	public class MyAsyncTask extends AsyncTask<String, Integer, Bitmap>{

		private SeekBar sb;
		private ImageView iv;
		
		public MyAsyncTask(SeekBar seekBar, ImageView iv){
			this.sb = seekBar;
			this.iv = iv;
		}
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			sb.setMax(100);
		}
		
		@Override
		protected Bitmap doInBackground(String... arg0) {
			publishProgress(0);
			String url = arg0[0];
			HttpClient httpClient = new DefaultHttpClient();
			HttpGet httpGet = new HttpGet(url);
			publishProgress(60);
			Bitmap bmp = null;
			try {
				HttpResponse httpResponse = httpClient.execute(httpGet);
				bmp = BitmapFactory.decodeStream(httpResponse.getEntity().getContent()); 
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			publishProgress(100);
			return bmp;
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
			sb.setProgress(values[0]);
		}
		
		@Override
		protected void onPostExecute(Bitmap result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result == null)
				sb.setProgress(0);
			else
				iv.setImageBitmap(result);
		}
	}



}
