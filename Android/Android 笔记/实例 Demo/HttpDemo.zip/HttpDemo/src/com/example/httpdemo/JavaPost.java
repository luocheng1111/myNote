package com.example.httpdemo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.app.Activity;
import android.os.Bundle;

public class JavaPost extends Activity {

	String HTTPADDRESS = "http://jcdzz.hbncw.cn:8080/SelQuestionList.aspx";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		try {
			//��׼Java�ӿ�POST��ʽ��������
			requestNetWork_JavaPOST();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void requestNetWork_JavaPOST() throws Exception{
		//����URL����
		URL url = new URL(HTTPADDRESS);
		//ʹ��HttpURLConnection������
		
		HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
		urlConn.setRequestMethod("POST");
		//��Ϊ��post������Ҫ����Ϊtrue
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		//post������ʹ�û���
		urlConn.setUseCaches(false);
		urlConn.setInstanceFollowRedirects(true);
		urlConn.connect();
		
		DataOutputStream out = new DataOutputStream(urlConn.getOutputStream());
		String content = "Count="+URLEncoder.encode("3", "UTF-8");
		out.writeBytes(content);
		out.flush();
		out.close();
		
		//�õ�����
		InputStream inputStream = urlConn.getInputStream();
		//��������
		InputStreamReader is = new InputStreamReader(inputStream);
		BufferedReader buffer = new BufferedReader(is);
		String resultData = "";
		String inputLine = null;
		while((inputLine = buffer.readLine()) != null){
			resultData += inputLine + "\n";
		}
		is.close();
		urlConn.disconnect();
		
		System.out.println("POST��ʽ���:"+resultData);
	}
}
