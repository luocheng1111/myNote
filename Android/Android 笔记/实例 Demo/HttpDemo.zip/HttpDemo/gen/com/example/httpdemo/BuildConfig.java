/** Automatically generated file. DO NOT MODIFY */
package com.example.httpdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}