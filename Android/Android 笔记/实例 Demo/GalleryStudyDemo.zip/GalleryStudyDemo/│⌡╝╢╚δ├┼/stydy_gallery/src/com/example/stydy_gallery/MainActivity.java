package com.example.stydy_gallery;  
  
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.Gallery.LayoutParams;
import android.widget.ImageView;
import android.widget.Toast;
  
public class MainActivity extends Activity {
	
    private Gallery gallery;  
    
    private int[] resIds = {R.drawable.a1, R.drawable.a2, R.drawable.a3,
    		R.drawable.a4, R.drawable.a5, R.drawable.a6,};
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.activity_main);  
          
        gallery = (Gallery) this.findViewById(R.id.gallery);
        ImageAdapter imageAdapter = new ImageAdapter(this);
        gallery.setAdapter(imageAdapter);
    }  
   
    public class ImageAdapter extends BaseAdapter{

    	private Context context;
    	
    	public ImageAdapter(Context context){
    		this.context = context;
    	}
    	
		@Override
		public int getCount() {
			return resIds.length;
		}

		@Override
		public Object getItem(int position) {
			return resIds[position];
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View arg1, ViewGroup arg2) {
			ImageView imageView = new ImageView(context);
			imageView.setImageResource(resIds[position]);
//			imageView.setAdjustViewBounds(true); 
//			imageView.setLayoutParams(new Gallery.LayoutParams(  
//		            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));  
//			imageView.setScaleType(ImageView.ScaleType.FIT_XY);
//			imageView.setLayoutParams(new Gallery.LayoutParams(120, 120));
//			imageView.setBackgroundResource(mGalleryItemBackground);
			return imageView;
		}
    	
    }
}  