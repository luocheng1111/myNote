/** Automatically generated file. DO NOT MODIFY */
package com.example.stydy_gallery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}