package com.example.stydy_viewpager;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;

public class MainActivity extends Activity {

	private ViewPager viewPager;
	private List<View> viewList; //װ�ػ����Ĳ���
	private List<String> titleList; //������ÿһҳ�ı���
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		viewPager = (ViewPager) this.findViewById(R.id.viewpager);
		
		LayoutInflater layoutInflater = LayoutInflater.from(this);
		View view1 = layoutInflater.inflate(R.layout.tab1, null);
		View view2 = layoutInflater.inflate(R.layout.tab2, null);
		View view3 = layoutInflater.inflate(R.layout.tab3, null);
		
		viewList = new ArrayList<View>();
		viewList.add(view1);
		viewList.add(view2);
		viewList.add(view3);
		
		titleList = new ArrayList<String>();
		titleList.add("title1");
		titleList.add("title2");
		titleList.add("title3");
		
		MyPagerAdapter adapter = new MyPagerAdapter(this, viewList, titleList);
		viewPager.setAdapter(adapter);
		viewPager.setOnPageChangeListener(new PageChangeListener());
	}
	
	class PageChangeListener implements OnPageChangeListener{

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub
			System.out.println("1");
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub
			System.out.println("2");
			
		}

		@Override
		public void onPageSelected(int arg0) {
			// TODO Auto-generated method stub
			System.out.println("333333333333333333");
		}
		
	}



}
