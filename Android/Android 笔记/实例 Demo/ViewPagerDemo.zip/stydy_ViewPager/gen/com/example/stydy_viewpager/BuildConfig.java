/** Automatically generated file. DO NOT MODIFY */
package com.example.stydy_viewpager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}