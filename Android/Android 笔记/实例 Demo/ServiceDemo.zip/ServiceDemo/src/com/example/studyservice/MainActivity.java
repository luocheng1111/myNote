package com.example.studyservice;

import com.example.studyservice.MyService2.MyBinder;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;

public class MainActivity extends Activity {

	boolean flag = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void start(View v){
		Intent i = new Intent(this, MyService1.class);
		startService(i);
	}
	
	public void stop(View v){
		Intent i = new Intent(this, MyService1.class);
		stopService(i);
	}
	
	public void bind(View v){
		Intent i = new Intent(this, MyService2.class);
		bindService(i, conn, Context.BIND_AUTO_CREATE);
	}
	
	public void unbind(View v){
		if(flag){ 
			unbindService(conn);
			flag = false;
		}
	}
	
	private ServiceConnection conn = new ServiceConnection() {
		
		@Override
		public void onServiceConnected(ComponentName name, IBinder iBinder) {
			System.out.println("onServiceConnected()");
			MyBinder binder = (MyBinder) iBinder;
			MyService2 bindService = binder.getService();
			bindService.MyMethod();
			flag = true;
		}
		
		@Override
		public void onServiceDisconnected(ComponentName arg0) {
			System.out.println("onServiceDisconnected()");
		}
		
		
	};

}
