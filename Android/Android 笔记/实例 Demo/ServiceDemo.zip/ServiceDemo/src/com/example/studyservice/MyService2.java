package com.example.studyservice;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public class MyService2 extends Service {

	@Override
	public void onCreate() {
		System.out.println("onCreate()");
		super.onCreate();
	}
	
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		System.out.println("onBind()");
		return myBinder;
	}

    private MyBinder myBinder = new MyBinder();

    public class MyBinder extends Binder{
    	
    	public MyService2 getService(){
    		return MyService2.this;
    	}
    }
    
    public void MyMethod(){
    	System.out.println("MyMethod()");
    }
    
    @Override
    public boolean onUnbind(Intent intent) {
    	System.out.println("onUnbind()");
    	return super.onUnbind(intent);
    }
    
    @Override
    public void onDestroy() {
    	System.out.println("onDestroy()");
    	super.onDestroy();
    }
}
