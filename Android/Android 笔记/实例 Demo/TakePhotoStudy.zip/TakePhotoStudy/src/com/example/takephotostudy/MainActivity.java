package com.example.takephotostudy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends Activity {

	public static final int TAKE_PHOTO = 1;
	public static final int CROP_PHOTO = 2;
	public static final int SELETE_PHOTO = 3;
	
	ImageView iv_;
	Button cropPhoto;
	Uri imageUri;
	Uri imageUri_seletePhoto;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		iv_ = (ImageView) findViewById(R.id.iv_);
		cropPhoto = (Button) findViewById(R.id.btn_cropphoto);
	}

	public void takePhoto(View v){
		File file = new File(Environment.getExternalStorageDirectory(), "tempImage.jpg");
		try {
			if(file.exists()){
				file.delete();
			}
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		imageUri = Uri.fromFile(file);
		Intent i = new Intent("android.media.action.IMAGE_CAPTURE");
		i.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
		startActivityForResult(i, TAKE_PHOTO);
	}
	
	
	public void cropPhoto(View v){
		Intent i = new Intent("com.android.camera.action.CROP");
		i.setDataAndType(imageUri, "image/*");
		i.putExtra("scale", true);
		i.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
		startActivityForResult(i, CROP_PHOTO);
	}
	
	public void seletePhoto(View v){
		File file = new File(Environment.getExternalStorageDirectory(), "tempImage1.jpg");
		try {
			if(file.exists()){
				file.delete();
			}
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		imageUri_seletePhoto = Uri.fromFile(file);
		Intent i = new Intent("android.intent.action.GET_CONTENT");
		i.setType("image/*");
		i.putExtra(MediaStore.EXTRA_OUTPUT, imageUri_seletePhoto);
		startActivityForResult(i, SELETE_PHOTO);
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case TAKE_PHOTO:
			if(resultCode == RESULT_OK){
				try {
					Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
					iv_.setImageBitmap(bitmap);
					cropPhoto.setClickable(true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case CROP_PHOTO:
			if(resultCode == RESULT_OK){
				try {
					Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver()
							.openInputStream(imageUri));
					iv_.setImageBitmap(bitmap);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case SELETE_PHOTO:
			if(resultCode == RESULT_OK){
				try {
					Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
					iv_.setImageBitmap(bitmap);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}        
			}
			break;
		}
	}
}
