package com.example.recyclerviewstudy;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.recyclerviewstudy.SimpleAdapter.OnItemClickListener;

public class MainActivity extends Activity {

	RecyclerView mRecyclerView;
	List<String> mDatas;
	SimpleAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initViews();
		
		initDatas();
		
		adapter = new SimpleAdapter(this, mDatas);
		mRecyclerView.setAdapter(adapter);
		
		//设置RecyclerView的布局管理
		mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
		
		//设置RecyclerView的Item分割线
//		mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
		adapter.setOnItemClickListener(new OnItemClickListener() {
			
			@Override
			public void onItemLongClickListener(View v, int position) {
				Toast.makeText(MainActivity.this, "Long:"+position, Toast.LENGTH_SHORT).show();
				
			}
			
			@Override
			public void onItemClickListener(View v, int position) {
				Toast.makeText(MainActivity.this, "Click:"+position, Toast.LENGTH_SHORT).show();
				
			}
		});
	}


	private void initViews() {
		mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview_);
	}
	
	private void initDatas() {
		mDatas = new ArrayList<String>();
		for (int i = 'A'; i <= 'z'; i++) {
			mDatas.add(""+(char)i);
		}
	}

	public void addItem(String c, int position){
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		int id = item.getItemId();
		switch (id) {
		case R.id.action_listview: //ListView
			mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
			break;
		case R.id.action_gridview: //GridView
			mRecyclerView.setLayoutManager(new GridLayoutManager(this, 4));
			break;
		case R.id.action_horizontal_listview: //横向ListView
			mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayout.HORIZONTAL, false));
			break;
		case R.id.action_horizontal_gridview: //横向GridView
			mRecyclerView.setLayoutManager(new GridLayoutManager(this, 5, LinearLayout.HORIZONTAL, false));
			break;
		case R.id.action_staggered_gridview: //瀑布流
			Intent i = new Intent(this, StaggeredGridLayoutActivity.class);
			startActivity(i);
			break;
		case R.id.action_add: //添加
			mDatas.add("ZZZ");
			adapter.notifyItemInserted(2);
			break;
		case R.id.action_delete: //删除
			mDatas.remove(2);
			adapter.notifyItemRemoved(2);
			break;
		}
		
		return super.onOptionsItemSelected(item);
	}
	
	

}
