package com.example.recyclerviewstudy;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.ViewGroup.LayoutParams;

public class StaggeredGridLayoutAdapter extends SimpleAdapter {

	List<Integer> mHeights;
	
	public StaggeredGridLayoutAdapter(Context context, List<String> datas) {
		super(context, datas);
		
		mHeights = new ArrayList<Integer>();
		for (int i = 0; i < datas.size(); i++) {
			mHeights.add((int)(80+Math.random()*100));
		}
	}


	// 绑定ViewHolder
	public void onBindViewHolder(MyViewHolder holder, int pos) {
		LayoutParams lp = holder.tv.getLayoutParams();
		lp.height = mHeights.get(pos);
		holder.tv.setLayoutParams(lp);
		
		holder.tv.setText(datas.get(pos));
		
		setUpItemEvent(holder);
	}


}
