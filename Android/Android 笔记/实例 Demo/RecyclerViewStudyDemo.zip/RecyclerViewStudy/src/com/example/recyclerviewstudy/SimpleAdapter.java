package com.example.recyclerviewstudy;

import java.util.List;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

public class SimpleAdapter extends RecyclerView.Adapter<SimpleAdapter.MyViewHolder> {

	LayoutInflater inflater;
	Context context;
	List<String> datas;

	OnItemClickListener onItemClickListener;
	
	public interface OnItemClickListener{
		public void onItemClickListener(View v, int pos);
		public void onItemLongClickListener(View v, int pos);
	}
	
	public void setOnItemClickListener(OnItemClickListener listener){
		this.onItemClickListener = listener;
	}
	
	public SimpleAdapter(Context context, List<String> datas) {
		this.context = context;
		this.datas = datas;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getItemCount() {
		return datas.size();
	}

	@Override // 绑定ViewHolder
	public void onBindViewHolder(final MyViewHolder holder, final int pos) {
		holder.tv.setText(datas.get(pos));
		
		setUpItemEvent(holder);
	}
	
	
	@Override // 创建ViewHolder
	public MyViewHolder onCreateViewHolder(ViewGroup arg0, int arg1) {

		View view = inflater.inflate(R.layout.adapter_, arg0, false);

		MyViewHolder viewHolder = new MyViewHolder(view);
		return viewHolder;
	}

	class MyViewHolder extends ViewHolder {

		TextView tv;

		public MyViewHolder(View arg0) {
			super(arg0);
			tv = (TextView) arg0.findViewById(R.id.tv_);
		}

	}

	public void setUpItemEvent(final MyViewHolder holder){
		if (onItemClickListener != null) {
			holder.itemView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					int layoutPosition = holder.getPosition();
					onItemClickListener.onItemClickListener(holder.itemView,
							layoutPosition);

				}

			});

			holder.itemView.setOnLongClickListener(new OnLongClickListener() {

				@Override
				public boolean onLongClick(View arg0) {
					int layoutPosition = holder.getPosition();
					onItemClickListener.onItemLongClickListener(
							holder.itemView, layoutPosition);
					return false;
				}
			});
		}
	}
	
}
