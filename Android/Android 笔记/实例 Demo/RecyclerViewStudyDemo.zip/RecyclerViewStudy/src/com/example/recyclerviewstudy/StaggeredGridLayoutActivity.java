package com.example.recyclerviewstudy;

import java.util.ArrayList;
import java.util.List;

import com.example.recyclerviewstudy.SimpleAdapter.OnItemClickListener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.widget.LinearLayout;

@SuppressLint("NewApi")
public class StaggeredGridLayoutActivity extends Activity {

	RecyclerView mRecyclerView;
	List<String> mDatas;
	StaggeredGridLayoutAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initView();
		initData();
		
		adapter = new StaggeredGridLayoutAdapter(this, mDatas);
		mRecyclerView.setAdapter(adapter);
		
		mRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(3, LinearLayoutManager.VERTICAL));
		
		//设置RecyclerView的Item分割线
//		mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
		mRecyclerView.setItemAnimator(new DefaultItemAnimator());
		
		adapter.setOnItemClickListener(new OnItemClickListener() {
			
			@Override
			public void onItemLongClickListener(View v, int pos) {
				mDatas.remove(2);
				adapter.notifyItemRemoved(2);
			}
			
			@Override
			public void onItemClickListener(View v, int pos) {
				
			}
		});
	}



	private void initView() {
		mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview_);
		
	}
	
	private void initData() {
		mDatas = new ArrayList<String>();
		for (int i = 'A'; i <= 'z'; i++) {
			mDatas.add(""+(char)i);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main2, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		int id = item.getItemId();
		switch (id) {
		case R.id.action_add:
			mDatas.add("ZZZ");
			adapter.notifyItemInserted(2);
			break;
		case R.id.action_delete:
			mDatas.remove(2);
			adapter.notifyItemRemoved(2);
			break;
		}
		
		return super.onOptionsItemSelected(item);
	}

}
