package com.example.studybroadcastreceiver;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}


	public void send1(View v){
		Intent i = new Intent();
		i.setAction("MyBroadcast"); 
		sendBroadcast(i);
	}
	
	public void register(View v){
		MyBroadcastReceiver2 receiver = new MyBroadcastReceiver2();
		IntentFilter filter = new IntentFilter();
		filter.addAction("BBB");
		registerReceiver(receiver, filter);
	}
	
	public void send2(View v){
		Intent i = new Intent();
		i.setAction("BBB");
		sendBroadcast(i);
	}
}
