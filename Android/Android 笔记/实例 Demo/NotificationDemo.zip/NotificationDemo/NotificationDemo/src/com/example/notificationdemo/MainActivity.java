package com.example.notificationdemo;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private static String TAG = "mian";
	private Button btnToast1, btnCustomToast, btnNotification,
	btnProgreNotification, btnProNotification, btnCustomNotification,
			btnBigViewNotification;
	private NotificationManager manager;
	private NotificationCompat.Builder builder;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btnToast1 = (Button) findViewById(R.id.btnToast1);
		btnCustomToast = (Button) findViewById(R.id.btnCustomToast);
		btnNotification = (Button) findViewById(R.id.btnNotification);
		btnProgreNotification = (Button) findViewById(R.id.btnProgreNotification);
		btnProNotification = (Button) findViewById(R.id.btnProNotification);
		btnCustomNotification = (Button) findViewById(R.id.btnCustomNotification);
		btnBigViewNotification = (Button) findViewById(R.id.btnBigViewNotification);
		btnToast1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Toast toast = Toast.makeText(MainActivity.this, "Toast��ʾ��Ϣ",
						Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER, 0, 0);
				toast.show();
			}
		});

		btnCustomToast.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				View view = LayoutInflater.from(MainActivity.this).inflate(
						R.layout.toast_layout, null);
				TextView tv = (TextView) view.findViewById(R.id.text);
				tv.setText("�Զ�����ʾToast");
				Toast toast = new Toast(MainActivity.this);
				toast.setView(view);
				toast.show();

			}
		});

		btnNotification.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Bitmap btm = BitmapFactory.decodeResource(getResources(),
						R.drawable.msg);
				NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
						MainActivity.this).setSmallIcon(R.drawable.msg)
						.setContentTitle("5 new message")
						.setContentText("twain@android.com");
				mBuilder.setTicker("New message");//��һ����ʾ��Ϣ��ʱ����ʾ��֪ͨ����
				mBuilder.setNumber(12);
				mBuilder.setLargeIcon(btm);
				mBuilder.setAutoCancel(true);//�Լ�ά��֪ͨ����ʧ
				mBuilder.setDefaults(Notification.DEFAULT_ALL);
				
				//����һ��Intent
				Intent resultIntent = new Intent(MainActivity.this,
						ResultActivity.class);
				//��װһ��Intent
				PendingIntent resultPendingIntent = PendingIntent.getActivity(
						MainActivity.this, 0, resultIntent,
						PendingIntent.FLAG_UPDATE_CURRENT);
				// ����֪ͨ�������ͼ
				mBuilder.setContentIntent(resultPendingIntent);
				//��ȡ֪ͨ����������
				NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				mNotificationManager.notify(0, mBuilder.build());
			}
		});

		btnProgreNotification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				builder = new NotificationCompat.Builder(MainActivity.this)
						.setSmallIcon(R.drawable.ic_launcher)
						.setContentTitle("Picture Download")
						.setContentText("Download in progress");
				builder.setAutoCancel(true);
				//ͨ��һ�����̣߳���̬���ӽ������̶�
				new Thread(new Runnable() {
					@Override
					public void run() {
						int incr;
						for (incr = 0; incr <= 100; incr += 5) {
							builder.setProgress(100, incr, false);
							manager.notify(0, builder.build());
							try {
								Thread.sleep(300);
							} catch (InterruptedException e) {
								Log.i(TAG, "sleep failure");
							}
						}
						builder.setContentText("Download complete")
								.setProgress(0, 0, false);
						manager.notify(0, builder.build());
					}
				}).start();
			}
		});

		btnProNotification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				builder = new NotificationCompat.Builder(MainActivity.this)
						.setSmallIcon(R.drawable.ic_launcher)
						.setContentTitle("Picture Download")
						.setContentText("Download in progress");
				builder.setProgress(0, 0, true);//����Ϊtrue����ʾ����
				manager.notify(0, builder.build());

				//5��֮��ֹͣ����
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						builder.setProgress(100, 100, false);//����Ϊtrue����ʾ�̶�
						manager.notify(0, builder.build());
					}
				}).start();
			}
		});

		btnCustomNotification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				RemoteViews contentViews = new RemoteViews(getPackageName(),
						R.layout.custom_notification);
				//ͨ���ؼ���Id��������
				contentViews
						.setImageViewResource(R.id.imageNo, R.drawable.btm1);
				contentViews.setTextViewText(R.id.titleNo, "�Զ���֪ͨ����");
				contentViews.setTextViewText(R.id.textNo, "�Զ���֪ͨ����");

				Intent intent = new Intent(MainActivity.this,
						ResultActivity.class);

				PendingIntent pendingIntent = PendingIntent.getActivity(
						MainActivity.this, 0, intent,
						PendingIntent.FLAG_CANCEL_CURRENT);
				NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
						MainActivity.this).setSmallIcon(R.drawable.ic_launcher)
						.setContentTitle("My notification")
						.setTicker("new message");
				mBuilder.setAutoCancel(true);

				mBuilder.setContentIntent(pendingIntent);
				mBuilder.setContent(contentViews);
				mBuilder.setAutoCancel(true);
				NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				mNotificationManager.notify(10, mBuilder.build());
			}
		});

		btnBigViewNotification.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Bitmap btm = BitmapFactory.decodeResource(getResources(),
						R.drawable.msg);
				Intent intent = new Intent(MainActivity.this,
						ResultActivity.class);

				PendingIntent pendingIntent = PendingIntent.getActivity(
						MainActivity.this, 0, intent,
						PendingIntent.FLAG_CANCEL_CURRENT);

				Notification noti = new NotificationCompat.Builder(
						MainActivity.this)
						.setSmallIcon(R.drawable.msg)
						.setLargeIcon(btm)
						.setNumber(13)
						.setContentIntent(pendingIntent)
						.setStyle(
								new NotificationCompat.InboxStyle()
										.addLine(
												"M.Twain (Google+) Haiku is more than a cert...")
										.addLine("M.Twain Reminder")
										.addLine("M.Twain Lunch?")
										.addLine("M.Twain Revised Specs")
										.addLine("M.Twain ")
										.addLine(
												"Google Play Celebrate 25 billion apps with Goo..")
										.addLine(
												"Stack Exchange StackOverflow weekly Newsl...")
										.setBigContentTitle("6 new message")
										.setSummaryText("mtwain@android.com"))
						.build();

				NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				mNotificationManager.notify(0, noti);
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
