package com.example.fragmentstydy;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.Display;

public class MainActivity extends FragmentActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Display display = getWindowManager().getDefaultDisplay();
		int windowWidth = display.getWidth();
		int windowHeight = display.getHeight();
		
		FragmentManager fragmentManager = this.getSupportFragmentManager();
		
		if(windowHeight > windowWidth){
			Fragment1 fragment1 = new Fragment1();
			fragmentManager.beginTransaction().replace(R.id.main_activity, fragment1).commit();
		}else{
			Fragment2 fragment2 = new Fragment2();
			fragmentManager.beginTransaction().replace(R.id.main_activity, fragment2).commit();
		}
	}

}
