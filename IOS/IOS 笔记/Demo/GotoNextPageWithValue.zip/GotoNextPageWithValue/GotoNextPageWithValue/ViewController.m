//
//  ViewController.m
//  GotoNextPageWithValue
//
//  Created by 罗小成 on 2017/9/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"
#import "DefaultInstance.h"

@interface ViewController ()<passValueDelegate>

@property (nonatomic, strong)UILabel *label1;
@property (nonatomic, strong)UIButton *button1;


@end




@implementation ViewController


- (void)passValue:(NSString *)str{
    self.label1.text = str;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.label1 = [UILabel new];
    self.label1.frame = CGRectMake(50, 50, 200, 40);
    self.label1.textColor = [UIColor redColor];
    self.label1.backgroundColor = [UIColor blackColor];
    
    self.button1 = [UIButton new];
    self.button1.frame = CGRectMake(50, 150, 200, 40);
    [self.button1 setTitle:@"跳转至界面二" forState:UIControlStateNormal];
    [self.button1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.button1 addTarget:self action:@selector(toNextPage:) forControlEvents:UIControlEventTouchDown];

    
    [self.view addSubview:self.label1];
    [self.view addSubview:self.button1];
    
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//    NSLog(@"%d", label1 == nil);
//    NSLog(@"1%@", [DefaultInstance sharedInstance].str);
    self.label1.text = [DefaultInstance sharedInstance].str;
}

- (IBAction)toNextPage:(id)sender {

    NextViewController *nextVC = [NextViewController new];
//    nextVC.str = @"属性传值";
//    [DefaultInstance sharedInstance].str = @"单例传值";
//    NSLog(@"2%@", [DefaultInstance sharedInstance].str);
//    nextVC.delegate = self;
//    nextVC.block = ^(NSString *str){
//        self.label1.text = str;
//    };
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notHandler:) name:@"notify" object:nil];
    
    [self presentViewController:nextVC animated:YES completion:nil];
}

- (void)notHandler:(NSNotification*)not{
    self.label1.text = not.userInfo[@"not"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
