//
//  NextViewController.m
//  GotoNextPageWithValue
//
//  Created by 罗小成 on 2017/9/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "NextViewController.h"
#import "DefaultInstance.h"

@interface NextViewController ()

@property (nonatomic, strong)UITextField *textField;
@property (nonatomic, strong)UIButton *button2;

@end


@implementation NextViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.textField = [UITextField new];
    self.textField.frame = CGRectMake(50, 50, 200, 40);
    self.textField.borderStyle = UITextBorderStyleRoundedRect;

    self.button2 = [UIButton new];
    self.button2.frame = CGRectMake(50, 150, 200, 40);
    [self.button2 setTitle:@"回到界面一" forState:UIControlStateNormal];
    [self.button2 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.button2 addTarget:self action:@selector(toHomePage:) forControlEvents:UIControlEventTouchDown];

    
    [self.view addSubview:self.textField];
    [self.view addSubview:self.button2];
    
    self.view.backgroundColor = [UIColor whiteColor];

    
    self.textField.text = self.str;
//    NSLog(@"3%@", [DefaultInstance sharedInstance].str);
    self.textField.text = [DefaultInstance sharedInstance].str;
    
    
}


- (IBAction)toHomePage:(id)sender {
    [DefaultInstance sharedInstance].str = self.textField.text;
//    NSLog(@"4%@", [DefaultInstance sharedInstance].str);

//    [self.delegate passValue:self.textField.text];
//    self.block(self.textField.text);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"notify" object:nil userInfo:@{@"not":self.textField.text}];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
