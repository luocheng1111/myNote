//
//  NextViewController.h
//  GotoNextPageWithValue
//
//  Created by 罗小成 on 2017/9/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

//委托方-创建一个协议
@protocol passValueDelegate <NSObject>

//协议定义一个传值的方法
- (void)passValue:(NSString *)str;

@end

@interface NextViewController : ViewController


@property (strong, nonatomic)NSString *str;

@property (weak)id<passValueDelegate>delegate;

@property (copy) void (^block)(NSString *);

@end
