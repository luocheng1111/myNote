//
//  DefaultInstance.h
//  GotoNextPageWithValue
//
//  Created by 罗小成 on 2017/9/12.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DefaultInstance : NSObject

@property(strong, nonatomic)NSString *str;

+ (instancetype)sharedInstance;

@end
