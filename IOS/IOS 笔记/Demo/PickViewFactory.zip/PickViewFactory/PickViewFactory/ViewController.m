//
//  ViewController.m
//  PickViewFactory
//
//  Created by 森虹 on 2018/7/13.
//  Copyright © 2018年 森虹. All rights reserved.
//

#import "ViewController.h"
#import "PickViewFactory.h"
#import <BRPickerView.h>



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)btn1:(id)sender {
    [PickViewFactory showTimePickView:@"时分" resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn2:(id)sender {
    [PickViewFactory showTimePickView:nil defaultTime:@"13:00" style:2 resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn3:(id)sender {
    [PickViewFactory showTimePickView:nil defaultTime:@"13:00" style:3 resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn4:(id)sender {
    [PickViewFactory showDatePickView:nil isShowYear:true isShowMonth:true isShowDay:false defaultDateTime:nil resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn5:(id)sender {
    [PickViewFactory showDatePickView:nil isShowYear:true isShowMonth:true isShowDay:true defaultDateTime:@"2018-03-04" resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn6:(id)sender {
    [PickViewFactory showDateTimePickView:@"时间选择" isShowYear:false isShowMonth:true isShowDay:true isShowHour:true isShowMinute:true defaultDateTime:nil resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
}

- (IBAction)btn7:(id)sender {
    [PickViewFactory showCityPickView:@"浙江省 杭州市 西湖区"  resultBlock:^(BRProvinceModel *province, BRCityModel *city, BRAreaModel *area) {
        NSLog(@"省[%@]：%@，%@", @(province.index), province.code, province.name);
        NSLog(@"市[%@]：%@，%@", @(city.index), city.code, city.name);
        NSLog(@"区[%@]：%@，%@", @(area.index), area.code, area.name);
    }];
  
}


- (IBAction)btn8:(id)sender {
    [PickViewFactory showOneItemPickView:@"性别" defaultValue:@"男" dataSource:@[@"男", @"女", @"其他"] resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
    }];
    
}

- (IBAction)btn9:(id)sender {
    NSArray *dataSource = @[@[@"第1周", @"第2周", @"第3周", @"第4周", @"第5周", @"第6周", @"第7周"], @[@"第1天", @"第2天", @"第3天", @"第4天", @"第5天", @"第6天", @"第7天"]];
    NSArray *defaultSelArr = @[@"第1周", @"第7天"];
    [PickViewFactory showTwoItemPickView:@"自定义多列字符串" defaultSelArr:defaultSelArr dataSource:dataSource resultBlock:^(id selectValue) {
        NSLog(@"%@，%@", selectValue[0], selectValue[1]);
    }];
}

- (IBAction)btn10:(id)sender {
}


@end
