//
//  main.m
//  UIPickView_study01
//
//  Created by 罗小成 on 2017/9/16.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
