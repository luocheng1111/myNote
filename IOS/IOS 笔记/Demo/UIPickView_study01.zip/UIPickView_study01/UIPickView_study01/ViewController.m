//
//  ViewController.m
//  UIPickView_study01
//
//  Created by 罗小成 on 2017/9/16.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIPickerView *pickerView = [UIPickerView new];
    pickerView.frame = CGRectMake(50, 50, 200, 400);
    
    pickerView.dataSource = self;
    pickerView.delegate = self;
    
    [self.view addSubview:pickerView];
}

//视图的组数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

//每组多少个元素
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return 5;
}

//每个元素的内容
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSString *str = [NSString stringWithFormat:@"%ld组%ld行",component+1, row+1];
    return str;
}




@end
