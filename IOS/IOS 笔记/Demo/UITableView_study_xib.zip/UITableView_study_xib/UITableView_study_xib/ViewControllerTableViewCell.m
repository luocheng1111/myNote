//
//  ViewControllerTableViewCell.m
//  UITableView_study_xib
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewControllerTableViewCell.h"

@implementation ViewControllerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
