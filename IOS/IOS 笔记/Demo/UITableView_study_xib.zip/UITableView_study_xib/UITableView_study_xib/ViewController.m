//
//  ViewController.m
//  UITableView_study_xib
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"
#import "ViewControllerTableViewCell.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _tableView.dataSource = self;
    _tableView.delegate = self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"ViewControllerTableViewCell";
    ViewControllerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[[NSBundle mainBundle] loadNibNamed:@"ViewControllerTableViewCell" owner:self options:nil] lastObject];
    }
    
    cell.label1.text = @"a阿啊";
    cell.label2.text = [NSString stringWithFormat:@"%ld", indexPath.row];

    return cell;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
