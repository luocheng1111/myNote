//
//  BaseController.m
//  ReplaceTableViewByErrorData
//
//  Created by 森鸿 on 2018/6/12.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import "BaseController.h"
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>

@interface BaseController ()<DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

@property (nonatomic) BOOL isLoading;
@property(nonatomic,strong) NSString *emptyViewImageName;
@property(nonatomic,strong) NSString *emptyViewMsg;
@end

@implementation BaseController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)showEmptyView {
    self.emptyViewImageName = @"no_data";
    self.emptyViewMsg = @"没有数据 点击界面刷新";
}

- (void)showNetWorkErrView {
    self.emptyViewImageName = @"no_network";
    self.emptyViewMsg = @"网络错误 点击界面刷新";
}

- (void)showErrorView {
    self.emptyViewImageName = @"no_network";
    self.emptyViewMsg = @"出错了点击界面刷新";
}

#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    
}

#pragma mark - 空白页显示的图片
- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    if (self.isLoading) {
        return [UIImage imageNamed:@"emptyview_loading"];
    }else{
        return [UIImage imageNamed:self.emptyViewImageName==nil? @"no_data" : self.emptyViewImageName];
    }
}

#pragma mark - 空白页显示的信息
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
    NSString *title = nil;
    if (self.isLoading) {
       title = @"数据加载中...";
    }else{
        title = self.emptyViewMsg==nil? @"没有数据 点击界面刷新" : self.emptyViewMsg;
    }
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont boldSystemFontOfSize:18.0f],
                                 NSForegroundColorAttributeName:[UIColor darkGrayColor]
                                 };
    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
}


//获取滚动权限（默认值为NO）：
- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView{
    return YES;
}

#pragma mark 空白页面被点击时刷新页面
- (void)emptyDataSet:(UIScrollView *)scrollView didTapView:(UIView *)view {
    // 空白页面被点击时开启动画，reloadEmptyDataSet
    self.isLoading = YES;
    [self emptyViewClick];
}



#pragma mark 空白页消失时
- (void)emptyDataSetDidDisappear:(UIScrollView *)scrollView{
    self.isLoading = NO;
}

#pragma mark 图片旋转动画
- (CAAnimation *)imageAnimationForEmptyDataSet:(UIScrollView *)scrollView{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];
    animation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    animation.toValue = [NSValue valueWithCATransform3D: CATransform3DMakeRotation(M_PI_2, 0.0, 0.0, 1.0) ];
    animation.duration = 0.25;
    animation.cumulative = YES;
    animation.repeatCount = MAXFLOAT;
    
    return animation;
}


#pragma mark 是否开启动画
- (BOOL)emptyDataSetShouldAnimateImageView:(UIScrollView *)scrollView {
    return self.isLoading;
}




@end
