//
//  ViewController.m
//  ReplaceTableViewByErrorData
//
//  Created by 森鸿 on 2018/6/12.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import "ViewController.h"
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) NSMutableArray *dataSources;
@end

@implementation ViewController
- (IBAction)change1:(id)sender {
    [self.dataSources removeAllObjects];
    [self showEmptyView];
    [self.tableView reloadData];
}
- (IBAction)change2:(id)sender {
    [self.dataSources removeAllObjects];
    [self showNetWorkErrView];
    [self.tableView reloadData];
}
- (IBAction)add:(id)sender {
    [self.dataSources addObject:@"测试11111111"];
    [self.dataSources addObject:@"测试11111111"];
    [self.tableView reloadData];
}
- (IBAction)remove:(id)sender {
    [self.dataSources removeAllObjects];
    [self.tableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    // 删除单元格分隔线的一个小技巧
    self.tableView.tableFooterView = [UIView new];
    self.dataSources = [NSMutableArray new];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSources.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"XLCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    UILabel *lable = [cell viewWithTag:0];
    lable.text = self.dataSources[indexPath.row];
    return cell;
}


#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    NSLog(@"buttonEvent");
    [self.tableView reloadEmptyDataSet];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 任务加载完成后关闭动画，reloadEmptyDataSet
        [self.dataSources addObject:@"测试11111111"];
        [self.dataSources addObject:@"测试11111111"];
        [self.tableView reloadData];
    });
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}




@end
