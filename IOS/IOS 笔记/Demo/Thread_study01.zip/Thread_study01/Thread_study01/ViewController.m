//
//  ViewController.m
//  Thread_study01
//
//  Created by 罗小成 on 2017/9/20.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (IBAction)pThreadClick:(id)sender {
    pthread_t pthread;
    pthread_create(&pthread, NULL, pThreadRun, NULL);
    NSLog(@"主线程");
}

void *pThreadRun(void *data){
    for (int i=0; i<10; i++) {
        NSLog(@"%d",i);
        sleep(0.2);
    }
    return NULL;
}


- (IBAction)nSThreadClick:(id)sender {
    //有3种启动方法
    //1.先创建线程，再启动
//    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(nsThreadRun) object:nil];
//    [thread start];
    
    //2.通过detachNewThreadSelector 创建线程并启动
//    [NSThread detachNewThreadSelector:@selector(nsThreadRun) toTarget:self withObject:nil];
    
    
    //3.使用NSObject的方法创建并自动启动
    [self performSelectorInBackground:@selector(nsThreadRun) withObject:nil];
    
    NSLog(@"主线程 NThread 执行");
}

- (void) nsThreadRun{
    NSLog(@"子线程执行1");
}



- (IBAction)gcdClick:(id)sender {
    //同步线程. 异步线程
    //队列 串行队列 并行队列
    
    //异步并行队列
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//        //执行耗时任务
//        NSLog(@"thread start!");
//        sleep(3);
//        dispatch_async(dispatch_get_main_queue(), ^{
//            //回到主线程刷行UI
//            NSLog(@"刷新UI");
//        });
//    });
    
    //同步串行队列
//   dispatch_queue_t queue = dispatch_queue_create("com.test.thread", NULL);
//   dispatch_sync(queue, ^{
//       NSLog(@"thread1 start!");
//       [NSThread sleepForTimeInterval:2];
//       NSLog(@"thread1 end!");
//   });
//    
//   dispatch_sync(queue, ^{
//        NSLog(@"thread2 start!");
//        [NSThread sleepForTimeInterval:2];
//        NSLog(@"thread2 en   d!");
//   });
    
    //队列组 当一组线程全部执行完成之后可以进行通知
    //1.创建队列组
    dispatch_group_t group = dispatch_group_create();
    
    //3.多次使用队列组的方法执行任务, 只有异步方法
    //3.1.执行3次循环
    dispatch_group_async(group, dispatch_get_global_queue(0, 0), ^{
        for (NSInteger i = 0; i < 3; i++) {
            NSLog(@"group-01 - %ld", i);
        }
    });
    
    //3.2.主队列执行8次循环
    dispatch_group_async(group, dispatch_get_main_queue(), ^{
        for (NSInteger i = 0; i < 5; i++) {
            NSLog(@"group-02 - %ld", i);
        }
    });
    
    //3.3.执行5次循环
    dispatch_group_async(group, dispatch_get_global_queue(0, 0), ^{
        for (NSInteger i = 0; i < 3; i++) {
           NSLog(@"group-03 - %ld", i);
        }
    });
    
    //4.都完成后会自动通知
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        NSLog(@"完成 - %@", [NSThread currentThread]);
    });
    

}

- (IBAction)nsOperation:(id)sender {
    //2种NSOperation创建方式
    //1.NSInvocationOperation创建
    NSInvocationOperation *invocationOperation = [[NSInvocationOperation alloc] initWithTarget:self selector:@selector(nsOperationRun) object:nil];
    
    //2.NSBlockOperation创建
    NSBlockOperation *blockOperation = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"NSBlockOperation");
    }];
    //3.自定义NSOperation类
    CustomOperation *customOperation = [CustomOperation new];
    
    
    NSOperationQueue *queue = [NSOperationQueue mainQueue];
    queue.maxConcurrentOperationCount = 3;
    [queue addOperation:invocationOperation];
    [queue addOperation:blockOperation];
    [queue addOperation:customOperation];
    
}



- (void) nsOperationRun{
    NSLog(@"NSInvocationOperation");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
