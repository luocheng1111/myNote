//
//  CustomOperation.m
//  Thread_study01
//
//  Created by 罗小成 on 2017/9/27.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "CustomOperation.h"

@implementation CustomOperation

- (void)main{
    NSLog(@"自定义NSOperation类");
}

@end
