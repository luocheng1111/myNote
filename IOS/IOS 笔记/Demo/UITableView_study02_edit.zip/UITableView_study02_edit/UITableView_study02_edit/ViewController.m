//
//  ViewController.m
//  UITableView_syudy01
//
//  Created by 罗小成 on 17/9/1.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

NSMutableArray *dataList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //style有两种风格：普通风格和分组风格
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 80, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.view addSubview:self.tableView];
    
    dataList = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9", nil];
    
}

- (IBAction)toEdit:(UIButton *)sender {

    [self.tableView setEditing:!self.tableView.editing animated:YES];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"%ld", indexPath.row);
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataList.count;
    
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    
    
    NSString *str = dataList[sourceIndexPath.row];
    [dataList removeObjectAtIndex:sourceIndexPath.row];
    [dataList insertObject:str atIndex:destinationIndexPath.row];
    
    NSLog(@"移动后：%@", dataList);
//    [tableView reloadData];
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //有删除 有添加
    if(editingStyle == UITableViewCellEditingStyleDelete){
        [dataList removeObjectAtIndex:indexPath.row];
    }
    NSLog(@"删除后：%@", dataList);
    [tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellId = @"cell";
    
    UITableViewCell *tableCell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(tableCell == nil){
        tableCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    //默认点tableCell中有textLable imageView deta控件
    tableCell.textLabel.text = dataList[indexPath.row];
    return  tableCell;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
