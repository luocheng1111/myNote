//
//  AppDelegate.h
//  UITableView_study02_edit
//
//  Created by 罗小成 on 17/9/1.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

