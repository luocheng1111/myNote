//
//  TabController3.m
//  UITabBarController_study_storyboard
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "TabController3.h"

@interface TabController3 ()

@end

@implementation TabController3

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor blueColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
