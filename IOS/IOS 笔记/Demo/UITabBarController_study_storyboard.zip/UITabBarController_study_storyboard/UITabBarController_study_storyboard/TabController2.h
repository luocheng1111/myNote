//
//  TabController2.h
//  UITabBarController_study_storyboard
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabController2 : UIViewController

@end
