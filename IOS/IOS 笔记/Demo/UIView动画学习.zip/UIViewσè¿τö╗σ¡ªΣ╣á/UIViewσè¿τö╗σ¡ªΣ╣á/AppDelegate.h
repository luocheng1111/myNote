//
//  AppDelegate.h
//  UIView动画学习
//
//  Created by 罗小成 on 2017/9/13.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

