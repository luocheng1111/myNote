//
//  ViewController.m
//  UIView动画学习
//
//  Created by 罗小成 on 2017/9/13.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)moveAnimation:(id)sender {
    [UIView animateWithDuration:1 animations:^{
        CGPoint center = self.uiView.center;
        center.x = self.view.bounds.size.width - self.uiView.center.x;
        center.y = self.view.bounds.size.height - self.uiView.center.y;
        self.uiView.center = center;
    }];
    
}

- (IBAction)alphaAnimation:(id)sender {
    [UIView animateWithDuration:1 animations:^{
        self.uiView.alpha=0.1;
    }];
}

- (IBAction)scaleAnimation:(id)sender {
    CGAffineTransform transform = self.uiView.transform;
    [UIView animateWithDuration:1 animations:^{
        self.uiView.transform = CGAffineTransformMakeScale(2.0, 2.0);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:1 animations:^{
            self.uiView.transform = transform;
        }];
    }];
}

- (IBAction)colorAnimation:(id)sender {
    [UIView animateWithDuration:1 animations:^{
        self.uiView.backgroundColor = [UIColor greenColor];
    }];
}

- (IBAction)rotationAnimation:(id)sender {
    CGAffineTransform transform = self.uiView.transform;
    
    [UIView animateWithDuration:1 animations:^{
        self.uiView.transform = CGAffineTransformMakeRotation(4.0);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:1 animations:^{
            self.uiView.transform = transform;
        }];
    }];
}


- (IBAction)repate1Animation:(id)sender {
    [UIView animateWithDuration:2 delay:0 options:UIViewAnimationOptionRepeat animations:^{
        CGPoint center = self.uiView.center;
        center.x = self.view.bounds.size.width - self.uiView.center.x;
        self.uiView.center = center;
    } completion:^(BOOL finished) {
        
    }];
}


- (IBAction)repate2Animation:(id)sender {
    [UIView animateWithDuration:2 delay:0 options:UIViewAnimationOptionRepeat|UIViewAnimationOptionAutoreverse animations:^{
        CGPoint center = self.uiView.center;
        center.x = self.view.bounds.size.width - self.uiView.center.x;
        self.uiView.center = center;
    } completion:^(BOOL finished) {
        
    }];

}


- (IBAction)easingAnimation:(id)sender {
    [UIView animateWithDuration:2 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        CGPoint center = self.uiView.center;
        center.x = self.view.bounds.size.width - self.uiView.center.x;
        self.uiView.center = center;
    } completion:^(BOOL finished) {
        
    }];
    
}


- (IBAction)springAnimation:(id)sender {
    [UIView  animateWithDuration:2 delay:0 usingSpringWithDamping:0.1 initialSpringVelocity:0 options:nil animations:^{
        CGPoint center = self.uiView.center;
        center.x = self.view.bounds.size.width - self.uiView.center.x;
        self.uiView.center = center;
    } completion:^(BOOL finished) {
        
    }];
}

@end
