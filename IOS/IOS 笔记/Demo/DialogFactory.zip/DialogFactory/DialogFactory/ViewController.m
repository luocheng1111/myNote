//
//  ViewController.m
//  DialogFactory
//
//  Created by 森鸿 on 2018/6/13.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import "ViewController.h"
#import "DialogFactory.h"

@interface ViewController ()

@end

@implementation ViewController

UIAlertController *alertVC;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)btn0:(id)sender {
    [DialogFactory dismissDialog];
}

- (IBAction)btn1:(id)sender {
    [DialogFactory showOneBtnDialog:self withTitle:@"标题" withMsg:@"消息"];
    
//    [ViewController showAlert:self];
}

//+ (void)showAlert:(UIViewController *)controller
//{
//    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"title" message:@"message" preferredStyle:UIAlertControllerStyleAlert];
//    [alertVC addAction:[UIAlertAction actionWithTitle:@"YES" style:UIAlertActionStyleDefault handler:nil]];
//    [alertVC addAction:[UIAlertAction actionWithTitle:@"NO" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
//        NSLog(@"NO");
//    }]];
////    _alertVC = alertVC;
//    [controller presentViewController:alertVC animated:YES completion:nil];
//    
//    // 增加点击事件
//    UIWindow *alertWindow = (UIWindow *)[UIApplication sharedApplication].windows.lastObject;
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:controller action:@selector(hideAlert)];
//    [alertWindow addGestureRecognizer:tap];
//}
//- (void)hideAlert
//{
//    NSLog(@"111");
////    UIWindow *alertWindow = (UIWindow *)[UIApplication sharedApplication].windows.lastObject;
////    [alertWindow removeGestureRecognizer:tap];
////    [_alertVC dismissViewControllerAnimated:YES completion:nil];
//}


- (IBAction)btn2:(id)sender {
    [DialogFactory showTwoBtnDialog:self withTitle:@"标题" withMsg:@"消息"];
}

- (IBAction)btn3:(id)sender {
//    [DialogFactory showTwoBtnDialog:self withTitle:@"标题" withMsg:@"消息" isCancelable:false btn1Text:@"按钮1" btn2Text:@"按钮2" handle1:^(UIAlertAction *action) {
//        NSLog(@"按钮1");
//    } handle2:^(UIAlertAction *action) {
//        NSLog(@"按钮2");
//    }];
    [DialogFactory showLoadingView];
}
- (IBAction)btn4:(id)sender {
    [DialogFactory showLoadingView:@"加载中...."];
}
- (IBAction)btn5:(id)sender {
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:false withLoadingCircleStyle:1 isMask:true isCancelable:true];
}
- (IBAction)btn6:(id)sender {
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:true];
}
- (IBAction)btn7:(id)sender {
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:true withLoadingCircleStyle:1 isMask:true isCancelable:true];
    
}
- (IBAction)btn8:(id)sender {
    [DialogFactory showProgressView];
//    [DialogFactory showTipsInBottom:self.view withText:@"111"];
}
- (IBAction)btn9:(id)sender {
    [DialogFactory showProgressView:true isCancelable:true];
}
- (IBAction)btn10:(id)sender {
    [DialogFactory showTipsInCenter:self.view withText:@"1111"];
}
- (IBAction)btn11:(id)sender {
    [DialogFactory showTipsInBottom:self.view withText:@"1111"];
}
- (IBAction)btn12:(id)sender {
    [DialogFactory showInfoTip:@"Useful Information."];
}
- (IBAction)btn13:(id)sender {
     [DialogFactory showSuccessTip:@"Useful Information."];
}
- (IBAction)btn14:(id)sender {
     [DialogFactory showErrorTip:@"Failed with Error"];
}

- (IBAction)btn15:(id)sender {
    [DialogFactory showTipsWithImage:self.view withImage:@"ok" withText:@"成功"];
}
- (IBAction)btn16:(id)sender {
    [DialogFactory showTipsWithImage:self.view withImage:@"no" withText:@"失败"];
}
- (IBAction)btn17:(id)sender {
    [DialogFactory showTipsWithImage:self.view isWhiteStyle:true withImage:@"ok" withText:@"成功"];
}

- (IBAction)btn18:(id)sender {
   
}

- (IBAction)btn19:(id)sender {
}

@end
