//
//  ViewController.h
//  DialogFactory
//
//  Created by 森鸿 on 2018/6/13.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@end

