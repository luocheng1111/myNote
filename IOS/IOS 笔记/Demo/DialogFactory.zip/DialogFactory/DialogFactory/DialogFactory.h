//
//  DialogHelper.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DialogFactory : NSObject


 + (void)showOneBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
               withMsg:(NSString *)msg;

+ (void)showOneBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg
                 btnText:(NSString *)btnText
                action:(void (^)(UIAlertAction *action))action;


+ (void)showTwoBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg;

+ (void)showTwoBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg
            isCancelable:(BOOL)isCancelable
                btn1Text:(NSString *)btn1Text
                btn2Text:(NSString *)btn2Text
                handle1:(void (^)(UIAlertAction *action))handle1
                handle2:(void (^)(UIAlertAction *action))handle2;

        
+ (void)showLoadingView;
+ (void)showLoadingView:(NSString *)text;
+ (void)showLoadingView:(NSString *)text isWhiteStyle:(BOOL)isWhiteStyle;
+ (void)showLoadingView:(NSString *)text
               isWhiteStyle:(BOOL)isWhiteStyle
               withLoadingCircleStyle:(NSInteger)circleStyle
               isMask:(BOOL)isMask
               isCancelable:(BOOL)isCancelable;
+ (void)dismissDialog;


+ (void)showProgressView;
+ (void)showProgressView:(BOOL)isWhiteStyle isCancelable:(BOOL)isCancelable;

+ (void)showTipsInCenter:(UIView *)view withText:(NSString *)text;
+ (void)showTipsInBottom:(UIView *)view withText:(NSString *)text;

+ (void)showInfoTip:(NSString *)text;
+ (void)showSuccessTip:(NSString *)text;
+ (void)showErrorTip:(NSString *)text;

+ (void)showOKDialog:(UIView *)view withText:(NSString *)text;
+ (void)showNODialog:(UIView *)view withText:(NSString *)text;

+ (void)showTipsWithImage:(UIView *)view withImage:(NSString *)imageName withText:(NSString *)text;
+ (void)showTipsWithImage:(UIView *)view isWhiteStyle:(BOOL)isWhiteStyle withImage:(NSString *)imageName withText:(NSString *)text;



@end
