//
//  ViewController.m
//  UITouch_study01
//
//  Created by 罗小成 on 2017/9/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


//当点击屏幕的开始的瞬间调用此函数
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"手指触碰瞬间!");
    
    UITouch *touch = [touches anyObject];
    if (touch.tapCount==1){
        NSLog(@"单次点击");
    }
    else if(touch.tapCount==2){
        NSLog(@"双次点击");
    }
    
}

//手指在屏幕上时调用，并且移动数据可以获取
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"手指移动!");
    
    UITouch *touch = [touches anyObject];
    //获得当前手指在屏幕上的相对坐
    CGPoint pt = [touch locationInView:self.view];
    NSLog(@"x=%f, y=%f", pt.x, pt.y);
    
}

//手指离开屏幕时调用
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"手指离开屏幕!");
}

//在特殊情况中断触屏事件时调用
//电话，紧急信息时，取消当前的点击手势作用时调用
//用来做紧急数据处理
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"touch cancel!");
}


@end
