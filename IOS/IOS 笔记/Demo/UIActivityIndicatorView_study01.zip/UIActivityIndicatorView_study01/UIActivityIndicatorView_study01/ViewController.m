//
//  ViewController.m
//  UIActivityIndicatorView_study01
//
//  Created by 罗小成 on 2017/11/3.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController{
    UIActivityIndicatorView *_indicator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _indicator = [[UIActivityIndicatorView alloc] init];
    
    //指示器的那个圈的宽高不会改变，但指示器的大小会改变
    _indicator.frame = CGRectMake(100, 125, 50, 50);
    _indicator.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:_indicator];
    
    //设置风格
    /**
     UIActivityIndicatorViewStyleWhiteLarge  白 大号
     UIActivityIndicatorViewStyleWhite       白
     UIActivityIndicatorViewStyleGray        灰
     */
    _indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
    
    //设置停止时是否隐藏
    _indicator.hidesWhenStopped = NO;
    
    //设置颜色
    _indicator.color = [UIColor redColor];
}

- (IBAction)startClick:(UIButton *)sender {
    [_indicator startAnimating];
}

- (IBAction)stopClick:(UIButton *)sender {
    [_indicator stopAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
