//
//  ViewController.m
//  UIGesture_study01
//
//  Created by 罗小成 on 2017/9/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"meinv.jpg"]];
    imageView.frame = CGRectMake(50, 50, 250, 400);
    
    //UIImageView默认不支持手势，我们需要用时需开启手势
    imageView.userInteractionEnabled = YES;
    
    [self.view addSubview:imageView];
    
    //单击手势
//    UITapGestureRecognizer *tapOneGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapOneAct:)];
//    [imageView addGestureRecognizer:tapOneGes];
    
    
    //双击手势
//    UITapGestureRecognizer *tapTwoGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapTwoAct:)];
//    //手势识别事件：几次点击时触发
//    tapTwoGes.numberOfTapsRequired = 2;
//    //几个手指点击时触发此事件
//    tapTwoGes.numberOfTouchesRequired = 1;
//    [imageView addGestureRecognizer:tapTwoGes];
    
    
    //捏合手势
//    UIPinchGestureRecognizer *pinchGes = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchAct:)];
//    [imageView addGestureRecognizer:pinchGes];
    
    
    //旋转手势
//    UIRotationGestureRecognizer *rotGes = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotAct:)];
//    [imageView addGestureRecognizer:rotGes];
    
    //如果想同时支持放大缩小和旋转,则需要实现UIGestureRecognizerDelegate接口
    //且需要实现下面gestureRecognizer方法
//    pinchGes.delegate = self;
//    rotGes.delegate = self;
    
    //平移手势
//    UIPanGestureRecognizer *panGes = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAct:)];
//    [imageView addGestureRecognizer:panGes];
    
    //滑动手势,判断滑动方向
//    UISwipeGestureRecognizer *swipeGes = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeAct:)];
//    [imageView addGestureRecognizer:swipeGes];
    
    //长按手势
    UILongPressGestureRecognizer *longPressGes = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAct:)];
    [imageView addGestureRecognizer:longPressGes];
    
}

//是否可以同时相应两个手势
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}

//单击手势
- (void) tapOneAct:(UITapGestureRecognizer*)tap{
    NSLog(@"单击手势");
}

//双击手势
- (void) tapTwoAct:(UITapGestureRecognizer*)tap{
    NSLog(@"双击手势");
}

//捏合手势
- (void) pinchAct:(UIPinchGestureRecognizer*)pinch{
    NSLog(@"捏合手势");
    UIImageView *imageView = (UIImageView*)pinch.view;
    
    /**
     transform：表示变换矩阵
     p1: 原来的矩阵
     p2/p3:x／y方向的缩放比例
     返回新的缩放后的矩阵
    */
    imageView.transform = CGAffineTransformScale(imageView.transform, pinch.scale, pinch.scale);
    //将缩放值归位为单位值
    pinch.scale = 1;
}

//旋转手势
- (void) rotAct:(UIRotationGestureRecognizer*)rot{
    NSLog(@"旋转手势");
    
    UIImageView *imageView = (UIImageView*)rot.view;
    
    /**
     返回新的缩放后的矩阵
     */
    imageView.transform = CGAffineTransformRotate(imageView.transform, rot.rotation);
    //将角度清零
    rot.rotation = 0;
}

//平移手势
- (void) panAct:(UIPanGestureRecognizer*)pan{
    NSLog(@"平移手势");
    
    //获取移动的坐标，相当于视图的坐标系
    CGPoint pt = [pan translationInView:self.view];
    NSLog(@"pt.x=%.2f, pt.y=%.2f", pt.x, pt.y);
    
    //获取移动的相对速度
    CGPoint pv = [pan velocityInView:self.view];
    NSLog(@"pv.x=%.2f, pv.y=%.2f", pv.x, pv.y);
}

//滑动手势
- (void) swipeAct:(UISwipeGestureRecognizer*)swipe{
    NSLog(@"滑动手势");
    
//    NSLog(@"%@", swipe.direction);
    
    if(swipe.direction == UISwipeGestureRecognizerDirectionLeft){
        NSLog(@"向左滑动");
    }else if(swipe.direction == UISwipeGestureRecognizerDirectionRight){
        NSLog(@"向右滑动");
    }
}

//长按手势
- (void) longPressAct:(UILongPressGestureRecognizer*)press{
//    NSLog(@"长按手势");
    
    //手势的状态对象，到达规定时间3秒时触发
    if(press.state == UIGestureRecognizerStateBegan){
        NSLog(@"状态开始");
    }
    //当手指离开屏幕时，结束状态
    else if(press.state == UIGestureRecognizerStateEnded){
        NSLog(@"状态结束");
    }
}

@end
