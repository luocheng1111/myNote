//
//  AutoFillTextCell.h
//  carshare
//
//  Created by 森虹 on 2018/7/19.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AutoFillTextCell : UITableViewCell

@property (nonatomic, strong) UILabel *titleLabel;

@end
