//
//  AutoFillTextCell.m
//  carshare
//
//  Created by 森虹 on 2018/7/19.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "AutoFillTextCell.h"
#import "BRPickerViewMacro.h"

#define kLeftMargin 20
#define kRowHeight 50

@implementation AutoFillTextCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ([super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if (_titleLabel==nil) {
            NSLog(@"_titleLabel");
            _titleLabel = [[UILabel alloc]init];
            _titleLabel.backgroundColor = [UIColor clearColor];
            _titleLabel.textColor = BR_RGB_HEX(0x464646, 1.0);
            _titleLabel.font = [UIFont systemFontOfSize:16.0f * kScaleFit];
            _titleLabel.textAlignment = NSTextAlignmentLeft;
        }
        [self.contentView addSubview:self.titleLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.backgroundColor = [UIColor whiteColor];
    // 调整cell分割线的边距：top, left, bottom, right
    self.separatorInset = UIEdgeInsetsMake(0, kLeftMargin, 0, kLeftMargin);
    
    
    
    self.titleLabel.frame = CGRectMake(50, 0, SCREEN_WIDTH-80, 50);
    [self.titleLabel setTextAlignment:NSTextAlignmentRight];
}

- (UILabel *)titleLabel {
    
    return _titleLabel;
}


@end
