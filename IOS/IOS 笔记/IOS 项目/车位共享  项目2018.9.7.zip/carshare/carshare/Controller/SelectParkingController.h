//
//  SelectParkingController.h
//  carshare
//
//  Created by 森虹 on 2018/7/17.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseController.h"

@interface SelectParkingController : BaseController

@property (nonatomic , strong) NSString *pageType;
@property (nonatomic , strong) NSDictionary *pageDic;

@end
