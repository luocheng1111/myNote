//
//  BRInfoModel.m
//  BRPickerViewDemo
//
//  Created by 任波 on 2018/4/16.
//  Copyright © 2018年 91renb. All rights reserved.
//

#import "BRInfoModel.h"

@implementation BRInfoModel

@end
