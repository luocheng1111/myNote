//
//  ViewController.m
//  GaodeMap
//
//  Created by 森鸿 on 2018/6/20.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import "MapController.h"
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import "Constants.h"
#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import "MANaviRoute.h"
#import "CommonUtility.h"
#import "ShareController.h"

#import "GaodeMapManager.h"


#define DefaultLocationTimeout  6
#define DefaultReGeocodeTimeout 3

@interface MapController()<MAMapViewDelegate,AMapSearchDelegate>

@end

@interface MapController ()<AMapSearchDelegate, UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *searchField;
@property (weak, nonatomic) IBOutlet UIView *bottomDialogView;
@property (weak, nonatomic) IBOutlet UILabel *bottomDialogTitle;
@property (weak, nonatomic) IBOutlet UILabel *bottomDialogSubTitle;
@property (weak, nonatomic) IBOutlet UIButton *bottomDialogBtn;

@property (nonatomic, strong) MAMapView *mapView;

//@property (nonatomic, strong) AMapLocationManager *locationManager;

@property (nonatomic, strong) GaodeMapManager *mapManager;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *parkingListImg;
@property (nonatomic , strong) NSMutableArray *filedSearchResult;
@property (nonatomic , strong) NSMutableArray *aroundData;
@property (nonatomic, assign) BOOL isFirstLocation;

@property (nonatomic , strong) NSMutableArray *psersonArr;
@property (nonatomic , strong) NSMutableArray *propertyArr;
@property (nonatomic , strong) NSMutableArray *poisesArr;

@end

@implementation MapController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSLog(@"初始化。。。。。。");
    
    //初始化View和值
    [self initView];
    
    self.psersonArr = [NSMutableArray new];
    self.propertyArr = [NSMutableArray new];
    self.poisesArr = [NSMutableArray new];
    
    //初始化地图
    self.mapManager = [GaodeMapManager sharedManager];
    [self.mapManager initMapView:self];
    
    
    //    self.search =[[AMapSearchAPI alloc] init];
    //    self.search.delegate=self;
    
    //    [self startLocation];
    
    
    //
    //
    //    AMapSearchAPI *search = [[AMapSearchAPI alloc] init];
    //    search.delegate = self;
    
    //    MAPointAnnotation *pointAnnotation = [[MAPointAnnotation alloc] init];
    //    pointAnnotation.coordinate = CLLocationCoordinate2DMake(39.989631, 116.481018);
    //    pointAnnotation.title = @"方恒国际";
    //    pointAnnotation.subtitle = @"阜通东大街6号";
    //
    //    [_mapView addAnnotation:pointAnnotation];
    
    //    CLLocationCoordinate2D coor = CLLocationCoordinate2DMake(30.566666, 104.054536);
    //    [self.mapManager addAnomationToMapView:coor];
    
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //        [self.mapManager searchAroundWithKeyWords:@"餐饮"];
    //    });
    
    //    NSArray *array = @[@"39.822136,116.35095",@"39.832136,116.42095",@"39.902136,116.42095",@"39.902136,116.44095"];
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //        [self.mapManager drawLineWithArray:array];
    //    });
    
    //    CLLocationCoordinate2D startCoordinate        = CLLocationCoordinate2DMake(39.993291, 116.473188);
    //    CLLocationCoordinate2D destinationCoordinate  = CLLocationCoordinate2DMake(39.940474, 116.355426);
    //    [self.mapManager drawCarLine:startCoordinate destinationCoor:destinationCoordinate isWithStartAndEndImg:YES];
}

- (void)initView{
    
    self.tableView.hidden = true;
    self.bottomDialogView.hidden = true;
    
    self.filedSearchResult = [[NSMutableArray alloc]init];
    self.aroundData = [[NSMutableArray alloc]init];
    self.isFirstLocation = true;
    
    self.parkingListImg.hidden = true;
    
    //搜索框文字变化监听
    [self.searchField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    
    // 创建当前View的触摸手势监听
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:nil];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
}

//搜索框文字变化监听
- (void)textFieldDidChange:(UITextField *)textField{
    UITextRange *selectedRange = [textField markedTextRange];
    NSString *newText = [textField textInRange:selectedRange];
    if([newText isEqual:@""] || newText.length == 0){
        NSLog(@"%@",textField.text);
        [self onSearchByKey:textField.text];
    }else{
        NSLog(@"空白");
    }
}


//当前View的触摸手势监听 NO代表不拦截
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    //当底部弹框显示时，点击其外部底部弹框隐藏
    if(![touch.view isDescendantOfView:self.bottomDialogView]){
        self.bottomDialogView.hidden = true;
    }
    return NO;
}

- (IBAction)parkList:(id)sender {
    //    Intent intent2 = new Intent(getActivity(), ShowListActivity.class);
    //    intent2.putExtra("GaodeLocation", (Serializable) locations);
    //    intent2.putExtra("UserParking", (Serializable) parkings);
    //    intent2.putExtra("parkingsOfProperty", (Serializable) propertyparkings);
    //    intent2.putExtra("type", 11);
    //    startActivityForResult(intent2, PIO);
    ShareController *shareController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareController"];
    shareController.pageType = @"selectParking";
    shareController.pageDic = @{
                                @"parkings":self.psersonArr,
                                @"parkingsOfProperty":self.propertyArr,
                                @"poises":self.poisesArr
                                };
    [self.navigationController pushViewController:shareController animated:true];
    [shareController updatePageByPageType];
    
}


#pragma mark 定位更新回调
-(void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation updatingLocation:(BOOL)updatingLocation{
    if(updatingLocation){
        self.mapManager.currentLocation = userLocation.location;
        NSLog(@"定位更新回调 %f-%f", userLocation.location.coordinate.longitude, userLocation.location.coordinate.latitude);
        
        if(self.isFirstLocation){
            self.isFirstLocation = NO;
            self.mapManager.mapView.centerCoordinate = userLocation.location.coordinate;
            //发起逆地理编码
            [self.mapManager regeoLocation:userLocation.coordinate.latitude longitude:userLocation.coordinate.longitude];
        }
    }
}


/* 逆地理编码回调. */
- (void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response{
    if (response.regeocode != nil){
        [self.mapManager.mapView setZoomLevel:17 animated:YES];
        [self searchAroundParking:request.location address:response.regeocode.formattedAddress];
    }
}

//请求网络 获取周围的停车场
- (void)searchAroundParking:(AMapGeoPoint *)location address:(NSString *)address{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    NSString *url = SEARCH_URL;
    NSDictionary *params = [URLAndParmFactory makeSearchAroundParm:userCd city:@"021" destination:address longitude:location.longitude latitude:location.latitude];
    [manager httpRequest:self url:url parameters:params success:^(id responseObject) {
        [self.aroundData removeAllObjects];
        //小区的停车场
        [self.propertyArr removeAllObjects];
        if([responseObject objectForKey:@"parkingsOfProperty"]!=nil){
            [self.propertyArr addObjectsFromArray:[responseObject objectForKey:@"parkingsOfProperty"]];
            for (int i=0; i<(self.propertyArr.count>=20 ? 20: self.propertyArr.count); i++) {
                [self.aroundData addObject:self.propertyArr[i]];
                
                NSDictionary *dic = self.propertyArr[i];
                NSString *title = [NSString stringWithFormat:@"%@,%d", [dic objectForKey:@"propertyName"], 100+i];
                NSString *subtitle = [NSString stringWithFormat:@"距离目的地%@米", [dic objectForKey:@"distance"]];
                [self.mapManager addAnomationToMapView:((NSString*)[dic objectForKey:@"longitude"]).floatValue lon:((NSString *)[dic objectForKey:@"latitude"]).floatValue title:title subtitle:subtitle];
            }
        }
        NSLog(@"小区停车场车位数量：%d", self.propertyArr.count);
        NSLog(@"个人停车场车位数量：%l", self.psersonArr.count);
        NSLog(@"公共停车场车位数量：%l", self.poisesArr.count);
        //个人停车场
        [self.psersonArr removeAllObjects];
        if([responseObject objectForKey:@"parkings"]!=nil){
            NSLog(@"空吗");
            [self.psersonArr addObjectsFromArray:[responseObject objectForKey:@"parkings"]];
            for (int i=0; i<20-self.propertyArr.count; i++) {
                if(i>self.psersonArr.count-1){
                    break ;
                }
                [self.aroundData addObject:self.psersonArr[i]];
                
                NSDictionary *dic = self.psersonArr[i];
                NSString *title = [NSString stringWithFormat:@"%@,%d", [dic objectForKey:@"name"], 1000+self.psersonArr.count+i];
                NSString *subtitle = [NSString stringWithFormat:@"距离目的地%@米", [dic objectForKey:@"distance"]];
                [self.mapManager addAnomationToMapView:((NSString*)[dic objectForKey:@"longitude"]).floatValue lon:((NSString *)[dic objectForKey:@"latitude"]).floatValue title:title subtitle:subtitle];
            }
        }
        NSLog(@"个人停车场车位数量：%l", self.psersonArr.count);
        
        //公共的停车场
        [self.poisesArr removeAllObjects];
        if([responseObject objectForKey:@"poises"]!=nil){
            [self.poisesArr addObjectsFromArray:[responseObject objectForKey:@"poises"]];
            
        }
        NSLog(@"公共停车场车位数量：%l", self.poisesArr.count);
        
        
        self.parkingListImg.hidden = false;
        
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        
    }];
}




//标记点图标设定
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id <MAAnnotation>)annotation{
    //定位小蓝点
    if ([annotation isKindOfClass:[MAUserLocation class]]) {
        return nil;
    }
    //绘制其他点
    if([annotation isKindOfClass:[MAPointAnnotation class]]){
        static NSString *pointReuseIndetifier = @"pointReuseIndetifier";
        
        MAPinAnnotationView *annotationView = (MAPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier];
        
        if (annotationView == nil){
            annotationView = [[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier];
            //点击点标记后是否弹框 如何是YES 弹框显示的是设置好的title和subtitle
            annotationView.canShowCallout = YES;
            annotationView.calloutOffset = CGPointMake(0, -5);
        }
        
        /* 设置起点的图标. */
        if ([[annotation title] isEqualToString:@"起点"]){
            annotationView.image = [UIImage imageNamed:@"startPoint"];
        }
        /* 设置终点的图标. */
        else if([[annotation title] isEqualToString:@"终点"]){
            annotationView.image = [UIImage imageNamed:@"endPoint"];
        }
        /* 设置默认显示图标. */
        else{
            NSString *title = [[annotation title] componentsSeparatedByString:@","][0];
            NSInteger tag = [[[annotation title] componentsSeparatedByString:@","][1] integerValue];
            if(tag>=1000){
                annotationView.image = [UIImage imageNamed:@"poi_marker_10"];
            }else{
                annotationView.image = [UIImage imageNamed:@"poi_marker_1"];
            }
            [annotation setTitle:title];
            annotationView.tag = tag;
            //           NSLog(@"%@", annotationView.flag);
        }
        return annotationView;
    }
    return nil;
    
}

//点击大头针后的回调
- (void)mapView:(MAMapView *)mapView didSelectAnnotationView:(MAAnnotationView *)view{
    //    if ([view1 isKindOfClass:[CustomAnnotationView class]]) {
    //        CustomAnnotationView *view = (CustomAnnotationView*)view1;
    //        NSInteger flag = [view.flag integerValue];
    if(view.tag>=1000){
        NSDictionary *dic = self.aroundData[view.tag-1000];
        self.bottomDialogTitle.text = [dic objectForKey:@"name"];
        self.bottomDialogSubTitle.text = [NSString stringWithFormat:@"距离目的地%@米", [dic objectForKey:@"distance"]];
        [self.bottomDialogBtn setTitle:@"去预约" forState:nil];
    }else{
        NSDictionary *dic = self.aroundData[view.tag-100];
        self.bottomDialogTitle.text = [dic objectForKey:@"propertyName"];
        self.bottomDialogSubTitle.text = [NSString stringWithFormat:@"距离目的地%@米", [dic objectForKey:@"distance"]];
        [self.bottomDialogBtn setTitle:@"去这里" forState:nil];
    }
    self.bottomDialogView.hidden = false;
    //    }
}




- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //点击其他地方，让键盘消失
    [self.view endEditing:YES];
    
}

- (void)addAnnotationToMapView:(id<MAAnnotation>)annotation{
    [self.mapView addAnnotation:annotation];
    
    [self.mapView selectAnnotation:annotation animated:YES];
    [self.mapView setZoomLevel:15.1 animated:NO];
    [self.mapView setCenterCoordinate:annotation.coordinate animated:YES];
}




//请求网络 获取field关键字相关的地名 结果用tableView显示
- (void)onSearchByKey:(NSString *)keywork{
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:[URLAndParmFactory makeKeywordSearchURL:keywork] parameters:nil success:^(id responseObject) {
        self.tableView.hidden = false;
        [self.filedSearchResult removeAllObjects];
        [self.filedSearchResult addObjectsFromArray:[responseObject objectForKey:@"tips"]];
        if(self.filedSearchResult.count==0){
            self.tableView.hidden = true;
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            self.tableView.hidden = true;
        }
    }];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
    //tableView消失
    self.tableView.hidden = true;
    //键盘消失
    [self.view endEditing:true];
    //清空地图上的路线和点
    [self.mapManager removeMapAllAnnotations];
    [self.mapManager removeMapAllOverlays];
    
    //设置搜索框的内容为选中的tableView
    self.searchField.text = [[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"name"];
    
    NSString *address = [[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"address"];
    NSString *location = [[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"location"];
    NSArray *arr = [location componentsSeparatedByString:@","];
    CGFloat desLat = ((NSString *)arr[1]).floatValue;
    CGFloat desLon = ((NSString *)arr[0]).floatValue;
    
    //搜索Driver路线
    [self.mapManager searchDriverLine:desLat desLon:desLon isWithStartAndEndImg:true];
    
    //设置地图中心点为目标点 并设置地图缩放比例
    [self.mapManager setMapCenter:desLat centerLon:desLon zoomLevel:17];
    
    //搜索目标周围的停车点
    AMapGeoPoint *aMapGeoPoint = [[AMapGeoPoint alloc] init];
    aMapGeoPoint.latitude = desLat;
    aMapGeoPoint.longitude = desLon;
    [self searchAroundParking:aMapGeoPoint address:address];
    
    
}

/* 绘制线时的回调 此方法可以设置线的颜色和样式 */
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id <MAOverlay>)overlay{
    NSLog(@"mapView");
    if ([overlay isKindOfClass:[MAPolyline class]]){
        MAPolylineRenderer *polylineRenderer = [[MAPolylineRenderer alloc] initWithPolyline:overlay];
        //设置线的宽度
        polylineRenderer.lineWidth    = 8.f;
        //设置线的颜色
        polylineRenderer.strokeColor  = [UIColor blueColor];
        polylineRenderer.lineJoinType = kMALineJoinRound;
        polylineRenderer.lineCapType  = kMALineCapRound;
        
        //将轨迹设置为自定义的样式
        //        [polylineRenderer loadStrokeTextureImage:[UIImage imageNamed:@"map_history"]];
        
        
        return polylineRenderer;
    }
    return nil;
}

/* 路径规划搜索回调. 根据结果集在地图上画出路线 */
- (void)onRouteSearchDone:(AMapRouteSearchBaseRequest *)request response:(AMapRouteSearchResponse *)response{
    NSLog(@"onRouteSearchDone");
    if (response.route == nil){
        return;
    }
    if (response.count > 0){
        MANaviAnnotationType type = MANaviAnnotationTypeDrive;
        
        //在地图上绘制出行车路线
        MANaviRoute *naviRoute = [MANaviRoute naviRouteForPath:response.route.paths[0] withNaviType:type showTraffic:YES startPoint:[AMapGeoPoint locationWithLatitude:self.mapManager.startCoor.latitude longitude:self.mapManager.startCoor.longitude] endPoint:[AMapGeoPoint locationWithLatitude:self.mapManager.destinationCoor.latitude longitude:self.mapManager.destinationCoor.longitude]];
        [naviRoute addToMapView:self.mapManager.mapView];
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.filedSearchResult.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"MapViewTablecell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *parameters = [self.filedSearchResult objectAtIndex:indexPath.row];
    
    UILabel *lable = [cell viewWithTag:1];
    lable.text = [parameters objectForKey:@"name"];
    return  cell;
}




#pragma mark 周边搜索回调
-(void)onPOISearchDone:(AMapPOISearchBaseRequest *)request response:(AMapPOISearchResponse *)response{
    NSLog(@"返回结果");
    
    if (response.pois.count>0) {
        if(self.filedSearchResult==nil){
            self.filedSearchResult = [NSMutableArray new];
        }else{
            [self.filedSearchResult removeAllObjects];
        }
        NSMutableArray *searchResultArr = [response.pois mutableCopy];
        //        NSLog(@"%@",self.dataArray);
        dispatch_async(dispatch_get_main_queue(), ^{
            //            [_mapView setZoomLevel:13.1 animated:YES];
            for (int i = 0; i < searchResultArr.count; i++) {
                AMapPOI *poi = searchResultArr[i];
                [self.filedSearchResult addObject:poi.name];
                //                    NSLog(@"%@",[NSString stringWithFormat:@"%@\nPOI: %@,%@", poi.description, poi.name, poi.address]);
            }
            [self.tableView setHidden:NO];
            [self.tableView reloadData];
        });
        
    }else{
        NSLog(@"搜索结果个数为0");
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
