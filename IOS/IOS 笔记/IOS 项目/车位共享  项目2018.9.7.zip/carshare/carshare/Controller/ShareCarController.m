//
//  ShareCarController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/8.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "ShareCarController.h"
#import "AFNetworking.h"
#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#import <MJRefresh.h>
#import "PickViewFactory.h"
#import "DialogFactory.h"
#import "URLAndParmFactory.h"
#import "Constants.h"
#import "ModifyShareParkingController.h"

@interface ShareCarController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic , strong) NSMutableArray *data;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ShareCarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(modifyparkingSuccess) name:@"modifyparking" object:nil];
    
    self.tableView.emptyDataSetSource = self;
    self.tableView.emptyDataSetDelegate = self;
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    self.data = [[NSMutableArray alloc]init];
    
    [self addTableViewHeader];
    
    [self showLoadingView:self.tableView];
    [self onRefresh];
}

- (void)modifyparkingSuccess {
    NSLog(@"收到修改车位通知");
    [self onRefresh];
}

- (void)onRefresh{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    
    NSString *url = nil;
    if ([userType isEqualToString:@"0"]) {
        url = [URLAndParmFactory makeUserparkingURL:userCd];
    } else {
        url = [URLAndParmFactory makePropertyparkingURL:userCd];
    }
    
    [manager httpRequest:self url:url success:^(id responseObject) {
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:responseObject];
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
    
}

#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    NSLog(@"buttonEvent");
    [self.tableView reloadEmptyDataSet];
    [self onRefresh];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
    NSLog(@"1");
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.data.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"ShareCarViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    
    //默认点tableCell中有textLable imageView deta控件
    UIImageView *iv_img = [cell viewWithTag:0];
    UILabel *tv_item_title = [cell viewWithTag:1];
    UILabel *tv_type = [cell viewWithTag:2];
    UILabel *tv_yzAddress = [cell viewWithTag:3];
    UILabel *tv_typeSp = [cell viewWithTag:4];
    UILabel *tv_typeBus = [cell viewWithTag:5];
    UILabel *tv_times = [cell viewWithTag:6];
    UIButton *tv_phone = [cell viewWithTag:7];
    UIButton *tv_55 = [cell viewWithTag:8];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    if ([userType isEqualToString:@"0"]) {
        //        String url = NetAPI.USE_RSERVICE_NAME + NetAPI.METHOD_NAME_TX + "/" + list.get(i).getPropertyUserCd();
        //        Glide.with(context).load(url).diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).placeholder(R.drawable.ic_icon).into(houdle.iv_item_img);
        tv_item_title.text = [parameters objectForKey: @"propertyName"];
        tv_yzAddress.text = [NSString stringWithFormat:@"车位地址：%@",[parameters objectForKey: @"unitName"]];
        [tv_phone setTitle:@"联系物业" forState:nil];
    } else {
        //        String url = NetAPI.USE_RSERVICE_NAME + NetAPI.METHOD_NAME_TX + "/" + list.get(i).getUserCd();
        //        Glide.with(context).load(url).diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).placeholder(R.drawable.ic_icon).into(houdle.iv_item_img);
        tv_item_title.text = [parameters objectForKey: @"userName"];
        tv_yzAddress.text = [NSString stringWithFormat:@"业主地址：%@",[parameters objectForKey: @"unitName"]];
        [tv_phone setTitle:@"联系业主" forState:nil];
    }
    tv_phone.tag = indexPath.row;
    tv_55.tag = indexPath.row;
    //    [tv_phone addTarget:s zelf action:@selector(callPhone) forControlEvents:UIControlEventTouchDown];
    //    [tv_55 addTarget:self action:@selector(moredell) forControlEvents:UIControlEventTouchDown];
    tv_type.text = [parameters objectForKey: @"shareStatusDisplayName"];
    
    tv_times.text = [NSString stringWithFormat:@"开放时间：%@-%@",[parameters objectForKey: @"startTime"],[parameters objectForKey: @"endTime"]];
    tv_typeSp.text = [NSString stringWithFormat:@"审批状态：%@",[parameters objectForKey: @"allowStatusDisplayName"]];
    tv_typeBus.text = [NSString stringWithFormat:@"共享时间：%@",[parameters objectForKey: @"shareMethodDisplayName"]];
    
    //    houdle.tv_55.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View view) {
    //            onMorelistener.onMore(i);
    //        }
    //    });
    //    houdle.tv_phone.setOnClickListener(new View.OnClickListener() {
    //        @Override
    //        public void onClick(View view) {
    //            onPhonelistener.onPhone(i);
    //        }
    //    });
    //
    
    
    return  cell;
}
- (IBAction)callPhone:(id)sender {
    UIButton *button = (UIButton *)sender;
    UITableViewCell  *cell;
    //    if (iOS7) {
    //        cell = (UITableViewCell *)button.superview.superview;
    //    }else{
    cell = (UITableViewCell *)button.superview.superview;
    //    }
    int row = [self.tableView indexPathForCell:cell].row;　　//row为该button所在
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    NSString *phoneNum = nil;
    if([userType isEqualToString:@"0"]){//普通用户
        phoneNum = [self.data[row] objectForKey:@"propertyPhone"];
    }else{
        phoneNum = [self.data[row] objectForKey:@"userPhone"];
    }
    //    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",phoneNum];
    //    UIWebView * callWebview = [[UIWebView alloc] init];
    //    [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    //    [self.view addSubview:callWebview];
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"telprompt:%@",phoneNum];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}


- (IBAction)moreDell:(id)sender {
    UIButton *button = (UIButton *)sender;
    UITableViewCell  *cell;
    //    if (iOS7) {
    //        cell = (UITableViewCell *)button.superview.superview;
    //    }else{
    cell = (UITableViewCell *)button.superview.superview;
    //    }
    int row = [self.tableView indexPathForCell:cell].row;　　//row为该button所在
    NSLog(@"%d", row);
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    if([userType isEqualToString:@"2"]){
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"审核是否通过" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }]];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"同意" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *userCd = [userDefaults objectForKey:@"userCd"];
            
            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
            [manager httpRequest:self url:agreeparking_URL parameters:[URLAndParmFactory makeAgreeParkingParm:userCd :[[self.data[row] objectForKey:@"Id"] stringValue]] success:^(id responseObject) {
                [self onRefresh];
            } onFinish:^(BOOL isError, NSString *errorMsg) {
                if (isError) {
                    [DialogFactory showTipsInCenter:self.view withText:errorMsg];
                }
            }];
        }]];
        
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"拒绝" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *userCd = [userDefaults objectForKey:@"userCd"];
            
            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
            [manager httpRequest:self url:refuseparking_URL parameters:[URLAndParmFactory makeRefuseParkingParm:userCd :[[self.data[row] objectForKey:@"Id"] stringValue]] success:^(id responseObject) {
                [self onRefresh];
            } onFinish:^(BOOL isError, NSString *errorMsg) {
                if (isError) {
                    [DialogFactory showTipsInCenter:self.view withText:errorMsg];
                }
            }];
        }]];
        
        
        // 由于它是一个控制器 直接modal出来就好了
        [self presentViewController:alertController animated:YES completion:nil];
    }else{
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }]];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"修改" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            ModifyShareParkingController *controller = [ModifyShareParkingController new];
            controller.pageDic = self.data[row];
            [self.navigationController pushViewController:controller animated:YES];
        }]];
        
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *userCd = [userDefaults objectForKey:@"userCd"];
            
            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
            [manager httpRequest:self url:deleteparking_URL parameters:[URLAndParmFactory makeDeleteParkingParm:[[self.data[row] objectForKey:@"Id"] stringValue]] success:^(id responseObject) {
                [self onRefresh];
            } onFinish:^(BOOL isError, NSString *errorMsg) {
                if (isError) {
                    [DialogFactory showTipsInCenter:self.view withText:errorMsg];
                }
            }];
        }]];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"停止分享" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *userCd = [userDefaults objectForKey:@"userCd"];
            
            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
            [manager httpRequest:self url:pauseparking_URL parameters:[URLAndParmFactory makePapuseParkingParm:userCd :[[self.data[row] objectForKey:@"Id"] stringValue]] success:^(id responseObject) {
                [self onRefresh];
            } onFinish:^(BOOL isError, NSString *errorMsg) {
                if (isError) {
                    [DialogFactory showTipsInCenter:self.view withText:errorMsg];
                }
            }];
        }]];
        
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"继续分享" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *userCd = [userDefaults objectForKey:@"userCd"];
            
            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
            [manager httpRequest:self url:restartparking_URL parameters:[URLAndParmFactory makeRestartParkingParm:userCd :[[self.data[row] objectForKey:@"Id"] stringValue]] success:^(id responseObject) {
                [self onRefresh];
            } onFinish:^(BOOL isError, NSString *errorMsg) {
                if (isError) {
                    [DialogFactory showTipsInCenter:self.view withText:errorMsg];
                }
            }];
            
            
        }]];
        
        // 由于它是一个控制器 直接modal出来就好了
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}


@end

