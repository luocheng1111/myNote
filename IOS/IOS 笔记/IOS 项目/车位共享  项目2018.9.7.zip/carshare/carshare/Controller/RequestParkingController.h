//
//  TestViewController.h
//  BRPickerViewDemo
//
//  Created by 罗成 on 2017/8/11.
//  Copyright © 2017年 91renb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RequestParkingController : UIViewController

@property (nonatomic , strong) NSDictionary *selectorDic;

@end

