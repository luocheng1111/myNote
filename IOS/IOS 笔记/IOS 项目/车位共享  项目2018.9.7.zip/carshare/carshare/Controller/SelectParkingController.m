//
//  SelectParkingController.m
//  carshare
//
//  Created by 森虹 on 2018/7/17.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "SelectParkingController.h"
#import "AFNetworking.h"
#import "Constants.h"
#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import <MJRefresh.h>
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#import "Constants.h"
#import "DialogFactory.h"
#import "RequestParkingController.h"

@interface SelectParkingController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic , strong) NSMutableArray *data;

@end

@implementation SelectParkingController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"pageType: %@", _pageType);
    
    
    //    self.tableView.emptyDataSetSource = self;
    //    self.tableView.emptyDataSetDelegate = self;
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    self.data = [[NSMutableArray alloc]init];
    
    
    
    [self showLoadingView:self.tableView];
    
    if([self.pageDic objectForKey:@"parkings"] != nil){
        
        if([self.pageType isEqualToString:@"One"]){
            [self.data addObjectsFromArray:[self.pageDic objectForKey:@"parkingsOfProperty"]];
        }else if([self.pageType isEqualToString:@"Two"]){
            [self.data addObjectsFromArray:[self.pageDic objectForKey:@"parkings"]];
        }else{
            [self.data addObjectsFromArray:[self.pageDic objectForKey:@"poises"]];
        }
        if(self.data.count==0){
            [self showEmptyView:self.tableView withString:@"没有车位"];
            self.isEmptyViewClick = false;
            
        }
        [self.tableView reloadData];
    }else{
        [self addTableViewHeader];
        [self onRefresh];
    }
    
    
}



- (void)onRefresh {
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    
    NSString *url =  SEARCHCHSABLE_URL;
    
    NSDictionary *params = [URLAndParmFactory makeSelectParkingParm:userCd city:[self.pageDic objectForKey:@"city"] address:[self.pageDic objectForKey:@"address"] location:[self.pageDic objectForKey:@"location"] starttime:[NSString stringWithFormat:@"%@:00", [self.pageDic objectForKey:@"starttime"]] overtime:[self.pageDic objectForKey:@"overtime"]];
    
    [manager httpRequest:self url:url parameters:params success:^(id responseObject) {
        [self.data removeAllObjects];
        if([self.pageType isEqualToString:@"One"]){
            [self.data addObjectsFromArray:[(NSDictionary*)responseObject objectForKey:@"parkingsOfProperty"]];
        }else if([self.pageType isEqualToString:@"Two"]){
            [self.data addObjectsFromArray:[(NSDictionary*)responseObject objectForKey:@"parkings"]];
        }else{
            [self.data addObjectsFromArray:[(NSDictionary*)responseObject objectForKey:@"poises"]];
        }
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
    
    
}

#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    NSLog(@"buttonEvent");
    [self.tableView reloadEmptyDataSet];
    [self onRefresh];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
    if([self.pageType isEqualToString:@"Three"]){
        [DialogFactory showTwoBtnDialog:self withTitle:nil withMsg:@"是否跳到导航？" isCancelable:false btn1Text:@"否" btn2Text:@"是" handle1:^(UIAlertAction *action) {
            
        } handle2:^(UIAlertAction *action) {
            
        }];
        return;
    }
    
    NSDictionary *dic =  _data[indexPath.row];
    
    //地图页面进来的
    if([self.pageDic objectForKey:@"parkings"] != nil){
        
        NSMutableDictionary *selectData1 = [NSMutableDictionary new];
        [selectData1 setValue:dic forKey:@"pio"];
        if([self.pageType isEqualToString:@"One"]){
            [selectData1 setValue:@"小区车位" forKey:@"title"];
        }else{
            [selectData1 setValue:@"个人车位" forKey:@"title"];
        }
        
        if([dic objectForKey:@"unitName"]!=nil){
            [selectData1 setValue:[NSString stringWithFormat:@"%@%@车位",[dic objectForKey:@"propertyName"],[dic objectForKey:@"unitName"]] forKey:@"busname"];
        }else{
            [selectData1 setValue:[NSString stringWithFormat:@"%@车位",[dic objectForKey:@"propertyName"]] forKey:@"busname"];
        }
        
        RequestParkingController *controller = [RequestParkingController new];
        controller.selectorDic = selectData1;
        [self.navigationController pushViewController:controller animated:YES];
        return;
    }else{
        
        NSMutableDictionary *selectData = [NSMutableDictionary new];
        NSLog(@"--- %@", dic);
        NSString *location = [NSString stringWithFormat:@"%@,%@",[dic objectForKey:@"latitude"],[dic objectForKey:@"longitude"]];
        [selectData setValue:location forKey:@"location"];
        if ([dic objectForKey:@"propertyName"]!=nil){
            if([dic objectForKey:@"unitName"]!=nil){
                [selectData setValue:[NSString stringWithFormat:@"%@%@车位",[dic objectForKey:@"propertyName"],[dic objectForKey:@"unitName"]] forKey:@"name"];
            }else{
                [selectData setValue:[NSString stringWithFormat:@"%@车位",[dic objectForKey:@"propertyName"]] forKey:@"name"];
            }
            
        }else {
            [selectData setValue:[dic objectForKey:@"name"] forKey:@"name"];
            
        }
        [selectData setValue:[[dic objectForKey:@"price"] stringValue] forKey:@"price"];
        [selectData setValue:[[dic objectForKey:@"id"] stringValue] forKey:@"id"];
        [selectData setValue:[[dic objectForKey:@"distance"] stringValue] forKey:@"distance"];
        if([self.pageType isEqualToString:@"One"]){
            [selectData setValue:@"小区车位" forKey:@"title"];
        }else{
            [selectData setValue:@"个人车位" forKey:@"title"];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:@"selectParking" object:self userInfo:selectData];
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"数量：%ld", _data.count);
    return _data.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 90;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"SelectParkingCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    
    UILabel *lable1 = [cell viewWithTag:1];
    UILabel *lable2 = [cell viewWithTag:2];
    UILabel *lable3 = [cell viewWithTag:3];
    UILabel *lable4 = [cell viewWithTag:4];
    
    if([self.pageType isEqualToString:@"One"]){
        lable1.text = [parameters objectForKey: @"propertyName"];
        lable2.text = [NSString stringWithFormat:@"%@元/小时",[[parameters objectForKey: @"price"] stringValue]] ;
        lable3.text = [NSString stringWithFormat:@"地址：%@米",[parameters objectForKey: @"addressLine"]];;
        
    }else if([self.pageType isEqualToString:@"Two"]){
        lable1.text = [parameters objectForKey: @"propertyName"];
        lable2.text = [NSString stringWithFormat:@"%@元/小时",[[parameters objectForKey: @"price"] stringValue]] ;
        lable3.text = [NSString stringWithFormat:@"地址：%@米",[parameters objectForKey: @"addressLine"]];;
    }else{
        lable1.text = [parameters objectForKey: @"name"];
        lable2.text = nil;
        lable3.text = [NSString stringWithFormat:@"地址：%@米",[parameters objectForKey: @"address"]];;
    }
    
    lable4.text = [NSString stringWithFormat:@"距离目的地：%@米",[parameters objectForKey: @"distance"]];
    return  cell;
}



- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}

@end

