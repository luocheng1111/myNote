//
//  LoginController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/4.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "LoginController.h"
#import "AFNetworking.h"
#import "RequestParkingController.h"
#import "StringHelper.h"
#import "DialogFactory.h"
//#import "ZFScanViewController.h"

@interface LoginController ()
@property (weak, nonatomic) IBOutlet UITextField *usernameEt;
@property (weak, nonatomic) IBOutlet UITextField *passwordEt;
@property (nonatomic, assign) BOOL isUserLogin;
@property (weak, nonatomic) IBOutlet UILabel *userLoginTitleTv;
@property (weak, nonatomic) IBOutlet UIImageView *userLoginTitleLineTv;
@property (weak, nonatomic) IBOutlet UILabel *phoneLoginTitleTv;
@property (weak, nonatomic) IBOutlet UIImageView *phoneLoginLineTv;
@property (weak, nonatomic) IBOutlet UIButton *getPhoneCodeBt;

@end

@implementation LoginController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.isUserLogin = YES;
    
    // 1. 创建一个点击事件，点击时触发labelClick方法
    UITapGestureRecognizer *labelTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(titleClick:)];
    [self.phoneLoginTitleTv addGestureRecognizer:labelTapGestureRecognizer];
    [self.phoneLoginLineTv addGestureRecognizer:labelTapGestureRecognizer];
}


- (void)titleClick:(UIView *)view {
    
}


- (IBAction)btnLogin:(id)sender {
    NSLog(@"按钮1松开！");
    
   
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":@"123456",
                           @"userCd":@"15103743307"
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        //        NSString *str = responseObject;
        //        NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
        //
        //        id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults setValue:[dic objectForKey:@"ShareUser"] forKeyPath:@"ShareUser"];
            [userDefaults synchronize];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
            //            [self.navigationController popViewControllerAnimated:YES];
        }
        //        if ([jsonObj isKindOfClass:[NSArray class]]){
        //
        //        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
    
}

- (IBAction)register:(id)sender {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":@"parking",
                           @"userCd":@"tth"
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults setValue:[dic objectForKey:@"ShareUser"] forKeyPath:@"ShareUser"];
            [userDefaults synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}
- (IBAction)wuye:(id)sender {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":@"123456",
                           @"userCd":@"15000000002"
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        //        NSString *str = responseObject;
        //        NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
        //
        //        id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults setValue:[dic objectForKey:@"ShareUser"] forKeyPath:@"ShareUser"];
            [userDefaults synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        //        if ([jsonObj isKindOfClass:[NSArray class]]){
        //
        //        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}
- (IBAction)qiye:(id)sender {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":@"123456",
                           @"userCd":@"15000000001"
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        //        NSString *str = responseObject;
        //        NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
        //
        //        id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults setValue:[dic objectForKey:@"ShareUser"] forKeyPath:@"ShareUser"];
            [userDefaults synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        //        if ([jsonObj isKindOfClass:[NSArray class]]){
        //
        //        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}
- (IBAction)person2:(id)sender {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":@"123456",
                           @"userCd":@"15103743308"
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        //        NSString *str = responseObject;
        //        NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
        //
        //        id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        //        if ([jsonObj isKindOfClass:[NSArray class]]){
        //
        //        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}



- (void)loginRequestWithDeviceToken:(NSString*) str  withUserName:(NSString*) userName  withPassword:(NSString*) password{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSDictionary *dict = @{
                           @"deviceOS":@"IOS",
                           @"deviceToken":@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH",
                           @"id":@"",
                           @"password":password,
                           @"userCd":userName
                           };
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager POST:@"http://202.96.207.14:8080/tthparking/webresources/user/login" parameters:dict progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功 === %@",responseObject);
        //        NSString *str = responseObject;
        //        NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
        //
        //        id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
        if([responseObject isKindOfClass:[NSDictionary class]]){
            //字典类型
            NSDictionary *dic = (NSDictionary*)responseObject;
            NSLog(@"%@, %@ ", [dic objectForKey:@"accessToken"],[dic objectForKey:@"userCd"]);
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setValue:[dic objectForKey:@"kindOfUser"] forKeyPath:@"kindOfUser"];
            [userDefaults setValue:[dic objectForKey:@"userCd"] forKeyPath:@"userCd"];
            [userDefaults setValue:[dic objectForKey:@"accessToken"] forKeyPath:@"accessToken"];
            [userDefaults synchronize];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":[dic objectForKey:@"kindOfUser"], @"ShareUser":[dic objectForKey:@"ShareUser"]}];
            [self dismissViewControllerAnimated:YES completion:nil];
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
    
}

- (IBAction)requestparking:(id)sender {
    RequestParkingController *controller = [RequestParkingController new];
    [self.navigationController pushViewController:controller animated:YES];
    //    ZFScanViewController * vc = [[ZFScanViewController alloc] init];
    //    vc.returnScanBarCodeValue = ^(NSString * barCodeString){
    ////        self.resultLabel.text = [NSString stringWithFormat:@"扫描结果:\n%@",barCodeString];
    //        NSLog(@"扫描结果的字符串======%@",barCodeString);
    //    };
    //
    //    [self presentViewController:vc animated:YES completion:nil];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

+ (void)Go:(UIViewController *)viewController{
    LoginController *controller = [viewController.storyboard instantiateViewControllerWithIdentifier:@"LoginController"];
    //        [viewController.navigationController pushViewController:controller animated:YES];
    [viewController presentViewController:controller  animated:YES completion:nil];
    
}

- (IBAction)loginBtn:(id)sender {
    if ([StringHelper isEmpty:self.usernameEt.text]) {
        [DialogFactory showTipsInCenter:self.view withText:@"请输入账号/手机号"];
        return;
    }
    if ([StringHelper isEmpty:self.passwordEt.text]) {
        [DialogFactory showTipsInCenter:self.view withText:@"请输入密码/验证码"];
        return;
    }
    if (self.isUserLogin==YES) { //账户名密码登录
        [self loginRequestWithDeviceToken:@"AkBwvC1DAuM1STLlu9HuiyxeApjRb2GJjnvU9rH" withUserName:self.usernameEt.text withPassword:self.passwordEt.text];
    } else { //手机号登录
//        String json = new Gson().toJson(new Login(username,"ANDROID", UserInfo.getDeviceToken(this), verif.getVerificationCode()));
//        Log.e("登录请求——————", json);
//        httpPost(this, NetAPI.METHOD_NAME_VERIF_LOGIN, json, handler, 0);
    }
}

- (IBAction)getPhoneCodeBt:(id)sender {
    
}

@end

