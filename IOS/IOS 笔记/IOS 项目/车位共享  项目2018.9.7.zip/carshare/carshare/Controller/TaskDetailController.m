//
//  TaskDetailController.m
//  carshare
//
//  Created by 森虹 on 2018/7/26.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "TaskDetailController.h"
#import "Constants.h"
#import "URLAndParmFactory.h"
#import "AFNetworkingHelper.h"
#import "DialogFactory.h"
#import "BRInfoCell.h"
#import "BRInfoModel.h"
#import "PickViewFactory.h"
#import "URLAndParmFactory.h"
//#import "ZFScanViewController.h"


@interface TaskDetailController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSArray *msgArr;
@property (nonatomic , strong) NSMutableDictionary *data;
@property (nonatomic) BOOL isFavorite;
@property (weak, nonatomic) IBOutlet UIButton *leftBtn;
@property (weak, nonatomic) IBOutlet UIButton *rightBtn;
@property (weak, nonatomic) IBOutlet UIButton *centerBtn;

@property (nonatomic, strong) NSString *id;

@end

@implementation TaskDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.data = [[NSMutableArray alloc]init];

    self.textView.hidden=true;
    self.leftBtn.hidden=true;
    self.rightBtn.hidden=true;
    self.centerBtn.hidden=true;
    [self.rightBtn setEnabled:false];
    
    if ([_pageType isEqualToString:@"Request"]){
        self.leftBtn.hidden=false;
        self.rightBtn.hidden=false;
    }else if([_pageType isEqualToString:@"Making"]){
        self.leftBtn.hidden=false;
        self.rightBtn.hidden=false;
        [self.rightBtn setTitle:@"结束" forState:nil];
        [self.leftBtn setEnabled:false];
        [self.rightBtn setEnabled:true];
    }else if([_pageType isEqualToString:@"WaitPay"]){
        self.centerBtn.hidden=false;
        [self.centerBtn setTitle:@"去支付" forState:nil];
    }else if([_pageType isEqualToString:@"History"]){
        self.centerBtn.hidden=false;
    }
    
    [self onRefresh];
}


- (void)onRefresh {
    NSString *url = nil;
    if ([_pageType isEqualToString:@"Request"]){
        url = [URLAndParmFactory makeTaskRequestDetailURL:self.id = [self.pageDic objectForKey:@"id"]];
    }else if([_pageType isEqualToString:@"Making"]){
        url = [URLAndParmFactory makeTaskMakingDetailURL:self.id = [self.pageDic objectForKey:@"id"]];
    }else if([_pageType isEqualToString:@"WaitPay"]){
        NSLog(@"pageDic:%@", _pageDic);
        [self requestMeg:[_pageDic objectForKey:@"id"]];
        _titleArr = [self getTitleArr];
        [self.tableView reloadData];
        return;
    }else if([_pageType isEqualToString:@"History"]){
        url = [URLAndParmFactory makeTaskFinishDetailURL:self.id = [self.pageDic objectForKey:@"requestId"]];
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:url success:^(id responseObject) {
        self.data = responseObject;
        if([self.data objectForKey:@"favorite"]==nil){
            NSLog(@"未收藏");
            self.isFavorite = false;
        }else{
            NSLog(@"已收藏");
            self.isFavorite = true;
        }
        [self requestMeg:[self.data objectForKey:@"id"]];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [DialogFactory showInfoTip:errorMsg];
            [self.data removeAllObjects];
        }
        if(self.data.count>0){
            _titleArr = [self getTitleArr];
        }
        [self.tableView reloadData];
    }];
}


- (void)requestMeg:(NSString *)reqestId {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:[URLAndParmFactory makeGetMsgURL:userCd requestId:reqestId] success:^(id responseObject) {
        self.msgArr = responseObject;
        NSMutableString *contents = [NSMutableString new];
        if(self.msgArr.count>0){
            self.textView.hidden=false;
            for (int i=0; i<self.msgArr.count; i++) {
                NSDictionary *dic = self.msgArr[i];
                [contents appendString:[dic objectForKey:@"msgContents"]];
            }
            
            [self.textView setText: contents];
        }else{
            self.textView.hidden=true;
        }
        
    } onFinish:^(BOOL isError, NSString *errorMsg) {
       
    }];
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.titleArr.count;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"BRInfoCell";
    BRInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[BRInfoCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
//    if(self.data.count<=0) return nil;
    
    cell.titleLabel.text = self.titleArr[indexPath.row];
    cell.textField.tag = indexPath.row;
    cell.isNeed = NO;
    cell.isNext = NO;
    
    if([_pageType isEqualToString:@"WaitPay"]){
        switch (indexPath.row) {
            case 0:{
                cell.textField.text = [self.pageDic objectForKey:@"addressLine"];
            }
                break;
            case 1:{
                cell.textField.text = [self.pageDic objectForKey:@"licensePlate"];
            }
                break;
            case 2:{
                NSString *payStatus = [self.pageDic objectForKey:@"payStatus"];
                if([payStatus isEqualToString:@"1"]){
                    cell.textField.text = @"任务进行中";
                    [self.centerBtn setEnabled:false];
                }else if([payStatus isEqualToString:@"2"]){
                    cell.textField.text = @"未支付";
                }else{
                    cell.textField.text = @"余额不足";
                }
                
            }
                break;
            case 3:{
                cell.textField.text = [self.pageDic objectForKey:@"startDateTimeDisplay"];
            }
                break;
            case 4:{
                cell.textField.text = [self.pageDic objectForKey:@"planEndDateTimeDisplay"]==nil ? @"任务未结束" : [self.pageDic objectForKey:@"planEndDateTimeDisplay"];
            }
                break;
            case 5:{
                cell.textField.text = [NSString stringWithFormat:@"%@%@", [self.pageDic objectForKey:@"amount"], @"元"];
            }
            case 6:{
                NSLog(@"--- %@", [self.pageDic objectForKey:@"paidAmount"]);
                cell.textField.text = [NSString stringWithFormat:@"%@%@", [self.pageDic objectForKey:@"paidAmount"], @"元"];
            }
            case 7:{
                cell.textField.text = [NSString stringWithFormat:@"%@%@", [self.pageDic objectForKey:@"remainderAmount"], @"元"];
            }
                break;
        }
    }else{
    switch (indexPath.row) {
        case 0:{
            if([_pageType isEqualToString:@"Making"]){
                cell.textField.text = [self.data objectForKey:@"parkingDisplayName"];
            }else{
                cell.textField.text = [self.data objectForKey:@"addressLine"];
            }
            
        }
            break;
        case 1:{
            if([_pageType isEqualToString:@"Making"]){
                cell.textField.text = [self.data objectForKey:@"licensePlate"];
            }else{
                cell.textField.text = [self.data objectForKey:@"parkingCode"];
            }
            
        }
            break;
        case 2:{
            if([_pageType isEqualToString:@"Making"]){
                cell.textField.text = [self getStatusStr:[self.data objectForKey:@"status"]];
            }else{
                cell.textField.text = [self.data objectForKey:@"licensePlate"];
            }
        }
            break;
        case 3:{
            if([_pageType isEqualToString:@"Making"]){
                if([[self.data objectForKey:@"status"] isEqualToString:@"5"] || [[self.data objectForKey:@"status"] isEqualToString:@"6"]){
                    cell.isRightBtn = YES;
                    [cell.rightBtn setTitle:@"缩短" forState:nil];
                    [cell.rightBtn addTarget:self action:@selector(shortBtnClick) forControlEvents:UIControlEventTouchDown];
                }
                
                cell.textField.text = [self.data objectForKey:@"startDateTimeDisplay"];
            }else{
                cell.textField.text = [self getStatusStr:[self.data objectForKey:@"status"]];
            }
        }
            break;
        case 4:{
            if([_pageType isEqualToString:@"Making"]){
                if([[self.data objectForKey:@"status"] isEqualToString:@"5"] || [[self.data objectForKey:@"status"] isEqualToString:@"6"]){
                    cell.isRightBtn = YES;
                    [cell.rightBtn setTitle:@"延长" forState:nil];
                    [cell.rightBtn addTarget:self action:@selector(delayBtnClick) forControlEvents:UIControlEventTouchDown];
                }
                cell.textField.text = [self.data objectForKey:@"planEndDateTimeDisplay"];
            }else{
                if([_pageType isEqualToString:@"Request"] && [[self.data objectForKey:@"status"] isEqualToString:@"5"]){
                    cell.isRightBtn = YES;
                    [cell.rightBtn setTitle:@"缩短" forState:nil];
                    [cell.rightBtn addTarget:self action:@selector(shortBtnClick) forControlEvents:UIControlEventTouchDown];
                }
                cell.textField.text = [self.data objectForKey:@"startDateTimeDisplay"];
            }
            
        }
            break;
        case 5:{
            if([_pageType isEqualToString:@"Making"]){
                cell.textField.text = [NSString stringWithFormat:@"¥%@元",  [self.data objectForKey:@"price"]];
            }else{
                if([_pageType isEqualToString:@"Request"] && [[self.data objectForKey:@"status"] isEqualToString:@"5"]){
                    cell.isRightBtn = YES;
                    [cell.rightBtn setTitle:@"延长" forState:nil];
                    [cell.rightBtn addTarget:self action:@selector(delayBtnClick) forControlEvents:UIControlEventTouchDown];
                }
                cell.textField.text = [self.data objectForKey:@"endDateTimeDisplay"];
            }
           
        }
            break;
    }
    }
    return cell;

}

- (NSString*)getStatusStr:(NSString*) statusStr{
    int status = [statusStr intValue];
    NSString *str = nil;
    switch (status) {
        case 0:
            str = @"抢单中";
            break;
        case 1:
            str = @"请求中";
            break;
        case 2:
            str = @"已同意";
            [self.rightBtn setEnabled:true];
            break;
        case 3:
            str = @"被拒绝";
            break;
        case 4:
            str = @"已取消";
            [self.leftBtn setEnabled:true];
            break;
        case 5:
            str = @"已确认";
            [self.leftBtn setEnabled:true];
            [self.rightBtn setEnabled:true];
            [self.rightBtn setTitle:@"开始" forState:nil];
            break;
        case 6:
            str = @"任务进行中";
            break;
        case 7:
            str = @"被强制拒绝";
            break;
        case 8:
            str = @"已强制取消";
            break;
        case 9:
            str = @"任务已结束";
            break;
    }
    return str;
}

- (NSArray *)getTitleArr {
    if (!_titleArr) {
        if([_pageType isEqualToString:@"WaitPay"]){
            _titleArr = @[@"车位地址：", @"车牌号码：", @"请求状态：", @"开始时间：", @"结束时间：", @"计时费用：", @"支付费用：", @"剩余费用："];
        }else if([_pageType isEqualToString:@"Making"]){
            _titleArr = @[@"车位地址：", @"车牌号码：", @"请求状态：", @"开始时间：", @"结束时间：", @"计时用费："];
        }else{
            _titleArr = @[@"车位地址：", @"车位编号：", @"车牌号码：", @"请求状态：", @"开始时间：", @"结束时间："];
        }
    }
    return _titleArr;
}

- (IBAction)leftBtnClick:(id)sender {
    [DialogFactory showTwoBtnDialog:self withTitle:nil withMsg:@"您确认取消此任务吗？" isCancelable:true btn1Text:@"取消" btn2Text:@"确认" handle1:^(UIAlertAction *action) {
        
    }handle2:^(UIAlertAction *action) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *userCd = [userDefaults objectForKey:@"userCd"];
        
        AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
        [manager httpRequest:self url:CANCEL_URL parameters:[URLAndParmFactory makeTaskCancelParm:userCd :self.id] success:^(id responseObject) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"TaskStatusUpdate" object:self userInfo:nil];
            [self.navigationController popViewControllerAnimated:YES];
        } onFinish:^(BOOL isError, NSString *errorMsg) {
            if (isError) {
                [DialogFactory showTipsInCenter:self.view withText:errorMsg];
            }
            
           
        }];
    }];
}

-(void) shortBtnClick{
    [PickViewFactory showOneItemPickView:@"选择时间 单位：分钟" defaultValue:nil dataSource:@[@"15", @"30", @"60"] resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *userCd = [userDefaults objectForKey:@"userCd"];
        
        AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
        NSString *requestId = nil;
        if([[self.data objectForKey:@"status"] isEqualToString:@"6"]){
            requestId = [self.data objectForKey:@"requestId"];
        } else {
            requestId = [self.data objectForKey:@"id"];
        }
        
        [manager httpRequest:self url:requestshorten_URL parameters:[URLAndParmFactory makeDelayOrShortParm:userCd :requestId :selectValue] success:^(id responseObject) {
            [self onRefresh];
        } onFinish:^(BOOL isError, NSString *errorMsg) {
            if (isError) {
                [DialogFactory showInfoTip:errorMsg];
            }
        }];
    }];
}

-(void) delayBtnClick{
    [PickViewFactory showOneItemPickView:@"选择时间 单位：分钟" defaultValue:nil dataSource:@[@"15", @"30", @"60"] resultBlock:^(NSString *selectValue) {
        NSLog(@"%@", selectValue);
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *userCd = [userDefaults objectForKey:@"userCd"];
        
        AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
        NSString *requestId = nil;
        if([[self.data objectForKey:@"status"] isEqualToString:@"6"]){
            requestId = [self.data objectForKey:@"requestId"];
        } else {
            requestId = [self.data objectForKey:@"id"];
        }
        
        [manager httpRequest:self url:requestextend_URL parameters:[URLAndParmFactory makeDelayOrShortParm:userCd :requestId :selectValue] success:^(id responseObject) {
            [self onRefresh];
        } onFinish:^(BOOL isError, NSString *errorMsg) {
            if (isError) {
                [DialogFactory showInfoTip:errorMsg];
            }
        }];
    }];
}

- (IBAction)centerBtnClick:(id)sender {
    
}

- (IBAction)rightBtnClick:(UIButton *)sender{
//    NSLog(@"%@", sender.currentTitle);
    if ([_pageType isEqualToString:@"Request"] && [sender.currentTitle  isEqualToString:@"确认"]){ //确认
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *userCd = [userDefaults objectForKey:@"userCd"];
        
        AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
        NSString *requestId = nil;
        if([[self.data objectForKey:@"status"] isEqualToString:@"6"]){
            requestId = [self.data objectForKey:@"requestId"];
        } else {
            requestId = [self.data objectForKey:@"id"];
        }
        [manager httpRequest:self url:requestconfirm_URL parameters:[URLAndParmFactory makeRequestConfirmParm:userCd :requestId] success:^(id responseObject) {
            NSLog(@"%@", responseObject);
            NSDictionary *result = responseObject;
            NSLog(@"%@", [result objectForKey:@"result"]);
            if([[result objectForKey:@"result"] isEqualToString:@"true"]){
                [self onRefresh];
                [DialogFactory showTwoBtnDialog:self withTitle:nil withMsg:@"是否导航" isCancelable:false btn1Text:@"取消" btn2Text:@"导航" handle1:^(UIAlertAction *action) {
                    NSLog(@"取消");
                } handle2:^(UIAlertAction *action) {
                    NSLog(@"导航");
                }];
            }else{
                 [DialogFactory showInfoTip:[result objectForKey:@"message"]];
            }
        } onFinish:^(BOOL isError, NSString *errorMsg) {
            if (isError) {
                [DialogFactory showInfoTip:errorMsg];
            }
        }];
    }
    
      if ([_pageType isEqualToString:@"Request"] && [sender.currentTitle  isEqualToString:@"开始"]){ //确认
//          ZFScanViewController * vc = [[ZFScanViewController alloc] init];
//          vc.returnScanBarCodeValue = ^(NSString * barCodeString){
//              //        self.resultLabel.text = [NSString stringWithFormat:@"扫描结果:\n%@",barCodeString];
//                     NSLog(@"扫描结果的字符串======%@",barCodeString);
//              NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//              NSString *userCd = [userDefaults objectForKey:@"userCd"];
//              AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
//              NSString *requestId = nil;
//              if([[self.data objectForKey:@"status"] isEqualToString:@"6"]){
//                  requestId = [self.data objectForKey:@"requestId"];
//              } else {
//                  requestId = [self.data objectForKey:@"id"];
//              }
//              [manager httpRequest:self url:requestexecute_URL parameters:[URLAndParmFactory makeStartParkingParm:userCd :requestId :barCodeString] success:^(id responseObject) {
//                  NSLog(@"%@", responseObject);
//                  NSDictionary *result = responseObject;
//                  NSLog(@"%@", [result objectForKey:@"result"]);
//                  if([[result objectForKey:@"result"] isEqualToString:@"true"]){
//                      [[NSNotificationCenter defaultCenter] postNotificationName:@"TaskStatusUpdate" object:self userInfo:nil];
//                      [self.navigationController popViewControllerAnimated:YES];
//                  }else{
//                      [DialogFactory showInfoTip:[result objectForKey:@"message"]];
//                  }
//              } onFinish:^(BOOL isError, NSString *errorMsg) {
//                  if (isError) {
//                      [DialogFactory showInfoTip:errorMsg];
//                  }
//              }];
//
//          };
//
//          [self presentViewController:vc animated:YES completion:nil];
      }
    
    if ([_pageType isEqualToString:@"Making"] && [sender.currentTitle  isEqualToString:@"结束"]){ //确认
//        ZFScanViewController * vc = [[ZFScanViewController alloc] init];
//        vc.returnScanBarCodeValue = ^(NSString * barCodeString){
//            //        self.resultLabel.text = [NSString stringWithFormat:@"扫描结果:\n%@",barCodeString];
//            NSLog(@"扫描结果的字符串======%@",barCodeString);
//            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//            NSString *userCd = [userDefaults objectForKey:@"userCd"];
//            AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
//            NSString *requestId = nil;
//            if([[self.data objectForKey:@"status"] isEqualToString:@"6"]){
//                requestId = [self.data objectForKey:@"requestId"];
//            } else {
//                requestId = [self.data objectForKey:@"id"];
//            }
//            [manager httpRequest:self url:requestending_URL parameters:[URLAndParmFactory makeStartParkingParm:userCd :requestId :barCodeString] success:^(id responseObject) {
//                NSLog(@"%@", responseObject);
//                NSDictionary *result = responseObject;
//                NSLog(@"%@", [result objectForKey:@"result"]);
//                if([[result objectForKey:@"payStatus"] isEqualToString:@"3"]){
//                    [[NSNotificationCenter defaultCenter] postNotificationName:@"TaskStatusUpdate" object:self userInfo:nil];
//                    [self.navigationController popViewControllerAnimated:YES];
//                }else{
//                    [DialogFactory showTwoBtnDialog:self withTitle:nil withMsg:@"余额不足！" isCancelable:false btn1Text:@"充值" btn2Text:@"支付" handle1:^(UIAlertAction *action) {
//                        NSLog(@"充值");
//                    } handle2:^(UIAlertAction *action) {
//                        NSLog(@"支付");
//                    }];
//                }
//                
//            } onFinish:^(BOOL isError, NSString *errorMsg) {
//                if (isError) {
//                    [DialogFactory showInfoTip:errorMsg];
//                }
//            }];
//            
//        };
//        
//        [self presentViewController:vc animated:YES completion:nil];
    }
    
  

}

@end
