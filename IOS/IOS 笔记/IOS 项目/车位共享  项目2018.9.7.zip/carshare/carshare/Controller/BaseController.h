//
//  BaseController.h
//  ReplaceTableViewByErrorData
//
//  Created by 森鸿 on 2018/6/12.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseController : UIViewController

@property (nonatomic) BOOL isEmptyViewClick;

- (void)showLoadingView:(UITableView*)tableView;
- (void)showEmptyView:(UITableView*)tableView;
- (void)showEmptyView:(UITableView*)tableView withString:(NSString *)string;
- (void)showNetWorkErrView:(UITableView*)tableView;
- (void)showErrorView:(UITableView*)tableView;;

@end

