//
//  TestViewController.m
//  BRPickerViewDemo
//
//  Created by 任波 on 2017/8/11.
//  Copyright © 2017年 91renb. All rights reserved.
//

#import "RequestParkingController.h"
#import "BRInfoCell.h"
#import "BRInfoModel.h"
#import "PickViewFactory.h"
#import <BRPickerView.h>
#import "ShareController.h"
#import "AFNetworkingHelper.h"
#import "Constants.h"
#import "URLAndParmFactory.h"
#import "AutoFillTextCell.h"
#import "StringHelper.h"
#import "DialogFactory.h"

@interface RequestParkingController ()<UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UITableView *searchTableView;

@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSMutableArray *dataArr;

@property (nonatomic , strong) NSMutableArray *filedSearchResult;


@property (nonatomic, strong) NSMutableArray *licenseplateArr;

@property (nonatomic, strong) NSString *searchLocation;
@property (nonatomic, strong) NSString *searchAddress;

@end

@implementation RequestParkingController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"请求停车任务";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(clickSaveBtn)];
    
    [self getPlace];
    
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor whiteColor];
        // 设置子视图的大小随着父视图变化
        _tableView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        [self.view addSubview:_tableView];
    }
    
    
    if (!_searchTableView) {
        _searchTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 110, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height/2.5) style:UITableViewStylePlain];
        _searchTableView.backgroundColor = [UIColor whiteColor];
        // 设置子视图的大小随着父视图变化
        _searchTableView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _searchTableView.dataSource = self;
        _searchTableView.delegate = self;
        _searchTableView.tableFooterView = [[UIView alloc]init];
        [self.view addSubview:_searchTableView];
        self.searchTableView.hidden = YES;
    }
    
    self.filedSearchResult = [[NSMutableArray alloc]init];
    
    
    self.dataArr = [[NSMutableArray alloc] init];
    [self.dataArr addObjectsFromArray:@[@"", @"", @"", @"", @"", @""]];
    
    if(self.selectorDic!=nil){
        NSLog(@"%@", _selectorDic);
        NSDictionary *pio = [self.selectorDic objectForKey:@"pio"];
        
        [self.dataArr replaceObjectAtIndex:0 withObject:[pio objectForKey:@"propertyName"]];
        [self.dataArr replaceObjectAtIndex:5 withObject:[NSString stringWithFormat:@"%@元/小时",[pio objectForKey:@"price"]]];
        if([StringHelper isEmpty:[self.selectorDic objectForKey:@"parkingCode"]]){
            [self.dataArr replaceObjectAtIndex:4 withObject:[self.selectorDic objectForKey:@"busname"]];
        }else{
            [self.dataArr replaceObjectAtIndex:4 withObject:[pio objectForKey:@"parkingCode"]];
        }
        
        [self.tableView reloadData];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(selectParking:) name:@"selectParking" object:nil];
}


//获取车牌号
- (void)getPlace{
    _licenseplateArr = [NSMutableArray new];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    
    [manager httpRequest:self url:[NSString stringWithFormat:@"%@/%@", licenseplate_URL, userCd]  success:^(id responseObject) {
        NSArray *tempArr = responseObject;
        for (int i=0; i<tempArr.count; i++) {
            NSDictionary *temp =  tempArr[i];
            if(![[temp objectForKey:@"licensePlate"] isEqualToString:@"K123521"]){
                [self.licenseplateArr addObject:[temp objectForKey:@"licensePlate"]];
            }
        }
        [self.dataArr replaceObjectAtIndex:3 withObject:self.licenseplateArr[0]];
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            NSLog(@"获取车牌号失败！");
        }
    }];
    
}


- (void)selectParking:(NSNotification *)sender {
    self.selectorDic = sender.userInfo;
    NSLog(@"--- %@", self.selectorDic);
    
    [self.dataArr replaceObjectAtIndex:4 withObject:[self.selectorDic objectForKey:@"name"]];
    [self.dataArr replaceObjectAtIndex:5 withObject:[NSString stringWithFormat:@"%@元/小时",[self.selectorDic objectForKey:@"price"]]];
    
    [self.tableView reloadData];
}

- (void)clickSaveBtn {
    NSLog(@"-----保存数据-----");
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    //    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    //
    //    NSString *url =  SEARCHCHSABLE_URL;
    //    NSDictionary *params = [URLAndParmFactory makeSelectParkingParm:userCd city:[self.pageDic objectForKey:@"city"] address:[self.pageDic objectForKey:@"address"] location:[self.pageDic objectForKey:@"location"] starttime:[self.pageDic objectForKey:@"starttime"] overtime:[self.pageDic objectForKey:@"overtime"]];
    if([StringHelper isEmpty:_dataArr[0]]){
        [DialogFactory showInfoTip:@"请输入目的地"];
        return;
    }
    
    if([StringHelper isEmpty:_dataArr[1]] || [StringHelper isEmpty:_dataArr[2]]){
        [DialogFactory showInfoTip:@"请选择开始/结束时间"];
        return;
    }
    if([StringHelper isEmpty:_dataArr[3]]){
        [DialogFactory showInfoTip:@"请选择车牌"];
        return;
    }
    if([StringHelper isEmpty:_dataArr[4]]){
        [DialogFactory showInfoTip:@"请选择车位"];
        return;
    }
    NSLog(@"%@", self.selectorDic);
    NSString *str = [self.selectorDic objectForKey:@"title"];
    NSLog(@"%@", str);
    NSLog(@"%@", _dataArr);
    NSLog(@"%@", self.selectorDic);
    NSString *url = nil;
    NSDictionary *params = nil;
    if([str isEqual:@"小区车位"]){
        url = requestbroadcast_URL;
        if([self.selectorDic objectForKey:@"pio"]==nil){
            params = [URLAndParmFactory makeAddParkForPlotParm:userCd city:@"021" address:_dataArr[0] location:[self.selectorDic objectForKey:@"location"] starttime:[NSString stringWithFormat:@"%@:00", _dataArr[1]] overtime:[NSString stringWithFormat:@"%@:00", _dataArr[2]] distance:[self.selectorDic objectForKey:@"distance"] licenseplate:self.dataArr[3] propertyId:[self.selectorDic objectForKey:@"id"]];
            NSLog(@"--- %@", [self.selectorDic objectForKey:@"id"]);
        }else{
            NSDictionary *pio = [self.selectorDic objectForKey:@"pio"];
            NSString *location = [NSString stringWithFormat:@"%@,%@", [pio objectForKey:@"latitude"], [pio objectForKey:@"longitude"]];
            params = [URLAndParmFactory makeAddParkForPlotParm:userCd city:@"021" address:_dataArr[0] location:location starttime:[NSString stringWithFormat:@"%@:00", _dataArr[1]] overtime:[NSString stringWithFormat:@"%@:00", _dataArr[2]] distance:[pio objectForKey:@"distance"] licenseplate:self.dataArr[3] propertyId:[pio objectForKey:@"id"]];
            NSLog(@"--- %@", [pio objectForKey:@"id"]);
        }
        
    }
    if([str isEqual:@"个人车位"]){
        url = requestadd_URL;
        if([self.selectorDic objectForKey:@"pio"]==nil){
            params = [URLAndParmFactory makeAddParkForAloneParm:userCd city:@"021" address:_dataArr[0] location:[self.selectorDic objectForKey:@"location"] starttime:[NSString stringWithFormat:@"%@:00", _dataArr[1]] overtime:[NSString stringWithFormat:@"%@:00", _dataArr[2]] distance:[self.selectorDic objectForKey:@"distance"] licenseplate:self.dataArr[3] parkingId:[self.selectorDic objectForKey:@"Id"]];
        }else{
            NSDictionary *pio = [self.selectorDic objectForKey:@"pio"];
            NSString *location = [NSString stringWithFormat:@"%@,%@", [pio objectForKey:@"latitude"], [pio objectForKey:@"longitude"]];
            params = [URLAndParmFactory makeAddParkForAloneParm:userCd city:@"021" address:_dataArr[0] location:location starttime:[NSString stringWithFormat:@"%@:00", _dataArr[1]] overtime:[NSString stringWithFormat:@"%@:00", _dataArr[2]] distance:[pio objectForKey:@"distance"] licenseplate:self.dataArr[3] parkingId:[pio objectForKey:@"Id"]];
        }
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:url parameters:params success:^(id responseObject) {
        //        [[NSNotificationCenter defaultCenter] postNotificationName:@"aaa" object:self userInfo:nil];
        [self.navigationController popViewControllerAnimated:YES];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            [DialogFactory showTipsInCenter:self.view withText:errorMsg];
        }
    }];
}


#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.tableView){
        return self.titleArr.count;
    }else{
        return self.filedSearchResult.count;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == self.searchTableView){
        //tableView消失
        self.searchTableView.hidden = true;
        //键盘消失
        [self.view endEditing:true];
        [self.dataArr replaceObjectAtIndex:0 withObject:[[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"name"]];
        self.searchAddress = [[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"address"];
        self.searchLocation = [[self.filedSearchResult objectAtIndex:indexPath.row] objectForKey:@"location"];
        [self.tableView reloadData];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.tableView){
        static NSString *cellID = @"BRInfoCell";
        BRInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[BRInfoCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = self.titleArr[indexPath.row];
        cell.textField.delegate = self;
        cell.textField.tag = indexPath.row;
        switch (indexPath.row) {
            case 0:{
                cell.isNeed = NO;
                cell.isNext = NO;
                cell.textField.placeholder = @"请输入";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
                cell.textField.returnKeyType = UIReturnKeyDone;
                //            cell.textField.text = self.infoModel.nameStr;
            }
                break;
            case 1:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.placeholder = @"请选择";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
            }
                break;
            case 2:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.placeholder = @"请选择";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
            }
                break;
            case 3:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.placeholder = @"请选择";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
            }
                break;
            case 4:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.placeholder = @"请选择";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
            }
                break;
            case 5:{
                cell.isNeed = NO;
                cell.isNext = NO;
                cell.textField.placeholder = @"";
                if(![StringHelper isEmpty:_dataArr[indexPath.row]]){
                    cell.textField.text = _dataArr[indexPath.row];
                }
            }
                break;
        }
        return cell;
    }else{
        static NSString *cellID = @"AutoFillTextCell";
        AutoFillTextCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[AutoFillTextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        NSDictionary *parameters = [self.filedSearchResult objectAtIndex:indexPath.row];
        cell.titleLabel.text = [parameters objectForKey:@"name"];
        return cell;
    }
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}



#pragma mark - UITextFieldDelegate 返回键
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField.tag == 0) {
        [textField resignFirstResponder];
    }
    return YES;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == 0) {
        [textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        return YES; // 当前 textField 可以编辑
    } else {
        [self.view endEditing:YES];
        [self handlerTextFieldSelect:textField];
        return NO; // 当前 textField 不可编辑，可以响应点击事件
    }
}

//搜索框文字变化监听
- (void)textFieldDidChange:(UITextField *)textField{
    UITextRange *selectedRange = [textField markedTextRange];
    NSString *newText = [textField textInRange:selectedRange];
    if([newText isEqual:@""] || newText.length == 0){
        NSLog(@"关键字 %@",textField.text);
        [self onSearchByKey:textField.text];
    }else{
        NSLog(@"空白");
    }
}

//请求网络 获取field关键字相关的地名 结果用tableView显示
- (void)onSearchByKey:(NSString *)keywork{
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:[URLAndParmFactory makeKeywordSearchURL:keywork] parameters:nil success:^(id responseObject) {
        self.searchTableView.hidden = false;
        [self.filedSearchResult removeAllObjects];
        [self.filedSearchResult addObjectsFromArray:[responseObject objectForKey:@"tips"]];
        if(self.filedSearchResult.count==0){
            self.searchTableView.hidden = true;
        }
        [self.searchTableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            self.searchTableView.hidden = true;
        }
    }];
}

#pragma mark - 处理点击事件
- (void)handlerTextFieldSelect:(UITextField *)textField {
    switch (textField.tag) {
        case 1:{
            NSDate *minDate = [NSDate date];
            NSDate *maxDate = [NSDate dateWithTimeIntervalSinceNow:24*60*60];
            [PickViewFactory showDateTimePickView:@"选择时间" isShowYear:false isShowMonth:true isShowDay:true isShowHour:true isShowMinute:true defaultDateTime:nil selectMinTime:minDate selectMaxTime:maxDate resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                textField.text = selectValue;
                [self.dataArr replaceObjectAtIndex:textField.tag withObject:selectValue];
            }];
        }
            break;
        case 2:{
            NSDate *minDate = [NSDate date];
            NSDate *maxDate = [NSDate dateWithTimeIntervalSinceNow:24*60*60];
            [PickViewFactory showDateTimePickView:@"选择时间" isShowYear:false isShowMonth:true isShowDay:true isShowHour:true isShowMinute:true defaultDateTime:nil selectMinTime:minDate selectMaxTime:maxDate resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                textField.text = selectValue;
                [self.dataArr replaceObjectAtIndex:textField.tag withObject:selectValue];
            }];
        }
            break;
        case 3:{
            [PickViewFactory showOneItemPickView:@"选择车牌号码" defaultValue:nil dataSource:self.licenseplateArr resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                textField.text = selectValue;
                [self.dataArr replaceObjectAtIndex:textField.tag withObject:selectValue];
                
            }];
        }
            break;
        case 4:{
            if([StringHelper isEmpty:_dataArr[0]]){
                [DialogFactory showTipsInCenter:self.view withText:@"请输入目的地"];
                return;
            }
            
            if([StringHelper isEmpty:_dataArr[1]] || [StringHelper isEmpty:_dataArr[2]]){
                [DialogFactory showTipsInCenter:self.view withText:@"请选择开始/结束时间"];
                return;
            }
            
            
            ShareController *shareController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareController"];
            shareController.pageType = @"selectParking";
            shareController.pageDic = @{
                                        @"city":@"021",
                                        @"address":_dataArr[0],
                                        @"location":self.searchLocation,
                                        @"starttime":_dataArr[1],
                                        @"overtime":_dataArr[2]
                                        };
            [self.navigationController pushViewController:shareController animated:true];
            [shareController updatePageByPageType];
            
            
            
        }
            break;
            
        default:
            break;
    }
}

//#pragma mark - 刷新指定行的数据
//- (void)reloadData:(NSInteger)section row:(NSInteger)row {
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
//    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
//}





- (NSArray *)titleArr {
    if (!_titleArr) {
        _titleArr = @[@"目地地址：", @"开始时间：", @"结束时间：", @"车牌号码：", @"选择车位：", @"车位费用："];
    }
    return _titleArr;
}

- (NSMutableArray *)dataArr {
    if (!_dataArr) {
        
    }
    return _dataArr;
}

//- (BRInfoModel *)infoModel {
//    if (!_infoModel) {
//        _infoModel = [[BRInfoModel alloc]init];
//    }
//    return _infoModel;
//}

@end
