//
//  QYSHDetailController.m
//  carshare
//
//  Created by 森虹 on 2018/7/9.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "QYSHDetailController.h"
#import "Constants.h"
#import "URLAndParmFactory.h"
#import "AFNetworkingHelper.h"
#import "DialogFactory.h"
#import "UIColor+Hex.h"

@interface QYSHDetailController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *btn;

@property (nonatomic , strong) NSMutableArray *data;
@property (nonatomic , strong) NSDictionary *auditEnterprises;

@end

@implementation QYSHDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.hidden = true;
    // 删除单元格分隔线
    self.tableView.bounces = false;
    self.tableView.tableFooterView = [UIView new];
    self.data = [[NSMutableArray alloc]init];
    [self onRefresh];
}


- (void)onRefresh {
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:[URLAndParmFactory makeEnterpriseURL:_requestId] success:^(id responseObject) {
        self.auditEnterprises = responseObject;
        [self refreshData:responseObject];
        
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [DialogFactory showInfoTip:errorMsg];
            [self.data removeAllObjects];
        }
        [self.tableView reloadData];
    }];
}



- (void)refreshData:(NSDictionary *)auditEnterprises {
    NSString *contractStatus = [auditEnterprises objectForKey:@"contractStatus"];
    if ([contractStatus isEqualToString:@"0"]) {
        [self.btn setTitle:@"同意签约" forState:nil];
    } else {
        [self.btn setTitle:@"取消签约" forState:nil];
    }
    
    NSMutableArray *data1 = [NSMutableArray new];
    NSMutableArray *data2 = [NSMutableArray new];
    NSMutableArray *data3 = [NSMutableArray new];
    
    [data1 addObject:@[@"企业名称", [auditEnterprises objectForKey:@"enterpriseName"]]];
    [data1 addObject:@[@"公司地址", [NSString stringWithFormat:@"%@ %@ %@",[auditEnterprises objectForKey:@"cityDisplayName"], [auditEnterprises objectForKey:@"districtDisplayName"], [auditEnterprises objectForKey:@"addressLine"]]]];
    [data1 addObject:@[@"企业编号", [auditEnterprises objectForKey:@"businessCode"]]];
    [data1 addObject:@[@"公司电话", [auditEnterprises objectForKey:@"phone"]]];
    [data1 addObject:@[@"公司网站", [auditEnterprises objectForKey:@"url"]]];
    
    [data2 addObject:@[@"联系人姓名", [auditEnterprises objectForKey:@"contactName"]==nil? @" " : [auditEnterprises objectForKey:@"contactName"]]];
    [data2 addObject:@[@"联系人电话", [auditEnterprises objectForKey:@"contactPhone"]==nil? @" " : [auditEnterprises objectForKey:@"contactPhone"]]];
    [data2 addObject:@[@"联系人邮箱", [auditEnterprises objectForKey:@"contactEmail"]==nil? @" " : [auditEnterprises objectForKey:@"contactEmail"]]];
    
    [data3 addObject:@[@"银行名称", [auditEnterprises objectForKey:@"bankName"]==nil? @" " : [auditEnterprises objectForKey:@"bankName"]]];
    [data3 addObject:@[@"支行名称", [auditEnterprises objectForKey:@"branchName"]==nil? @" " : [auditEnterprises objectForKey:@"branchName"]]];
    [data3 addObject:@[@"账户号码", [auditEnterprises objectForKey:@"bandAccount"]==nil? @" " : [auditEnterprises objectForKey:@"bandAccount"]]];
    
    [self.data addObject:data1];
    [self.data addObject:data2];
    [self.data addObject:data3];
    
    NSLog(@"总数 %ld", self.data.count);
    [self.tableView reloadData];
    
    self.view.hidden = false;
}

//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSLog(@"总数 %ld", self.data.count);
    return self.data.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) { //section组
        return 5;
    } else if (section == 1) {
        return 3;
    }
    return 3;
}


//头视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 20;
}

//脚视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"QYSHDetailCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    NSLog(@"%d-%d", section, row);
    NSArray *parameters = [self.data objectAtIndex:section];
    NSArray *content= [parameters objectAtIndex:row];
    //默认点tableCell中有textLable imageView deta控件
    UILabel *tv_name = [cell viewWithTag:1];
    UILabel *tv_detail = [cell viewWithTag:2];
    
    [tv_name setText:content[0]];
    [tv_detail setText:content[1]];
    
    return  cell;
}

- (IBAction)btnClick:(id)sender {
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:false withLoadingCircleStyle:1 isMask:true isCancelable:true];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    NSString *contractStatus = [self.auditEnterprises objectForKey:@"contractStatus"];
    NSDictionary *parm = nil;
    if ([contractStatus isEqualToString:@"0"]) {
        //        new ApiRequest<AuditProperty>(AuditProperty.class).postRequest(getActivity(), NetAPI.AUDITPROPERTY_URL, URLFactory.makeAuditPropertiesParm(UserInfo.getUserCd(getActivity()), propertyAudit, "1"), observer);
        parm = [URLAndParmFactory makeAuditEnterprisesParm:userCd enterpriseId:[[self.auditEnterprises objectForKey:@"id"] stringValue] contractStatus:@"1"];
    } else {
        parm = [URLAndParmFactory makeAuditEnterprisesParm:userCd enterpriseId:[[self.auditEnterprises objectForKey:@"id"] stringValue] contractStatus:@"0"];
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:AUDITENTERPRISE_URL parameters:parm success:^(id responseObject) {
        [DialogFactory dismissDialog];
        [DialogFactory showTipsWithImage:self.view withImage:@"ok" withText:@"修改成功"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"qysh" object:self userInfo:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
        
        
        
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            [DialogFactory showInfoTip:errorMsg];
        }
    }];
}


+ (void)Go:(UIViewController *)viewController withObject:(NSString *)requestId{
    QYSHDetailController *controller = [viewController.storyboard instantiateViewControllerWithIdentifier:@"QYSHDetailController"];
    controller.requestId = requestId;
    [viewController.navigationController pushViewController:controller animated:YES];
}


@end

