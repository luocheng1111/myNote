//
//  QYSHDetailController.h
//  carshare
//
//  Created by 森虹 on 2018/7/9.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QYSHDetailController : UIViewController

@property (nonatomic , strong) NSString *requestId;

+ (void)Go:(UIViewController *)viewController withObject:(NSString *)requestId;

@end

