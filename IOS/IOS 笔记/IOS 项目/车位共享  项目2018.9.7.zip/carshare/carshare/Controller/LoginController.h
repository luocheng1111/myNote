//
//  LoginController.h
//  carshare
//
//  Created by 森鸿 on 2018/6/4.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface LoginController : UIViewController

+ (void)Go:(UIViewController *)viewController;

@end

