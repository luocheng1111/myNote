//
//  TaskDetailController.h
//  carshare
//
//  Created by 森虹 on 2018/7/26.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface TaskDetailController : UIViewController

@property (nonatomic , strong) NSMutableString *pageType;
@property (nonatomic , strong) NSMutableDictionary *pageDic;

@end


