//
//  ModifyShareParkingController.m
//  carshare
//
//  Created by 森虹 on 2018/7/24.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "ModifyShareParkingController.h"
#import "BRInfoCell.h"
#import "BRInfoModel.h"
#import "StringHelper.h"
#import "DialogFactory.h"
#import "AFNetworkingHelper.h"
#import "PickViewFactory.h"
#import "URLAndParmFactory.h"
#import "AFNetworking.h"
#import "Constants.h"

@interface ModifyShareParkingController ()<UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *titleArr;
@property (nonatomic, strong) NSMutableArray *dataArr;

@end

@implementation ModifyShareParkingController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"车位修改";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(clickSaveBtn)];
    
    NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
    [mutableItem setValue:@"1" forKey:@"mondayShare"]; // 0为开发 1为不开放
    [mutableItem setValue:@"1" forKey:@"tuesdayShare"];
    [mutableItem setValue:@"1" forKey:@"wednesdayShare"];
    [mutableItem setValue:@"1" forKey:@"thursdayShare"];
    [mutableItem setValue:@"1" forKey:@"fridayShare"];
    [mutableItem setValue:@"1" forKey:@"saturdayShare"];
    [mutableItem setValue:@"1" forKey:@"sundayShare"];
    [mutableItem setValue:@"1" forKey:@"holidayShare"];
    self.pageDic = mutableItem;
    
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor whiteColor];
        // 设置子视图的大小随着父视图变化
        _tableView.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        [self.view addSubview:_tableView];
    }
}

- (void)clickSaveBtn {
    NSMutableString *startTime = [self.pageDic objectForKey:@"startTime"];
    NSMutableString *endTime = [self.pageDic objectForKey:@"endTime"];
    NSLog(@"%@,%@", startTime, endTime);
    if([startTime hasSuffix:@"AM"]||[startTime hasSuffix:@"PM"]){
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"hh:mm:ss a";
        NSDate *date = [formatter dateFromString:startTime];
        NSLog(@"%@", date);
        NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        formatter2.dateFormat = @"HH:mm";
        startTime = [formatter2 stringFromDate:date];
        NSLog(@"%@", startTime);
    }

    if([endTime hasSuffix:@"AM"]||[endTime hasSuffix:@"PM"]){
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"hh:mm:ss a";
        NSDate *date = [formatter dateFromString:endTime];
        NSLog(@"%@", date);
        NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        formatter2.dateFormat = @"HH:mm";
        endTime = [formatter2 stringFromDate:date];
        NSLog(@"%@", endTime);
    }
//    NSArray *startArray = [startTime componentsSeparatedByString:@":"];
//    NSArray *endArray = [endTime componentsSeparatedByString:@":"];
//    NSLog(@"%@ - %@", startArray, endArray);
//    if([startArray[0] integerValue]-[endArray[0] integerValue]<=0){
//        //当天
//        NSArray *streArray = [endTime componentsSeparatedByString:@" "];
//        if(streArray.count<2){
//        NSDate *nowdate = [NSDate date];
//        NSDateFormatter *formatter3 = [[NSDateFormatter alloc] init];
//        formatter3.dateFormat = @"yyyy-MM-dd";
//        NSString *today = [formatter3 stringFromDate:nowdate];
//        NSString *endTimeR = [NSString stringWithFormat:@"%@ %@",today , endTime];
//        NSLog(@"%@", endTimeR);
//        NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
//        [mutableItem setObject:endTimeR forKey:@"endTime"];
//        self.pageDic = mutableItem;
//        }
//    }else{
//        //加一天
//        NSArray *streArray = [endTime componentsSeparatedByString:@" "];
//        if(streArray.count<2){
//        NSDate *nowdate = [NSDate dateWithTimeIntervalSinceNow:24*60*60];;
//        NSDateFormatter *formatter3 = [[NSDateFormatter alloc] init];
//        formatter3.dateFormat = @"yyyy-MM-dd";
//        NSString *today = [formatter3 stringFromDate:nowdate];
//        NSString *endTimeR = [NSString stringWithFormat:@"%@ %@",today , endTime];
//        NSLog(@"%@", endTimeR);
//        NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
//        [mutableItem setObject:endTimeR forKey:@"endTime"];
//        self.pageDic = mutableItem;
//        }
//    }
//    
//    NSArray *strArray = [startTime componentsSeparatedByString:@" "];
//    if(strArray.count<2){
//    NSDate *nowdate = [NSDate date];
//    NSDateFormatter *formatter3 = [[NSDateFormatter alloc] init];
//    formatter3.dateFormat = @"yyyy-MM-dd";
//    NSString *today = [formatter3 stringFromDate:nowdate];
//    NSString *startTimeR = [NSString stringWithFormat:@"%@ %@",today , startTime];
//    NSLog(@"%@", startTimeR);
//        NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
//        [mutableItem setObject:startTimeR forKey:@"startTime"];
//        self.pageDic = mutableItem;
//    }
//    NSLog(@"startTime：%@", [self.pageDic objectForKey:@"startTime"]);
//    NSLog(@"endTime：%@", [self.pageDic objectForKey:@"endTime"]);
    
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:false withLoadingCircleStyle:1 isMask:true isCancelable:true];
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    NSLog(@"%@",self.pageDic);
    [manager httpRequest:self url:modifyparking_URL parameters:[URLAndParmFactory makeModifyParkingParm:self.pageDic]  success:^(id responseObject) {
        [DialogFactory dismissDialog];
        [DialogFactory showTipsWithImage:self.view withImage:@"ok" withText:@"修改成功"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"modifyparking" object:self userInfo:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            [DialogFactory showInfoTip:errorMsg];
        }
        
    }];
    
    }





- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.titleArr.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        static NSString *cellID = @"BRInfoCell";
        BRInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[BRInfoCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = self.titleArr[indexPath.row];
        cell.textField.delegate = self;
        cell.textField.tag = indexPath.row;
        switch (indexPath.row) {
            case 0:{
                cell.isNeed = NO;
                cell.isNext = NO;
                cell.textField.text = [self.pageDic objectForKey:@"propertyName"];
            }
                break;
            case 1:{
                cell.isNeed = NO;
                cell.isNext = NO;
                cell.textField.text = [self.pageDic objectForKey:@"parkingCode"];
            }
                break;
            case 2:{
                cell.isNeed = NO;
                cell.isNext = NO;
                cell.textField.text = [self.pageDic objectForKey:@"addressLine"];
            }
                break;
            case 3:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.text = [self.pageDic objectForKey:@"shareMethodDisplayName"];
            }
                break;
            case 4:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.text = [self.pageDic objectForKey:@"startTime"];
            }
                break;
            case 5:{
                cell.isNeed = NO;
                cell.isNext = YES;
                cell.textField.text = [self.pageDic objectForKey:@"endTime"];
            }
                break;
        }
        return cell;
}


#pragma mark - UITextFieldDelegate 返回键
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField.tag == 0) {
        [textField resignFirstResponder];
    }
    return YES;
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    [self.view endEditing:YES];
    [self handlerTextFieldSelect:textField];
    return NO; // 当前 textField 不可编辑，可以响应点击事件
}

#pragma mark - 处理点击事件
- (void)handlerTextFieldSelect:(UITextField *)textField {
    switch (textField.tag) {
        case 3:{
            NSArray *arr = @[@"指定日",@"工作日",@"任意日"];
            [PickViewFactory showOneItemPickView:@"选择共享时间" defaultValue:nil dataSource:arr resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                if([selectValue isEqualToString:@"指定日"]){
                    NSArray *arr = @[@"星期一",@"星期二",@"星期三",@"星期四",@"星期五",@"星期六",@"星期天"];
                    [PickViewFactory showOneItemPickView:@"选择共享时间" defaultValue:nil dataSource:arr resultBlock:^(NSString *selectValue) {
                        NSLog(@"%@", selectValue);
                        textField.text = [NSString stringWithFormat:@"仅%@分享",selectValue];
//                        [self.pageDic setValue:@"2" forKey:@"shareMethod"];
//                        [self.pageDic setValue:@"1" forKey:@"mondayShare"]; // 0为开发 1为不开放
//                        [self.pageDic setValue:@"1" forKey:@"tuesdayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"wednesdayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"thursdayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"fridayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"saturdayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"sundayShare"];
//                        [self.pageDic setValue:@"1" forKey:@"holidayShare"];
                        NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
                       if([selectValue isEqualToString:@"星期一"]){
                           [mutableItem setValue:@"0" forKey:@"mondayShare"];
                       }else if ([selectValue isEqualToString:@"星期二"]){
                           [mutableItem setValue:@"0" forKey:@"tuesdayShare"];
                       }else if ([selectValue isEqualToString:@"星期三"]){
                           [mutableItem setValue:@"0" forKey:@"wednesdayShare"];
                       }else if ([selectValue isEqualToString:@"星期四"]){
                           [mutableItem setValue:@"0" forKey:@"thursdayShare"];
                       }else if ([selectValue isEqualToString:@"星期五"]){
                           [mutableItem setValue:@"0" forKey:@"thursdayShare"];
                       }else if ([selectValue isEqualToString:@"星期六"]){
                           [mutableItem setValue:@"0" forKey:@"fridayShare"];
                       }else{
                           [mutableItem setValue:@"0" forKey:@"sundayShare"];
                       }
                       self.pageDic = mutableItem;
    
                    }];
                }else if([selectValue isEqualToString:@"工作日"]){
                    textField.text = [NSString stringWithFormat:@"%@分享",selectValue];
                    NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
                    [mutableItem setValue:@"0" forKey:@"shareMethod"];
                    [mutableItem setValue:@"0" forKey:@"mondayShare"];
                    [mutableItem setValue:@"0" forKey:@"tuesdayShare"];
                    [mutableItem setValue:@"0" forKey:@"wednesdayShare"];
                    [mutableItem setValue:@"0" forKey:@"thursdayShare"];
                    [mutableItem setValue:@"0" forKey:@"fridayShare"];
                    [mutableItem setValue:@"1" forKey:@"saturdayShare"];
                    [mutableItem setValue:@"1" forKey:@"sundayShare"];
                    [mutableItem setValue:@"1" forKey:@"holidayShare"];
                    self.pageDic = mutableItem;
                }else{
                    NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
                    textField.text = [NSString stringWithFormat:@"%@分享",selectValue];
                    [mutableItem  setValue:@"3" forKey:@"shareMethod"];
                    [mutableItem  setValue:@"0" forKey:@"mondayShare"];
                    [mutableItem  setValue:@"0" forKey:@"tuesdayShare"];
                    [mutableItem  setValue:@"0" forKey:@"wednesdayShare"];
                    [mutableItem  setValue:@"0" forKey:@"thursdayShare"];
                    [mutableItem  setValue:@"0" forKey:@"fridayShare"];
                    [mutableItem  setValue:@"0" forKey:@"saturdayShare"];
                    [mutableItem  setValue:@"0" forKey:@"sundayShare"];
                    [mutableItem  setValue:@"0" forKey:@"holidayShare"];
                     self.pageDic = mutableItem;
                }
            }];
        }
            break;
        case 4:{
            [PickViewFactory showTimePickView:@"请选择时间" resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                textField.text = selectValue;
    
                NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
                [mutableItem setObject:selectValue forKey:@"startTime"];
                self.pageDic = mutableItem;
            }];
        }
            break;
        case 5:{
            [PickViewFactory showTimePickView:@"请选择时间" resultBlock:^(NSString *selectValue) {
                NSLog(@"%@", selectValue);
                textField.text = selectValue;
  
                NSMutableDictionary *mutableItem = [NSMutableDictionary dictionaryWithDictionary:_pageDic];
                [mutableItem setObject:selectValue forKey:@"endTime"];
                self.pageDic = mutableItem;
            }];
        }
            break;
            
        default:
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}


- (NSArray *)titleArr {
    if (!_titleArr) {
        _titleArr = @[@"物业名称：", @"车位编号：", @"所住地址：", @"共享时间：", @"分享开始时间：", @"分享结束时间："];
    }
    return _titleArr;
}


@end
