//
//  WYSHDetailController.m
//  carshare
//
//  Created by 森虹 on 2018/7/9.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "WYSHDetailController.h"
#import "Constants.h"
#import "URLAndParmFactory.h"
#import "AFNetworkingHelper.h"
#import "StringHelper.h"
#import <MAMapKit/MAMapKit.h>
#import "GaodeMapManager.h"
#import "DialogFactory.h"
#import <Masonry.h>
#import "UIColor+Hex.h"

@interface WYSHDetailController ()<UITableViewDelegate, UITableViewDataSource, MAMapViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;




@property (weak, nonatomic) IBOutlet UIView *photoView;
@property (weak, nonatomic) IBOutlet UITableView *photoTableView;


@property (nonatomic , strong) NSMutableArray *data;
@property (nonatomic , strong) NSDictionary *auditProperty;

@property (nonatomic, retain) UIButton *btn;
@property (nonatomic, retain) UIView *mapLayout;
@property (nonatomic, retain) UIView *mapView;
@property (nonatomic, retain) UILabel *mapTitleLabel;
@property (nonatomic, retain) UIView  *mapHintLabelBG;
@property (nonatomic, retain) UILabel *mapHintLabel;

@property (nonatomic, retain) UIView *propertyLayout;
@property (nonatomic, retain) UIView *propertyLabelBG;
@property (nonatomic, retain) UILabel *propertyTitleLabel;
@property (nonatomic, retain) UITextView *propertyLabel;


@end

@implementation WYSHDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
    //    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.edges.equalTo(self.scrollView).insets(UIEdgeInsetsMake(0, 0, 0, 0));
    //    }];
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
    }];
    
    
    
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    self.data = [[NSMutableArray alloc]init];
    
    //地图Layout
    self.mapLayout = [UIView new];
    self.mapLayout.backgroundColor = [UIColor whiteColor];
    
    [self.contentView addSubview:self.mapLayout];
    
    
    self.tableView.bounces = false;
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(@0);
        make.height.equalTo(@320);
    }];
    
    [self.mapLayout mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.top.equalTo(self.tableView.mas_bottom);
        make.right.equalTo(self.contentView);
    }];
    
    self.mapTitleLabel = [UILabel new];
    self.mapTitleLabel.text= @"停车场地图";
    self.mapTitleLabel.font = [UIFont systemFontOfSize:14];
    [self.mapTitleLabel setTextColor:[UIColor colorWithHexString:@"#999999"]];
    
    self.mapView = [UIView new];
    self.mapView.backgroundColor = [UIColor whiteColor];
    
    self.mapHintLabelBG = [UIView new];
    self.mapHintLabelBG.backgroundColor = [UIColor whiteColor];
    
    self.mapHintLabel = [UILabel new];
    self.mapHintLabel.backgroundColor = [UIColor whiteColor];
    [self.mapHintLabel setTextColor:[UIColor blackColor]];
    self.mapHintLabel.font = [UIFont systemFontOfSize:14];
    self.mapHintLabel.text= @"尚未添加地图";
    
    [self.mapLayout addSubview:self.mapTitleLabel];
    [self.mapLayout addSubview:self.mapView];
    [self.mapLayout addSubview:self.mapHintLabelBG];
    [self.mapHintLabelBG addSubview:self.mapHintLabel];
    
    [self.mapTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mapLayout).offset(10);
        make.top.equalTo(self.mapLayout).offset(16);
        make.right.equalTo(self.mapLayout);
        make.bottom.equalTo(self.mapView.mas_top).offset(-10);
        make.height.equalTo(@20);
    }];
    [self.mapView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mapLayout);
        make.top.equalTo(self.mapTitleLabel.mas_bottom);
        make.right.equalTo(self.mapLayout);
        make.height.equalTo(@160);
    }];
    
    [self.mapHintLabelBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mapLayout);
        make.top.equalTo(self.mapView.mas_bottom).offset(10);
        make.right.equalTo(self.mapLayout);
        make.height.equalTo(@40);
    }];
    
    
    [self.mapHintLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mapHintLabelBG).offset(35);
        make.top.equalTo(self.mapHintLabelBG.mas_top).offset(10);
        make.right.equalTo(self.mapHintLabelBG);
        make.bottom.equalTo(self.mapHintLabelBG.mas_bottom).offset(-10);
        make.height.equalTo(@20);
    }];
    
    //停车场Layout
    self.propertyLayout = [UIView new];
    
    [self.contentView addSubview:self.propertyLayout];
    
    [self.propertyLayout mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.top.equalTo(self.mapHintLabelBG.mas_bottom);
        make.right.equalTo(self.contentView);
    }];
    
    self.propertyTitleLabel = [UILabel new];
    self.propertyTitleLabel.text= @"出入口";
    self.propertyTitleLabel.font = [UIFont systemFontOfSize:14];
    [self.propertyTitleLabel setTextColor:[UIColor colorWithHexString:@"#999999"]];
    
    self.propertyLabelBG = [UIView new];
    self.propertyLabelBG.backgroundColor = [UIColor whiteColor];
    
    self.propertyLabel = [UITextView new];
    self.propertyLabel.font = [UIFont systemFontOfSize:14];
    [self.propertyLabel setTextColor:[UIColor grayColor]];
    
    [self.propertyLayout addSubview:self.propertyTitleLabel];
    [self.propertyLayout addSubview:self.propertyLabelBG];
    [self.propertyLabelBG addSubview:self.propertyLabel];
    
    [self.propertyTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.propertyLayout).offset(10);
        make.top.equalTo(self.propertyLayout).offset(16);
        make.right.equalTo(self.propertyLayout);
        make.bottom.equalTo(self.propertyLabelBG.mas_top).offset(-10);
        make.height.equalTo(@20);
    }];
    
    [self.propertyLabelBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.propertyLayout);
        make.top.equalTo(self.propertyTitleLabel.mas_bottom).offset(10);
        make.right.equalTo(self.propertyLayout);
        make.height.equalTo(@40);
    }];
    
    [self.propertyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.propertyLabelBG).offset(25);
        make.top.equalTo(self.propertyLabelBG);
        make.right.equalTo(self.propertyLabelBG);
        make.height.equalTo(@40);
    }];
    
    
    self.btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.contentView addSubview:self.btn];
    [self.btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchDown];
    [self.btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.top.equalTo(self.propertyLabelBG.mas_bottom).offset(20);
        make.right.equalTo(self.contentView);
        make.height.equalTo(@20);
    }];
    
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.btn.mas_bottom).offset(20);
    }];
    
    self.contentView.hidden = true;
    
    [self onRefresh];
}


- (void)viewDidAppear:(BOOL)animated{
    //    CGRect newFrame = self.tableView.frame;
    //    newFrame.size.height = 320;
    //    self.tableView.frame = newFrame;
}




- (void)onRefresh {
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:[URLAndParmFactory makePropertyURL:_requestId] success:^(id responseObject) {
        //        [self.data removeAllObjects];
        //        [self.data addObjectsFromArray:responseObject];
        self.auditProperty = responseObject;
        [self refreshData:responseObject];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
        }
        [self.tableView reloadData];
    }];
}



- (void)refreshData:(NSDictionary *)auditProperty {
    
    NSString *contractStatus = [auditProperty objectForKey:@"contractStatus"];
    
    if ([contractStatus isEqualToString:@"0"]) {
        [self.btn setTitle:@"同意签约" forState:nil];
    } else {
        [self.btn setTitle:@"取消签约" forState:nil];
    }
    
    
    NSString *parkingName = [auditProperty objectForKey:@"parkingName"];
    if ([StringHelper isEmpty:parkingName]) {
        [self.data addObject:@[@"物业名称", [auditProperty objectForKey:@"propertyName"]]];
    } else {
        [self.data addObject:@[@"停车场名称", parkingName]];
    }
    [self.data addObject:@[@"物业地址", [auditProperty objectForKey:@"addressLine"]]];
    [self.data addObject:@[@"物业公司名称", @" "]];
    [self.data addObject:@[@"物业电话", [auditProperty objectForKey:@"phone"]]];
    [self.data addObject:@[@"合同有效期", [NSString stringWithFormat:@"%@ - %@",[auditProperty objectForKey:@"validStartDisplay"], [auditProperty objectForKey:@"validEndDisplay"]]]];
    [self.data addObject:@[@"申请时间", [auditProperty objectForKey:@"ApplyDateTimeDisplay"]]];
    [self.data addObject:@[@"物业管理车位", [[auditProperty objectForKey:@"freeParking"] stringValue]]];
    [self.data addObject:@[@"价格", [auditProperty objectForKey:@"priceDispaly"]]];
    
    NSLog(@"数 %ld", self.data.count);
    [self.tableView reloadData];
    
    
    //设置地图
    NSString *latitude = [auditProperty objectForKey:@"latitude"];
    NSString *longitude = [auditProperty objectForKey:@"longitude"];
    if(latitude != nil){
        [self.mapView setHidden:false];
        //        CGRect newFrame = self.mapHintLabel.frame;
        //        newFrame.size.height = 0;
        //        self.mapHintLabel.frame = newFrame;
        [self.mapHintLabelBG mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@0);
        }];
        
        [self.mapHintLabelBG setHidden:true];
        
        CLLocationCoordinate2D startCoordinate  = CLLocationCoordinate2DMake([longitude floatValue], [latitude floatValue]);
        GaodeMapManager *mapManager = [GaodeMapManager sharedManager];
        [mapManager addAnomationToMapView:self coor:startCoordinate view:self.mapView];
    }else {
        [self.mapView setHidden:true];
        [self.mapHintLabelBG setHidden:false];
        NSLog(@"111131312312312");
        [self.mapView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@0);
        }];
    }
    
    //设置出入口
    NSArray *entrancesArr = [auditProperty objectForKey:@"entrances"];
    if (entrancesArr != nil && entrancesArr.count>0) {
        [self.propertyLayout setHidden:false];
        NSMutableString *sb = [NSMutableString new];
        for (int i = 0; i < entrancesArr.count; i++) {
            NSDictionary *entrance = [entrancesArr objectAtIndex:i];
            if (i != entrance.count - 1) {
                //                sb.append(entrance.getAddressLine() + "\n");
                [sb appendFormat: @"%@\n", [entrance objectForKey:@"addressLine"]];
            } else {
                //                sb.append(entrance.getAddressLine());
                [sb appendFormat: @"%@", [entrance objectForKey:@"addressLine"]];
            }
        }
        NSLog(@"出入口：%@", sb);
        [self.propertyLabel setText:sb];
        
        // 根据字体得到NSString的尺寸
        CGSize size = [self.propertyLabel.text sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"HelveticaNeue" size:14.0f],NSFontAttributeName, nil]];
        //        CGRect newFrame = self.propertyLabel.frame;
        //        newFrame.size.height = size.height;
        //        self.propertyLabel.frame = newFrame;
        [self.propertyLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@(size.height));
        }];
        [self.propertyLabelBG mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@(size.height));
        }];
    } else {
        [self.propertyLayout setHidden:true];
        [self.propertyLayout mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@0);
        }];
        
        [self.propertyLabelBG mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@0);
        }];
        [self.propertyTitleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.propertyLayout).offset(0);
            make.top.equalTo(self.propertyLayout).offset(0);
            make.bottom.equalTo(self.propertyLabelBG.mas_top).offset(0);
            make.height.equalTo(@0);
        }];
        
    }
    
    //设置图片
    NSArray *attachmentsArr = [auditProperty objectForKey:@"attachments"];
    if (attachmentsArr != nil && attachmentsArr.count>0) {
        //        [self.photoView setHidden:false];
        //        final List<MultiplexImage> images = new ArrayList<MultiplexImage>();
        //        for (int i = 0; i < propertyAudit.getAttachments().size(); i++) {
        //            images.add(new MultiplexImage(NetAPI.attachment_URL + "/" + propertyAudit.getAttachments().get(i)));
        //        }
        //        rvPhoto.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        //        rvPhoto.setAdapter(imageAdapter = new ImageAdapter(getActivity(), images));
        //        imageAdapter.setItemClickListener(new ImageAdapter.OnRecyclerItemClickListener() {
        //            @Override
        //            public void click(View item, int position) {
        //                PickPhotoActivity.startActivity(getActivity(), item, images, position);
        //            }
        //        });
    } else {
        //        [self.photoView setHidden:true];
        
    }
    
    //    CLLocationCoordinate2D startCoordinate  = CLLocationCoordinate2DMake(39.993291, 116.473188);
    //    GaodeMapManager *mapManager = [GaodeMapManager sharedManager];
    //    [mapManager addAnomationToMapView:startCoordinate view:self.mapView];
    
    
    
    self.contentView.hidden = false;
    
}


//标记点图标设定
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id <MAAnnotation>)annotation{
    NSLog(@"1232131312312312312");
    //定位小蓝点
    if ([annotation isKindOfClass:[MAUserLocation class]]) {
        return nil;
    }
    //绘制其他点
    if([annotation isKindOfClass:[MAPointAnnotation class]]){
        NSLog(@"1232131312");
        static NSString *pointReuseIndetifier = @"pointReuseIndetifier";
        
        MAPinAnnotationView *annotationView = (MAPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndetifier];
        
        if (annotationView == nil){
            annotationView = [[MAPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pointReuseIndetifier];
            //点击点标记后是否弹框 如何是YES 弹框显示的是设置好的title和subtitle
            annotationView.canShowCallout = YES;
            annotationView.calloutOffset = CGPointMake(0, -5);
        }
        
        /* 设置起点的图标. */
        if ([[annotation title] isEqualToString:@"起点"]){
            annotationView.image = [UIImage imageNamed:@"startPoint"];
        }
        /* 设置终点的图标. */
        else if([[annotation title] isEqualToString:@"终点"]){
            annotationView.image = [UIImage imageNamed:@"endPoint"];
        }
        /* 设置默认显示图标. */
        else{
            NSString *title = [[annotation title] componentsSeparatedByString:@","][0];
            NSInteger tag = [[[annotation title] componentsSeparatedByString:@","][1] integerValue];
            if(tag>=1000){
                annotationView.image = [UIImage imageNamed:@"poi_marker_10"];
            }else{
                annotationView.image = [UIImage imageNamed:@"poi_marker_1"];
            }
            [annotation setTitle:title];
            annotationView.tag = tag;
            //           NSLog(@"%@", annotationView.flag);
        }
        return annotationView;
    }
    return nil;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _data.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"WYSHDetailCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    
    NSArray *parameters = [self.data objectAtIndex:indexPath.row];
    
    //默认点tableCell中有textLable imageView deta控件
    UILabel *tv_name = [cell viewWithTag:1];
    UILabel *tv_detail = [cell viewWithTag:2];
    
    [tv_name setText:parameters[0]];
    [tv_detail setText:parameters[1]];
    
    
    
    return  cell;
}

- (void)btnClick {
    
    //    showLoadingDialog();
    [DialogFactory showLoadingView:@"加载中...." isWhiteStyle:false withLoadingCircleStyle:1 isMask:true isCancelable:true];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    NSString *contractStatus = [self.auditProperty objectForKey:@"contractStatus"];
    NSDictionary *parm = nil;
    if ([contractStatus isEqualToString:@"0"]) {
        //        new ApiRequest<AuditProperty>(AuditProperty.class).postRequest(getActivity(), NetAPI.AUDITPROPERTY_URL, URLFactory.makeAuditPropertiesParm(UserInfo.getUserCd(getActivity()), propertyAudit, "1"), observer);
        parm = [URLAndParmFactory makeAuditPropertiesParm:userCd propertyId:[[self.auditProperty objectForKey:@"id"] stringValue] degree:[self.auditProperty objectForKey:@"degree"] contractStatus:@"1"];
    } else {
        parm = [URLAndParmFactory makeAuditPropertiesParm:userCd propertyId:[[self.auditProperty objectForKey:@"id"] stringValue] degree:[self.auditProperty objectForKey:@"degree"] contractStatus:@"0"];
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:AUDITPROPERTY_URL parameters:parm success:^(id responseObject) {
        [DialogFactory dismissDialog];
        [DialogFactory showTipsWithImage:self.view withImage:@"ok" withText:@"修改成功"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"wysh" object:self userInfo:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
        
        
        
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if(isError){
            [DialogFactory showInfoTip:errorMsg];
        }
    }];
    
}

+ (void)Go:(UIViewController *)viewController withObject:(NSString *)requestId{
    WYSHDetailController *controller = [viewController.storyboard instantiateViewControllerWithIdentifier:@"WYSHDetailController"];
    controller.requestId = requestId;
    [viewController.navigationController pushViewController:controller animated:YES];
}



@end
