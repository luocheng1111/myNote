//
//  QYSHController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/6.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "QYSHController.h"
#import "AFNetworking.h"
#import "Constants.h"

#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import <MJRefresh.h>
#import "QYSHDetailController.h"

@interface QYSHController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation QYSHController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"222 %@", _pageType);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateViewControllerByUserType) name:@"qysh" object:nil];
    
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    self.data = [[NSMutableArray alloc]init];
    
    [self addTableViewHeader];
    
    [self showLoadingView:self.tableView];
    [self onRefresh];
    
}

- (void)updateViewControllerByUserType {
    NSLog(@"收到审核修改通知");
    [self onRefresh];
}


- (void)onRefresh {
    NSDictionary *parameters  = nil;
    if([_pageType isEqualToString:@"Wait"]){
        parameters = [URLAndParmFactory makeEnterprisesParm:@"0"];
    }else{
        parameters = [URLAndParmFactory makeEnterprisesParm:@"1"];
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:ENTERPRISES_URL parameters:parameters success:^(id responseObject) {
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:responseObject];
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
    
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //取消选中效果
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    [QYSHDetailController Go:self withObject:[self.data[indexPath.row] objectForKey:@"userCd"]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _data.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"QYSHViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    
    UILabel *lable1 = [cell viewWithTag:1];
    UILabel *lable2 = [cell viewWithTag:2];
    UILabel *lable3 = [cell viewWithTag:3];
    UILabel *lable4 = [cell viewWithTag:4];
    
    lable1.text = [parameters objectForKey: @"enterpriseName"];
    //    lable1.text = [propertyName stringByAppendingFormat:@"%@", [parkingName isEqualToString:@""] ? @"": [NSString stringWithFormat:@"(%@)",parkingName]];
    if([[parameters objectForKey: @"contractStatus"] isEqualToString:@"0"]){
        lable2.text = @"待审核";
    }else{
        lable2.text = @"已签约";
    }
    lable3.text = [parameters objectForKey: @"addressLine"] ;
    lable4.text = [NSString stringWithFormat:@"企业编号: %@",[parameters objectForKey: @"businessCode"]];
    
    return  cell;
}


- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}


@end

