//
//  ShareChildController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/6.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "ShareChildController.h"
#import "AFNetworking.h"
#import "Constants.h"
#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import <MJRefresh.h>
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>

@interface ShareChildController ()<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic , strong) NSMutableArray *data;

@end

@implementation ShareChildController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"222 %@", _pageType);
    
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    self.data = [[NSMutableArray alloc]init];
    
    [self addTableViewHeader];
    
    [self showLoadingView:self.tableView];
    [self onRefresh];
}

- (void)onRefresh {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userType = [userDefaults objectForKey:@"kindOfUser"];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    NSString *url = nil;
    NSDictionary *params = nil;
    if ([_pageType isEqualToString:@"Request"]){
        if ([userType isEqualToString:@"2"]) {
            url = requestforauth_URL;
            params = @{@"userCd":userCd};
        } else {
            url = requestforanswer_URL;
            params = @{@"userCd":userCd};
        }
        NSLog(@"url = %@", url);
        NSLog(@"params = %@", params);
    }else if([_pageType isEqualToString:@"Making"]){
        url = [URLAndParmFactory makeSharedTaskURL:userCd];
    }else if([_pageType isEqualToString:@"History"]){
        url = [URLAndParmFactory makeSharedHistoryListURL:userCd];
    }
    
    [manager httpRequest:self url:url parameters:params success:^(id responseObject) {
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:responseObject];
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
}

#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    NSLog(@"buttonEvent");
    [self.tableView reloadEmptyDataSet];
    [self onRefresh];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
    //取消选中效果
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _data.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([_pageType isEqualToString:@"Making"]){
        return 160;
    }else{
        return 100;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"ShareChildViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    
    //默认点tableCell中有textLable imageView deta控件
    UILabel *tv_name = [cell viewWithTag:1];
    UILabel *tv_status = [cell viewWithTag:2];
    UILabel *tv_1 = [cell viewWithTag:3];
    UILabel *tv_2 = [cell viewWithTag:4];
    UILabel *tv_3 = [cell viewWithTag:5];
    UILabel *tv_4 = [cell viewWithTag:6];
    UILabel *tv_5 = [cell viewWithTag:7];
    UIButton *btn_disagree = [cell viewWithTag:8];
    UIButton *btn_agree = [cell viewWithTag:9];
    UIButton *btn_black = [cell viewWithTag:10];
    
    btn_disagree.hidden = true;
    btn_agree.hidden = true;
    btn_black.hidden = true;
    tv_3.hidden = true;
    tv_4.hidden = true;
    
    
    //    final CarRequestForanwser item = (CarRequestForanwser) multiItemEntity;
    //    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    //显示状态
    tv_status.text = [self getStatusStr:[parameters objectForKey: @"status"]];
    
    if([_pageType isEqualToString:@"Request"]){
        tv_name.text = [NSString stringWithFormat:@"%@(%@)",[parameters objectForKey: @"licensePlate"], [[NSUserDefaults standardUserDefaults] objectForKey:@"userCd"]];
        tv_1.text = [NSString stringWithFormat:@"停车位: %@",[parameters objectForKey: @"parkingName"]];
        tv_2.text = [NSString stringWithFormat:@"预定时间: %@ - %@",[parameters objectForKey: @"startDateTimeDisplay"],[parameters objectForKey: @"endDateTimeDisplay"]];
        
        NSString *status = [parameters objectForKey: @"status"];
        if ([status isEqualToString:@"1"]) {
            btn_agree.hidden = false;
            btn_disagree.hidden = false;
            [btn_agree setTitle:@"同意" forState:nil];
            [btn_disagree setTitle:@"拒绝" forState:nil];
        } else {
            btn_agree.hidden = true;
            btn_disagree.hidden = false;
        }
        
        if([parameters objectForKey: @"authorizeStatus"] !=nil) {
            if (![[parameters objectForKey: @"authorizeStatus"] isEqualToString:@"1"]) {
                btn_agree.hidden = true;
                btn_disagree.hidden = true;
            }
        }
    }else if([_pageType isEqualToString:@"Making"]){
        tv_3.hidden = false;
        tv_4.hidden = false;
        
        tv_name.text = [NSString stringWithFormat:@"%@(%@)",[parameters objectForKey: @"licensePlate"], [[NSUserDefaults standardUserDefaults] objectForKey:@"userCd"]];
        tv_1.text = [NSString stringWithFormat:@"停车位: %@",[parameters objectForKey: @"parkingDisplayName"]];
        tv_2.text = [NSString stringWithFormat:@"预定时间: %@ - %@",[parameters objectForKey: @"planStartDateTime"],[parameters objectForKey: @"planEndDateTime"]];
        tv_3.text = [NSString stringWithFormat:@"停车时间: %@ - 现在",[parameters objectForKey: @"startDateTime"]];
        tv_4.text = [NSString stringWithFormat:@"计费: %@元",[parameters objectForKey: @"price"]];
        
        
    }else {
        tv_3.hidden = false;
        tv_4.hidden = false;
        
        tv_name.text = [NSString stringWithFormat:@"%@(%@)",[parameters objectForKey: @"licensePlate"], [[NSUserDefaults standardUserDefaults] objectForKey:@"userCd"]];
        tv_1.text = [NSString stringWithFormat:@"停车位: %@",[parameters objectForKey: @"parkingCode"]];
        tv_2.text = [NSString stringWithFormat:@"预定时间: %@ - %@",[parameters objectForKey: @"startDateTimeDisplay"],[parameters objectForKey: @"endDateTimeDisplay"]];
        
        if([[parameters objectForKey: @"status"] isEqualToString:@"9"]) {
            tv_3.hidden = false;
            tv_4.hidden = false;
            
            tv_3.text = [NSString stringWithFormat:@"停车时间: %@ - %@",[parameters objectForKey: @"realStartDateTimeDisplay"],[parameters objectForKey: @"realEndDateTimeDisplay"]];
            tv_4.text = [NSString stringWithFormat:@"停车收入: %@元",[parameters objectForKey: @"price"]];
        }else {
            tv_3.hidden = true;
            tv_4.hidden = true;
        }
        
    }
    
    NSString *status = [parameters objectForKey: @"status"];
    if ([status isEqualToString:@"0"]) {
        btn_agree.hidden = true;
        btn_disagree.hidden = true;
    }
    
    return  cell;
}

- (NSString*)getStatusStr:(NSString*) statusStr{
    int status = [statusStr intValue];
    NSString *str = nil;
    switch (status) {
        case 1:
            str = @"请求中";
            break;
        case 2:
            str = @"已同意";
            break;
        case 3:
            str = @"被拒绝";
            break;
        case 4:
            str = @"已取消";
            break;
        case 5:
            str = @"已确认";
            break;
        case 6:
            str = @"任务进行中";
            break;
        case 7:
            str = @"被强制拒绝";
            break;
        case 8:
            str = @"已强制取消";
            break;
        case 9:
            str = @"任务已结束";
            break;
    }
    return str;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}



@end

