//
//  ViewController.m
//  carshare
//
//  Created by 森鸿 on 2018/5/18.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "MainController.h"

#import "MapController.h"
#import "ShareController.h"
#import "MineController.h"
#import "Constants.h"
#import "ShareCarController.h"
#import "DialogFactory.h"
#import "LoginController.h"
#import "UIColor+Hex.h"

@interface MainController ()

@property (nonatomic, strong) MapController *mapController;
@property (nonatomic, strong) ShareController *shareController1;
@property (nonatomic, strong) ShareController *shareController2;
@property (nonatomic, strong) ShareCarController *shareCarController;
@property (nonatomic, strong) MineController *mineController;

@end

@implementation MainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"%@", AUDITENTERPRISE_URL);
}

-(void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateViewControllerByUserType:) name:@"labelChange" object:nil];
}

//-(void)dealloc {
//    [[NSNotificationCenter defaultCenter] removeObserver:self];
//}



- (void)updateViewControllerByUserType:(NSNotification *)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if(self.mapController==nil){ self.mapController=[storyboard instantiateViewControllerWithIdentifier:@"MapController"];}
    if(self.shareController1==nil){ self.shareController1=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];}
    if(self.shareController2==nil){ self.shareController2=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];}
    if(self.shareCarController==nil){ self.shareCarController=[storyboard instantiateViewControllerWithIdentifier:@"ShareCarController"];}
    if(self.mineController==nil){ self.mineController=[storyboard instantiateViewControllerWithIdentifier:@"MineController"];}
    
    NSDictionary *dic = sender.userInfo;
    NSLog(@"%@", dic[@"kindOfUser"]);
    NSString *userType = dic[@"kindOfUser"];
    BOOL ShareUser = [dic[@"ShareUser"] boolValue];
    NSLog(@"用户类型：%@ %d", userType, ShareUser);
    if ([userType isEqualToString:@"0"]){ //普通用户
        
        self.mapController.tabBarItem.image = [UIImage imageNamed:@"social_android_outline"];
        self.mapController.tabBarItem.selectedImage = [UIImage imageNamed:@"social_android"];
        self.mapController.tabBarItem.title=@"地图";
        
        self.shareController1.tabBarItem.image = [UIImage imageNamed:@"stoppacking_outline"];
        self.shareController1.tabBarItem.selectedImage = [UIImage imageNamed:@"stoppacking"];
        self.shareController1.tabBarItem.title=@"停车";
        self.shareController1.pageType = @"分享人";
        [self.shareController1 updatePageByPageType];
        
        self.shareController2.tabBarItem.image = [UIImage imageNamed:@"social_apple_outline"];
        self.shareController2.tabBarItem.selectedImage = [UIImage imageNamed:@"social_apple"];
        self.shareController2.tabBarItem.title=@"任务";
        self.shareController2.pageType = @"task";
        [self.shareController2 updatePageByPageType];
        
        self.shareCarController.tabBarItem.image = [UIImage imageNamed:@"social_bitcoin_outline"];
        self.shareCarController.tabBarItem.selectedImage = [UIImage imageNamed:@"social_bitcoin"];
        self.shareCarController.tabBarItem.title=@"分享";
        [self.shareCarController onRefresh];
        
        self.mineController.tabBarItem.image = [UIImage imageNamed:@"social_buffer_outline"];
        self.mineController.tabBarItem.selectedImage = [UIImage imageNamed:@"social_buffer"];
        self.mineController.tabBarItem.title=@"个人";
        
        
        if(ShareUser){
            self.viewControllers = @[self.mapController,self.shareController1,self.shareController2,self.shareCarController,self.mineController];
        }else{
            self.viewControllers = @[self.mapController,self.shareController1,self.shareController2,self.mineController];
        }
        
        
        
        //        ShareController *c3=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];
        //        c3.pageType = @"task";
        //        c3.tabBarItem.title=@"任务";
        //
        //        ShareCarController *c4=[storyboard instantiateViewControllerWithIdentifier:@"ShareCarController"];
        //        c4.pageType = @"物业";
        //        c4.tabBarItem.title=@"分享";
        //
        //        MineController *c5=[storyboard instantiateViewControllerWithIdentifier:@"MineController"];
        //        c5.tabBarItem.title=@"个人";
        
        //4.
        
        
        
    }else if([userType isEqualToString:@"3"]){ //管理者
        //        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        //        //创建子控制器
        //        ShareController *c1=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];
        //        c1.pageType = @"物业审核";
        //        c1.tabBarItem.title=@"物业审核";
        //
        //        ShareController *c2=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];
        //        c2.pageType = @"企业审核";
        //        c2.tabBarItem.title=@"企业审核";
        
        self.shareController1.tabBarItem.title=@"物业审核";
        self.shareController1.pageType = @"物业审核";
        [self.shareController1 updatePageByPageType];
        
        self.shareController2.tabBarItem.title=@"企业审核";
        self.shareController2.pageType = @"企业审核";
        [self.shareController2 updatePageByPageType];
        
        self.viewControllers = @[self.shareController1, self.shareController2];
    }else if([userType isEqualToString:@"2"]){ //物业
        //        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        //
        //        MapController *c1=[storyboard instantiateViewControllerWithIdentifier:@"MapController"];
        //        c1.tabBarItem.title=@"地图";
        //
        //        ShareController *c2=[storyboard instantiateViewControllerWithIdentifier:@"ShareController"];
        //        c2.pageType = @"物业停车";
        //        c2.tabBarItem.title=@"停车";
        //
        //        ShareCarController *c3=[storyboard instantiateViewControllerWithIdentifier:@"ShareCarController"];
        //        c3.pageType = @"物业";
        //        c3.tabBarItem.title=@"分享";
        
        self.mapController.tabBarItem.title=@"地图";
        
        self.shareController1.tabBarItem.title=@"停车";
        self.shareController1.pageType = @"物业停车";
        [self.shareController1 updatePageByPageType];
        
        self.shareCarController.tabBarItem.title=@"分享";
        [self.shareCarController onRefresh];
        
        self.viewControllers = @[self.mapController,self.shareController1, self.shareCarController];
    }else if([userType isEqualToString:@"1"]){ //企业
        //        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        //
        //        if(self.mapController==nil){
        //            NSLog(@"空空空空空");
        //            self.mapController=[storyboard instantiateViewControllerWithIdentifier:@"MapController"];
        //            self.mapController.tabBarItem.title=@"地图";
        //        }
        
        self.mapController.tabBarItem.title=@"地图";
        
        //4.
        self.viewControllers = @[self.mapController];
    }else{
        
    }
    
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithTitle:@"注销" style:UIBarButtonItemStylePlain target:self action:@selector(clickLeftBarBtnItem:)];
    self.navigationItem.rightBarButtonItem = rightItem;//设置右边按钮
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithHexString:@"#0590F5"];
    
    
}


- (void)clickLeftBarBtnItem:(UIBarButtonItem *)sender {
    NSLog(@"1111");
    [DialogFactory showTwoBtnDialog:self withTitle:@"提示" withMsg:@"是否确认注销？" isCancelable:YES btn1Text:@"取消" btn2Text:@"确定" handle1:^(UIAlertAction *action) {
        
    } handle2:^(UIAlertAction *action) {
        [LoginController Go:self];
    }];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end

