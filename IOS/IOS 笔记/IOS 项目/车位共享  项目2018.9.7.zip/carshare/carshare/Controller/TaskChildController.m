//
//  TaskChildController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/8.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "TaskChildController.h"
#import "AFNetworking.h"
#import "Constants.h"
#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import <MJRefresh.h>
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#import "TaskDetailController.h"

@interface TaskChildController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic , strong) NSMutableArray *data;

@end

@implementation TaskChildController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"222 %@", _pageType);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTaskStatus) name:@"TaskStatusUpdate" object:nil];
    
    self.tableView.emptyDataSetSource = self;
    self.tableView.emptyDataSetDelegate = self;
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    self.data = [[NSMutableArray alloc]init];
    
    [self addTableViewHeader];
    
    [self showLoadingView:self.tableView];
    [self onRefresh];
}

- (void)updateTaskStatus {
    [self onRefresh];
}

- (void)onRefresh {
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userCd = [userDefaults objectForKey:@"userCd"];
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    
    NSString *url = nil;
    if ([_pageType isEqualToString:@"Request"]){
        url = [URLAndParmFactory makeTaskRequestURL:userCd];
    }else if([_pageType isEqualToString:@"Making"]){
        url = [URLAndParmFactory makeTaskParkingURL:userCd];
    }else if([_pageType isEqualToString:@"WaitPay"]){
        url = [URLAndParmFactory makeTaskWaitPayURL:userCd];
    }else if([_pageType isEqualToString:@"History"]){
        url = [URLAndParmFactory makeTaskHistoryURL:userCd];
    }
    
    [manager httpRequest:self url:url success:^(id responseObject) {
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:responseObject];
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
    
}

#pragma mark 空白页点击事件 如果需要显示loading 则重写此方法后, 调用[self.tableView reloadEmptyDataSet]
-(void)emptyViewClick{
    NSLog(@"buttonEvent");
    [self.tableView reloadEmptyDataSet];
    [self onRefresh];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //取消选中效果
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    TaskDetailController *controller = [storyboard instantiateViewControllerWithIdentifier:@"TaskDetailController"];
    controller.pageType = self.pageType;
    controller.pageDic = self.data[indexPath.row];
    [self.navigationController pushViewController:controller animated:YES];
    
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _data.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"TaskChildViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    
    UILabel *lable1 = [cell viewWithTag:1];
    UILabel *lable2 = [cell viewWithTag:2];
    UILabel *lable3 = [cell viewWithTag:3];
    UILabel *lable4 = [cell viewWithTag:4];
    UILabel *lable5 = [cell viewWithTag:5];
    
    lable1.text = [parameters objectForKey: @"addressLine"];
    lable3.text = [parameters objectForKey: @"licensePlate"];
    if([parameters objectForKey: @"status"] !=nil){
        lable2.text = [self getStatusStr:[parameters objectForKey: @"status"]];
        int status = [[parameters objectForKey: @"status"] intValue];
        if(status>0&&status<6){
            lable5.hidden = true;
        }else if(status==6){
            lable1.text = [parameters objectForKey: @"parkingDisplayName"];
            lable3.text = [parameters objectForKey: @"licensePlate"];
        }
    }
    
    
    
    if([parameters objectForKey: @"payStatus"] != nil){
        lable2.text = [self getPayStatusStr:[parameters objectForKey: @"payStatus"]];
    }
    
    lable4.text = [parameters objectForKey: @"addressLine"];
    if([parameters objectForKey: @"price"]==nil){
        lable5.text = [NSString stringWithFormat:@"预计费用：0.0元"];
    }else{
        lable5.text = [NSString stringWithFormat:@"预计费用：￥%@元",[parameters objectForKey: @"price"]];
    }
    
    return  cell;
}

- (NSString*)getStatusStr:(NSString*) statusStr{
    int status = [statusStr intValue];
    NSString *str = nil;
    switch (status) {
        case 0:
            str = @"抢单中";
            break;
        case 1:
            str = @"请求中";
            break;
        case 2:
            str = @"已同意";
            break;
        case 3:
            str = @"被拒绝";
            break;
        case 4:
            str = @"已取消";
            break;
        case 5:
            str = @"已确认";
            break;
        case 6:
            str = @"任务进行中";
            break;
        case 7:
            str = @"被强制拒绝";
            break;
        case 8:
            str = @"已强制取消";
            break;
        case 9:
            str = @"任务已结束";
            break;
    }
    return str;
}

- (NSString*)getPayStatusStr:(NSString*) statusStr{
    int status = [statusStr intValue];
    NSString *str = nil;
    switch (status) {
        case 1:
            str = @"进行中";
            break;
        case 2:
            str = @"未支付";
            break;
        case 9:
            str = @"余额不足";
            break;
    }
    return str;
}

- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}

@end

