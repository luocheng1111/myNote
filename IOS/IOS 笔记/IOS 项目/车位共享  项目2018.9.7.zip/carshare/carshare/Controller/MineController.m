//
//  MineController.m
//  carshare
//
//  Created by 森鸿 on 2018/5/18.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "MineController.h"
#import "LoginController.h"

@interface MineController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic , strong) NSArray *data; // 所有的省份
@property (weak, nonatomic) IBOutlet UIImageView *iv;

@end

@implementation MineController

- (void)viewDidLoad {
    [super viewDidLoad];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    
    //设置头像变圆角
    [self.iv.layer setCornerRadius:self.iv.frame.size.width/2];
    [self.iv.layer setMasksToBounds:YES];
    
    self.data = @[
                  @{@"image" : @"msg", @"title" : @"个人中心"},
                  @[@{@"image" : @"zh", @"title" : @"账户信息"}
                    , @{@"image" : @"packing1", @"title" : @"发布车位"}
                    , @{@"image" : @"wallet", @"title" : @"我的钱包"}
                    , @{@"image" : @"sc3", @"title" : @"我的收藏"}
                    , @{@"image" : @"fxiang", @"title" : @"分享"}]];
    
    
}

- (IBAction)test:(id)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"labelChange" object:self userInfo:@{@"kindOfUser":@"kindOfUser"}];
}


//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [LoginController Go:self];
    if(indexPath.row==1){
        NSDictionary *parameters  = @{@"contractStatus": @"1"};
        NSLog(@"%@", parameters);
        NSLog(@"%@", [self convertToJSONData:parameters]);
    }
}

- (NSString*)convertToJSONData:(id)infoDict{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:infoDict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    NSString *jsonString = @"";
    
    if (! jsonData)
    {
        NSLog(@"Got an error: %@", error);
    }else
    {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    jsonString = [jsonString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];  //去除掉首尾的空白字符和换行字符
    
    [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    return jsonString;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) { //section组
        return 1;
    } else if (section == 1) {
        return 5;
    }
    return 0;
}


//头视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 20;
}
//脚视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"MineViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    UIImageView *iv = [cell viewWithTag:1];
    UILabel *tv_title = [cell viewWithTag:2];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    
    
    if (section == 0) {
        NSDictionary *dic = self.data[indexPath.section];
        iv.image = [UIImage imageNamed: [dic objectForKey:@"image"]];
        tv_title.text = [dic objectForKey:@"title"];
        //        if (row == 0) {
        //            cell.textLabel.text = @"通用";
        //        } else if(row == 1) {
        //            cell.textLabel.text = @"设置";
        //        }
    } else {
        NSArray *arr = self.data[indexPath.section];
        NSDictionary *dic = arr[indexPath.row];
        iv.image = [UIImage imageNamed: [dic objectForKey:@"image"]];
        tv_title.text = [dic objectForKey:@"title"];
        
    }
    return cell;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

