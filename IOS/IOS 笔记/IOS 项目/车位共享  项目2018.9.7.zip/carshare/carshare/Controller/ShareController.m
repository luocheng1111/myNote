//
//  ShareController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/6.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "ShareController.h"
#import "ShareChildController.h"

#import "WYSHController.h"
#import "QYSHController.h"
#import <VTMagic/VTMagic.h>
#import "TaskChildController.h"
#import "SelectParkingController.h"
#import "UIColor+Hex.h"

@interface ShareController ()<VTMagicViewDataSource, VTMagicViewDelegate>

@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong)  NSArray *pageTitleList;
@property (nonatomic, strong)  NSArray *pageControllerList;
@end

@implementation ShareController

- (void)viewDidLoad {
    [super viewDidLoad];
    //    NSLog(@"%@", _pageType);
    
    //    self.edgesForExtendedLayout = UIRectEdgeAll;
    self.view.backgroundColor = [UIColor whiteColor];
    [self addChildViewController:self.magicController];
    [self.view addSubview:_magicController.view];
    [self.view setNeedsUpdateConstraints];
    
    //    [self updatePageByPageType];
    
    [_magicController.magicView reloadData];
}


- (void)updatePageByPageType{
    NSLog(@"pageType:%@", _pageType);
    
    if ([_pageType isEqualToString:@"物业审核"]){ //物业审核
        WYSHController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"WYSHController"];
        vc1.pageType = @"Wait";
        WYSHController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"WYSHController"];
        vc2.pageType = @"Pass";
        
        _pageTitleList = @[@"待审核", @"已签约"];
        _pageControllerList = @[vc1,vc2];
        [_magicController.magicView reloadData];
    }else if([_pageType isEqualToString:@"企业审核"]){
        QYSHController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"QYSHController"];
        vc1.pageType = @"Wait";
        QYSHController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"QYSHController"];
        vc2.pageType = @"Pass";
        
        _pageTitleList = @[@"待审核", @"已签约"];
        _pageControllerList = @[vc1,vc2];
        [_magicController.magicView reloadData];
    }else if([_pageType isEqualToString:@"分享人"]){
        ShareChildController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc1.pageType = @"Request";
        ShareChildController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc2.pageType = @"Making";
        ShareChildController *vc3 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc3.pageType = @"History";
        
        _pageTitleList = @[@"请求中", @"进行中", @"历史记录"];
        _pageControllerList = @[vc1,vc2,vc3];
        [_magicController.magicView reloadData];
    }else if([_pageType isEqualToString:@"task"]){
        TaskChildController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TaskChildController"];
        vc1.pageType = @"Request";
        TaskChildController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TaskChildController"];
        vc2.pageType = @"Making";
        TaskChildController *vc3 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TaskChildController"];
        vc3.pageType = @"WaitPay";
        TaskChildController *vc4 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TaskChildController"];
        vc4.pageType = @"History";
        
        _pageTitleList = @[@"请求中", @"进行中", @"待支付", @"历史记录"];
        _pageControllerList = @[vc1,vc2,vc3,vc4];
        [_magicController.magicView reloadData];
    }else if([_pageType isEqualToString:@"物业停车"]){
        ShareChildController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc1.pageType = @"Request";
        ShareChildController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc2.pageType = @"Making";
        ShareChildController *vc3 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ShareChildController"];
        vc3.pageType = @"History";
        
        _pageTitleList = @[@"请求中", @"进行中", @"历史记录"];
        _pageControllerList = @[vc1,vc2,vc3];
        [_magicController.magicView reloadData];
    }else if([_pageType isEqualToString:@"selectParking"]){
        SelectParkingController *vc1 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SelectParkingController"];
        vc1.pageType = @"One";
        vc1.pageDic = self.pageDic;
        SelectParkingController *vc2 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SelectParkingController"];
        vc2.pageType = @"Two";
        vc2.pageDic = self.pageDic;
        SelectParkingController *vc3 = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"SelectParkingController"];
        vc3.pageType = @"Three";
        vc3.pageDic = self.pageDic;
        
        _pageTitleList = @[@"小区车位", @"个人车位", @"公共车位"];
        _pageControllerList = @[vc1,vc2,vc3];
        [_magicController.magicView reloadData];
    }
    
}


#pragma mark - accessor methods
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        _magicController.view.translatesAutoresizingMaskIntoConstraints = NO;
        _magicController.magicView.navigationColor = [UIColor whiteColor];
        _magicController.magicView.sliderColor = [UIColor colorWithHexString:@"#fea0a2"];
        _magicController.magicView.switchStyle = VTSwitchStyleDefault;
        _magicController.magicView.layoutStyle = VTLayoutStyleCenter;
        _magicController.magicView.navigationHeight = 44.f;
        //        _magicController.magicView.againstStatusBar = YES;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        [_magicController.magicView setHeaderHidden:_magicController.magicView.againstStatusBar];
    }
    return _magicController;
    
    
}



#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    return _pageTitleList;
}

- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex
{
    static NSString *itemIdentifier = @"itemIdentifier";
    UIButton *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (!menuItem) {
        menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitleColor:RGBCOLOR(50, 50, 50) forState:UIControlStateNormal];
        [menuItem setTitleColor:[UIColor colorWithHexString:@"#febebf"] forState:UIControlStateSelected];
        menuItem.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:15.f];
    }
    return menuItem;
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex{
    return [_pageControllerList objectAtIndex:pageIndex];
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

