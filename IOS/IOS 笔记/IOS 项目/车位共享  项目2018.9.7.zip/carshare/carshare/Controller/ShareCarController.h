//
//  ShareCarController.h
//  carshare
//
//  Created by 森鸿 on 2018/6/8.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseController.h"

@interface ShareCarController : BaseController

@property (nonatomic , strong) NSString *pageType;

- (void)onRefresh;

@end

