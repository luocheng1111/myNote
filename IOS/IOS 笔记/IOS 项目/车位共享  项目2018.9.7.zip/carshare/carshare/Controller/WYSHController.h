//
//  WYSHController.h
//  carshare
//
//  Created by 森鸿 on 2018/6/6.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseController.h"

@interface WYSHController : BaseController<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic , strong) NSString *pageType;


@end

