//
//  WYSHController.m
//  carshare
//
//  Created by 森鸿 on 2018/6/6.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "WYSHController.h"
#import "AFNetworking.h"
#import "Constants.h"

#import "AFNetworkingHelper.h"
#import "URLAndParmFactory.h"
#import "WYSHDetailController.h"
#import <MJRefresh.h>

@interface WYSHController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic , strong) NSMutableArray *data;

@end

@implementation WYSHController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"%@", _pageType);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateViewControllerByUserType) name:@"wysh" object:nil];
    
    // 删除单元格分隔线
    self.tableView.tableFooterView = [UIView new];
    // 自适应TabBar的高度，不被UITabBar遮盖
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    
    self.data = [[NSMutableArray alloc]init];
    
    [self addTableViewHeader];
    
    [self showLoadingView:self.tableView];
    [self onRefresh];
}

-(void)viewWillAppear:(BOOL)animated {
    
}

- (void)updateViewControllerByUserType {
    NSLog(@"收到审核修改通知");
    [self onRefresh];
}


- (void)onRefresh {
    NSDictionary *parameters  = nil;
    if([_pageType isEqualToString:@"Wait"]){
        parameters = [URLAndParmFactory makePropertiesParm:@"0"];
    }else{
        parameters = [URLAndParmFactory makePropertiesParm:@"1"];
    }
    
    AFNetworkingHelper *manager = [AFNetworkingHelper shaerdInstance];
    [manager httpRequest:self url:PROPERTIES_URL parameters:parameters success:^(id responseObject) {
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:responseObject];
        if(self.data.count==0){
            [self showEmptyView:self.tableView];
        }
        [self.tableView reloadData];
    } onFinish:^(BOOL isError, NSString *errorMsg) {
        if (isError) {
            [self.data removeAllObjects];
            [self showEmptyView:self.tableView];
        }
        [self.tableView.mj_header endRefreshing];
    }];
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //取消选中效果
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    [WYSHDetailController Go:self withObject:[self.data[indexPath.row] objectForKey:@"userCd"]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _data.count;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 110;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"WYSHViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *parameters = [self.data objectAtIndex:indexPath.row];
    NSString *propertyName = [parameters objectForKey: @"propertyName"];
    NSString *parkingName = [parameters objectForKey: @"parkingName"];
    NSString *addressLine = [parameters objectForKey: @"addressLine"];
    NSString *contractStatus = [parameters objectForKey: @"contractStatus"];
    //    NSLog(@"contractStatus %@", contractStatus);
    NSString *validStartDisplay = [parameters objectForKey: @"validStartDisplay"];
    NSString *validEndDisplay = [parameters objectForKey: @"validEndDisplay"];
    NSString *ApplyDateTimeDisplay = [parameters objectForKey: @"ApplyDateTimeDisplay"];
    
    UILabel *lable1 = [cell viewWithTag:1];
    UILabel *lable2 = [cell viewWithTag:2];
    UILabel *lable3 = [cell viewWithTag:3];
    UILabel *lable4 = [cell viewWithTag:4];
    UILabel *lable5 = [cell viewWithTag:5];
    
    //        lable1.text = propertyName;
    lable1.text = [propertyName stringByAppendingFormat:@"%@", parkingName ==nil ? @"": [NSString stringWithFormat:@"(%@)",parkingName]];
    if([contractStatus isEqualToString:@"0"]){
        lable2.text = @"申请中";
    }else{
        lable2.text = @"已签约";
    }
    lable3.text = addressLine ;
    lable4.text = [NSString stringWithFormat:@"合同有效期: %@ - %@",validStartDisplay, validEndDisplay];
    lable5.text = [NSString stringWithFormat:@"申请时间: %@",ApplyDateTimeDisplay];
    return  cell;
}

- (void)addTableViewHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(onRefresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}



@end

