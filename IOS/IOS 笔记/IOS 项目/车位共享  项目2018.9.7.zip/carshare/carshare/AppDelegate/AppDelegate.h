//
//  AppDelegate.h
//  carshare
//
//  Created by 森虹 on 2018/8/27.
//  Copyright © 2018年 sh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

