//
//  URLMacro.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#ifndef URLMacro_h
#define URLMacro_h

//日志打印管理
#define isHttpLogPrint true

// DB
#define DBTableName_UserInfo @"UserInfo"

// NotificationType
#define kNotificationTypeCurrentUserChange @"CurrentUserChange"
#define kNotificationTypeRemoveCurrentUser @"RemoveCurrentUser"
#define kNotificationTypeListDataChange @"ListDataChange"

// 日期键值
#define kDateTypeYears @"years"
#define kDateTypeMonths @"months"
#define kDateTypeDays @"days"
#define kDateTypeHours @"hours"
#define kDateTypeMinutes @"minutes"


// Http
#define BaseHost                @"http://202.96.207.14:8080/tthparking/webresources/"

// User服务器
#define User                    BaseHost"user/"
#define PROPERTIES_URL          User"properties"            //物业审核列表
#define AUDITPROPERTY_URL       User"auditproperty"         //修改物业审核状态
#define ENTERPRISES_URL         User"enterprises"           //物业公司审核列表
#define AUDITENTERPRISE_URL     User"auditenterprise"       //修改物业公司审核状态
#define BlackList_URL           User"black"                 //用户拉黑列表
#define deleteBlack_URL         User"blackusercd/delete"    //删除拉黑
#define blackuser_URL           User"black"                 //拉黑用户
#define property_URL            User"property"              //物业详情
#define enterprise_URL          User"enterprise"            //公司详情
#define attachment_URL          User"attachment"            //获取图片
#define propertyparking_URL     User"propertyparking"       //物业车位详细信息
#define userparking_URL         User"userparking"           //用户车位详细信息
#define licenseplate_URL        User"licenseplate"          //获取车牌号
#define pauseparking_URL        User"pauseparking"          //停止车位分享
#define restartparking_URL      User"restartparking"        //开始车位分享
#define refuseparking_URL       User"refuseparking"         //拒绝共享请求
#define agreeparking_URL        User"agreeparking"          //同意共享请求
#define deleteparking_URL       User"deleteparking"         //删除车位分享
#define modifyparking_URL       User"modifyparking"         //修改车位分享


//Task 服务器
#define Task                    BaseHost"task/"
#define APPROVAL_URL            Task"request/approval"
#define MESSGES                 Task"messages"
#define APPROVAL_DIRECT         Task"parking/direct"//立即停车
#define APPROVAL_DELAY          Task"request/extend"
#define APPROVAL_SHORT          Task"request/shorten"
#define REFUSE_URL              Task"request/refuse"
#define enforcerefuse_URL       Task"request/enforcerefuse" //强制拒绝
#define CANCEL_URL              Task"request/cancel"
#define requestforanswer_URL    Task"requestforanswer"//分享人 获取车位列表
#define requestforauth_URL      Task"requestforauth"//物业 获取车位列表
#define sharetasks_URL          Task"sharetasks"//分享人 进行中
#define sharetask_URL           Task"sharetask"//分享人 进行中 详情
#define sharedhistory_URL       Task"history/owner"
#define requesthistory_URL      Task"request/history" //指定请求的历史
#define taskrequests_URL        Task"requests"       //方法名——获取请求列表---请求人
#define taskrequest_URL         Task"request"       //方法名——获取请求列表---请求人
#define taskparkingtasks_URL    Task"parkingtasks"   //方法名——获取进行中任务列表---请求人
#define taskparkingtask_URL     Task"parkingtask"
#define taskhistory_URL         Task"history"        //方法名——获取历史请求列表---请求人
#define SEARCH_URL              Task"searchparking"  //搜索附近车位
#define SEARCHCHSABLE_URL       Task"searchusableparking"  //搜索附近指定时间段车位
#define requestbroadcast_URL    Task"request/broadcast"    //添加抢单请求
#define requestadd_URL          Task"request/add"          //添加请求
#define requestshorten_URL      Task"request/shorten"      //缩短
#define requestextend_URL       Task"request/extend"       //延长
#define requestconfirm_URL       Task"request/confirm"      //确认
#define requestexecute_URL       Task"request/execute"      //开始停车
#define requestending_URL       Task"request/ending"       //结束停车



//Payment 服务器
#define PAYMENT                 BaseHost"payment/"
#define WITHDRAWAL_URL          PAYMENT"withdrawal"//提现
#define WALLET_URL              PAYMENT"wallet"//我的钱包
#define COUPON_URL              PAYMENT"coupon"//我的优惠券
#define DISCOUNT_URL            PAYMENT"discount"//我的打折卷
#define CASH_URL                PAYMENT"cash"//支付的信息
#define CASHHISTORY_URL         PAYMENT"cashhistory"//支付的历史记录
#define RECHARGE_URL            PAYMENT"alipay/recharge"//充值

//高德地图
#define KeySearck               @"https://restapi.amap.com/v3/assistant/inputtips?keywords=searchkey&key=389880a06e3f893ea46036f030c94700" //关键词检索


#endif


