//
//  CustomAnnotationView.m
//  CustomAnnotationDemo
//
//  Created by songjian on 13-3-11.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "CustomAnnotationView.h"
//#import "CustomCalloutView.h"

@implementation CustomAnnotationView


- (id)initWithAnnotation:(id<MAAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    
    if (self){
        self.bounds = CGRectMake(0.f, 0.f, 20.f, 30.f);
        
        //        self.backgroundColor = [UIColor grayColor];
        
        self.img = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 20.f, 30.f)];
        [self addSubview:self.img];
        
        //        /* Create name label. */
        //        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(kPortraitWidth + kHoriMargin,
        //                                                                           kVertMargin,
        //                                                                           kWidth - kPortraitWidth - kHoriMargin,
        //                                                                           kHeight - 2 * kVertMargin)];
        //        self.nameLabel.backgroundColor  = [UIColor clearColor];
        //        self.nameLabel.textAlignment    = NSTextAlignmentCenter;
        //        self.nameLabel.textColor        = [UIColor whiteColor];
        //        self.nameLabel.font             = [UIFont systemFontOfSize:15.f];
        //        [self addSubview:self.nameLabel];
    }
    
    return self;
}



- (void)btnAction{
    CLLocationCoordinate2D coorinate = [self.annotation coordinate];
    NSLog(@"coordinate = {%f, %f}", coorinate.latitude, coorinate.longitude);
}




@end
