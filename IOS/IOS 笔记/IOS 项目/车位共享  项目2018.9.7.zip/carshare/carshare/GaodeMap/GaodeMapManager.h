//
//  GaodeMapManager.h
//  GaodeMap
//
//  Created by 森鸿 on 2018/6/20.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import <Foundation/Foundation.h>
//基础定位类
#import <AMapFoundationKit/AMapFoundationKit.h>
//高德地图基础类
#import <MAMapKit/MAMapKit.h>
//搜索基础类
#import <AMapSearchKit/AMapSearchKit.h>
//高德导航类
//#import <AMapNaviKit/AMapNaviKit.h>
//gps纠偏类
//#import <JZLocationConverter.h>

@interface GaodeMapManager : NSObject

//初始化单例管理员对象
+(instancetype)sharedManager;

//Controller
@property (nonatomic,weak)UIViewController *controller;
//地图对象
@property(nonatomic,strong)MAMapView *mapView;
//当前定位
@property(nonatomic,strong)CLLocation *currentLocation;
//当前城市
@property (nonatomic,retain) NSString *currentCity;
//一个search对象，用于地理位置逆编码
@property(nonatomic,strong)AMapSearchAPI *search;
/* 起始点经纬度. */
@property(nonatomic)CLLocationCoordinate2D startCoor;
/* 终点经纬度. */
@property(nonatomic)CLLocationCoordinate2D destinationCoor;



/* 初始化地图对象 */
-(void)initMapView:(UIViewController *)controller;
/* 在View中显示地图并添加点 */
-(void)addAnomationToMapView:(UIViewController *)controller coor:(CLLocationCoordinate2D)coor view:(UIView *)view;
/* 逆编码 将坐标转换为具体地理信息 回调需实现onReGeocodeSearchDone: response:*/
-(void)regeoLocation:(CGFloat)lat longitude:(CGFloat)lon;

//在地图上添加点
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor;
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor title:(NSString *)title;
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor title:(NSString *)title subtitle:(NSString *)subtitle;
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon;
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon title:(NSString *)title;
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon title:(NSString *)title subtitle:(NSString *)subtitle;


//搜索Driver路线 如需在地图上绘制出，需要实现onRouteSearchDone:response: 方法
-(void)searchDriverLine:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;
-(void)searchDriverLine:(CGFloat)startLat startLon:(CGFloat)startLon desLat:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;
-(void)searchDriverLine:(CLLocationCoordinate2D)startCoor desCoor:(CLLocationCoordinate2D)desCoor isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;

//设置地图中心点
-(void)setMapCenter:(CGFloat)centerLat centerLon:(CGFloat)centerLon;
-(void)setMapCenter:(CGFloat)centerLat centerLon:(CGFloat)centerLon zoomLevel:(CGFloat)zoomLevel;
-(void)setMapCenter:(CLLocationCoordinate2D)centerCoor zoomLevel:(CGFloat)zoomLevel;





//设置地图的缩放层级
-(void)setZoomLevel:(CGFloat)zoomLevel;

//清除地图上的所有标记点
-(void)removeMapAllAnnotations;

//清除地图上的所有图层 比如路径线之类的
-(void)removeMapAllOverlays;

//根据关键字搜索附近
-(void)searchAroundWithKeyWords:(NSString *)keywords;

//根据关键字搜索
-(void)searchByKeyWords:(NSString *)keywords;

//绘制折线
-(void)drawLineWithArray:(NSArray *)array;



@end

