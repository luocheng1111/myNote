//
//  GaodeMapManager.m
//  GaodeMap
//
//  Created by 森鸿 on 2018/6/20.
//  Copyright © 2018年 luocheng. All rights reserved.
//

#import "GaodeMapManager.h"
#import "MANaviRoute.h"
#import "CommonUtility.h"

@interface GaodeMapManager()<MAMapViewDelegate,AMapSearchDelegate>
//搜索的结果
@property (nonatomic,strong)NSMutableArray *searchResultArr;
//搜索类型 搜索类型不一样 处理的方式不一样 "1"范围搜索 "2"关键词搜索
@property (nonatomic,retain) NSString *searchType;
/* 用于显示当前路线方案. */
@property (nonatomic) MANaviRoute * naviRoute;
@end
@implementation GaodeMapManager

#pragma mark --创建一个单例类对象
+(instancetype)sharedManager{
    static GaodeMapManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //初始化单例对象
        instance = [[GaodeMapManager alloc]init];
    });
    return instance;
}


#pragma mark --初始化地图对象
-(void)initMapView:(UIViewController *)controller{
    self.controller = controller;
    //    [self initSearch];
    ///地图需要v4.5.0及以上版本才必须要打开此选项（v4.5.0以下版本，需要手动配置info.plist）
    [AMapServices sharedServices].enableHTTPS = YES;
    ///初始化地图
    _mapView = [[MAMapView alloc] initWithFrame:self.controller.view.bounds];
    _mapView.delegate = controller.self;
    
    self.search =[[AMapSearchAPI alloc] init];
    self.search.delegate= controller.self;
    
    //把地图添加至view
    [self.controller.view insertSubview:_mapView atIndex:0];
    ///如果您需要进入地图就显示定位小蓝点，则需要下面两行代码
    _mapView.showsUserLocation = YES;
    _mapView.userTrackingMode = MAUserTrackingModeFollow;
    
    //设置地图缩放比例，即显示区域
    [_mapView setZoomLevel:17 animated:YES];
    //设置定位距离
    _mapView.distanceFilter = 200;
    
    //是否显示指南针 默认是显示
    _mapView.showsCompass= NO;
    //是否显示比例尺 默认是显示
    _mapView.showsScale= NO;
    //去除高德地图下方的 logo 图标
    [_mapView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            UIImageView * logoM = obj;
            logoM.layer.contents = (__bridge id)[UIImage imageNamed:@""].CGImage;
        }
    }];
}

//在View中显示地图并添加点
-(void)addAnomationToMapView:(UIViewController *)controller coor:(CLLocationCoordinate2D)coor view:(UIView *)view{
    ///地图需要v4.5.0及以上版本才必须要打开此选项（v4.5.0以下版本，需要手动配置info.plist）
    [AMapServices sharedServices].enableHTTPS = YES;
    ///初始化地图
    _mapView = [[MAMapView alloc] initWithFrame:view.bounds];
    //把地图添加至view
    [view insertSubview:_mapView atIndex:0];
    
    self.search =[[AMapSearchAPI alloc] init];
    self.search.delegate= controller.self;
    
    //设置地图缩放比例，即显示区域
    [_mapView setZoomLevel:17 animated:YES];
    
    //是否显示指南针 默认是显示
    _mapView.showsCompass= NO;
    //是否显示比例尺 默认是显示
    _mapView.showsScale= NO;
    //去除高德地图下方的 logo 图标
    [_mapView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            UIImageView * logoM = obj;
            logoM.layer.contents = (__bridge id)[UIImage imageNamed:@""].CGImage;
        }
    }];
    
    [self addAnomationToMapView:coor];
    [self setMapCenter:coor zoomLevel:17];
}


/* 逆编码 将坐标转换为具体地理信息 回调需实现onReGeocodeSearchDone: response:*/
-(void)regeoLocation:(CGFloat)lat longitude:(CGFloat)lon{
    AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
    regeo.location = [AMapGeoPoint locationWithLatitude:lat longitude:lon];
    regeo.requireExtension = YES;
    //发起逆地理编码
    [self.search AMapReGoecodeSearch:regeo];
}


//在地图上添加点
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor title:(NSString *)title subtitle:(NSString *)subtitle{
    MAPointAnnotation *pointAnnotation = [[MAPointAnnotation alloc] init];
    pointAnnotation.coordinate = coor;
    pointAnnotation.title = title;
    pointAnnotation.subtitle = subtitle;
    [_mapView addAnnotation:pointAnnotation];
}

//在地图上添加点
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor title:(NSString *)title{
    [self addAnomationToMapView:coor title:title subtitle:nil];
}



//在地图上添加点
-(void)addAnomationToMapView:(CLLocationCoordinate2D)coor{
    [self addAnomationToMapView:coor title:nil subtitle:nil];
}


//在地图上添加点
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon title:(NSString *)title subtitle:(NSString *)subtitle{
    [self addAnomationToMapView:CLLocationCoordinate2DMake(lat, lon) title:title subtitle:subtitle];
}


//在地图上添加点
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon{
    [self addAnomationToMapView:CLLocationCoordinate2DMake(lat, lon) title:nil subtitle:nil];
}

//在地图上添加点
-(void)addAnomationToMapView:(CGFloat)lat lon:(CGFloat)lon title:(NSString *)title{
    [self addAnomationToMapView:CLLocationCoordinate2DMake(lat, lon) title:title subtitle:nil];
}



#pragma mark --周边搜索方法
-(void)searchAroundWithKeyWords:(NSString *)keywords{
    if(_currentLocation==nil){
        NSLog(@"当前定位还未返回");
        return;
    }
    AMapPOIAroundSearchRequest  *request=[[AMapPOIAroundSearchRequest alloc] init];
    //设置搜索范围，以显示在地图上
    request.radius = 5000;
    NSLog(@"搜索 %lf", self.currentLocation.coordinate.latitude);
    request.location=[AMapGeoPoint locationWithLatitude:_currentLocation.coordinate.latitude longitude:_currentLocation.coordinate.longitude];
    request.keywords = keywords;
    /* 按照距离排序. */
    request.sortrule            = 0;
    request.requireExtension    = YES;
    self.searchType = @"1";
    [self.search AMapPOIAroundSearch:request];
    
    
    
}

#pragma mark 关键词搜索方法
-(void)searchByKeyWords:(NSString *)keywords {
    AMapPOIKeywordsSearchRequest *request = [[AMapPOIKeywordsSearchRequest alloc] init];
    request.keywords = keywords;
    request.city = @"上海";
    request.cityLimit           = YES;
    request.requireSubPOIs      = YES;
    self.searchType = @"2";
    [_search AMapPOIKeywordsSearch: request];
    
}

#pragma mark 周边搜索回调
-(void)onPOISearchDone:(AMapPOISearchBaseRequest *)request response:(AMapPOISearchResponse *)response{
    NSLog(@"返回结果");
    
    if (response.pois.count>0) {
        self.searchResultArr = [response.pois mutableCopy];
        //        NSLog(@"%@",self.dataArray);
        dispatch_async(dispatch_get_main_queue(), ^{
            //            [_mapView setZoomLevel:13.1 animated:YES];
            for (int i = 0; i < self.searchResultArr.count; i++) {
                AMapPOI *poi = self.searchResultArr[i];
                if([self.searchType isEqualToString:@"1"]){
                    [self addAnomationToMapView:poi.location.latitude lon:poi.location.longitude title:@"1"];
                }else{
                    NSLog(@"%@",[NSString stringWithFormat:@"%@\nPOI: %@,%@", poi.description, poi.name, poi.address]);
                }
            }
            //把中心点设成自己的坐标
            self.mapView.centerCoordinate = self.currentLocation.coordinate;
            
        });
    }else{
        NSLog(@"搜索结果个数为0");
    }
}


#pragma mark --绘制折线
-(void)drawLineWithArray:(NSArray *)array{
    //构造折线数据对象
    CLLocationCoordinate2D commonPolylineCoords[array.count];
    for (int i = 0; i<array.count; i++) {
        NSString *location = array[i];
        commonPolylineCoords[i].latitude = [location substringToIndex:9].floatValue;
        commonPolylineCoords[i].longitude = [location substringFromIndex:10].floatValue;
    }
    //构造折线对象
    MAPolyline *commonPolyline = [MAPolyline polylineWithCoordinates:commonPolylineCoords count:array.count];
    
    //在地图上添加折线对象
    [_mapView addOverlay: commonPolyline];
    //将地图的中心点设为固定的点
    _mapView.centerCoordinate = commonPolylineCoords[array.count/2];
    
}

//-(void)drawCarLine:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;
//-(void)drawCarLine:(CGFloat)startLat startLon:(CGFloat)startLon desLat:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;
//-(void)drawCarLine:(CLLocationCoordinate2D)startCoor desCoor:(CLLocationCoordinate2D)desCoor isWithStartAndEndImg:(BOOL)isWithStartAndEndImg;

//搜索Driver路线
-(void)searchDriverLine:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg{
    [self searchDriverLine:CLLocationCoordinate2DMake(self.currentLocation.coordinate.latitude, self.currentLocation.coordinate.longitude) desCoor:CLLocationCoordinate2DMake(desLat, desLon) isWithStartAndEndImg:isWithStartAndEndImg];
}

//搜索Driver路线
-(void)searchDriverLine:(CGFloat)startLat startLon:(CGFloat)startLon desLat:(CGFloat)desLat desLon:(CGFloat)desLon isWithStartAndEndImg:(BOOL)isWithStartAndEndImg{
    [self searchDriverLine:CLLocationCoordinate2DMake(startLat, startLon) desCoor:CLLocationCoordinate2DMake(desLat, desLon) isWithStartAndEndImg:isWithStartAndEndImg];
}


//搜索Driver路线
-(void)searchDriverLine:(CLLocationCoordinate2D)startCoor desCoor:(CLLocationCoordinate2D)desCoor isWithStartAndEndImg:(BOOL)isWithStartAndEndImg{
    
    //    NSLog(@"开始：%lf,%lf", startCoor.latitude, startCoor.longitude);
    //    NSLog(@"结束：%lf,%lf", destinationCoor.latitude, destinationCoor.longitude);
    self.startCoor =startCoor;
    self.destinationCoor =desCoor;
    
    AMapDrivingRouteSearchRequest *navi = [[AMapDrivingRouteSearchRequest alloc] init];
    
    navi.requireExtension = YES;
    navi.strategy = 5;
    /* 出发点. */
    navi.origin = [AMapGeoPoint locationWithLatitude:startCoor.latitude
                                           longitude:startCoor.longitude];
    /* 目的地. */
    navi.destination = [AMapGeoPoint locationWithLatitude:desCoor.latitude
                                                longitude:desCoor.longitude];
    [self.search AMapDrivingRouteSearch:navi];
    
    if(isWithStartAndEndImg){
        //在地图上添加起点和终点 可以根据title的值在 mapView: viewForAnnotation:中修改图标
        [self addAnomationToMapView:startCoor title:@"起点"];
        [self addAnomationToMapView:desCoor title:@"终点"];
    }
}

//设置地图中心点
-(void)setMapCenter:(CLLocationCoordinate2D)centerCoor zoomLevel:(CGFloat)zoomLevel{
    [self.mapView setCenterCoordinate:centerCoor animated:YES];
    if(zoomLevel>0){
        [self.mapView setZoomLevel:zoomLevel animated:YES];
    }
}

//设置地图中心点
-(void)setMapCenter:(CGFloat)centerLat centerLon:(CGFloat)centerLon{
    [self setMapCenter:CLLocationCoordinate2DMake(centerLat, centerLon) zoomLevel:-1];
}

//设置地图中心点和缩放层级
-(void)setMapCenter:(CGFloat)centerLat centerLon:(CGFloat)centerLon zoomLevel:(CGFloat)zoomLevel{
    [self setMapCenter:CLLocationCoordinate2DMake(centerLat, centerLon) zoomLevel:zoomLevel];
}

//设置地图的缩放层级
-(void)setZoomLevel:(CGFloat)zoomLevel{
    [self.mapView setZoomLevel:zoomLevel animated:YES];
}

//清除地图上的所有标记点
-(void)removeMapAllAnnotations{
    [self.mapView removeAnnotations:self.mapView.annotations];
}

//清除地图上的所有图层 比如路径线之类的
-(void)removeMapAllOverlays{
    [self.mapView removeOverlays:self.mapView.overlays];
}

@end

