//
//  URLAndParmFactory.h
//  carshare
//
//  Created by 森鸿 on 2018/6/8.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface URLAndParmFactory : NSObject

+ (NSDictionary*)makePropertiesParm:(NSString *)contractStatus;

+ (NSDictionary*)makeEnterprisesParm:(NSString *)contractStatus;

+ (NSString *) makeMyWalletURL:(NSString *)userCd;

+ (NSString *) makeMyCoucopURL:(NSString *)userCd;

+ (NSString *) makeDiscountURL:(NSString *)userCd;

+ (NSString *) makeCashhistoryURL:(NSString *)userCd;

+ (NSString *) makeSharedTaskURL:(NSString *)userCd;

+ (NSString *) makeSharedHistoryListURL:(NSString *)userCd;

+ (NSString *) makeRequestHistoryListURL:(NSString *)requestId;

+ (NSString *) makeTaskRequestDetailURL:(NSString *)requestId;

+ (NSString *) makeTaskMakingDetailURL:(NSString *)requestId;

+ (NSString *) makeTaskFinishDetailURL:(NSString *)requestId;


+ (NSString *) makePropertyURL:(NSString *)requestId;

+ (NSString *) makeEnterpriseURL:(NSString *)requestId;

+ (NSString *) makeSharetaskURL:(NSString *)requestId;

+ (NSString *) makeUserBlackListURL:(NSString *)userCd;

+ (NSString *) makeTaskRequestURL:(NSString *)userCd;

+ (NSString *) makeTaskParkingURL:(NSString *)userCd;

+ (NSString *) makeTaskHistoryURL:(NSString *)userCd;

+ (NSString *) makeTaskWaitPayURL:(NSString *)userCd;

+ (NSString *) makeUserparkingURL:(NSString *)userCd;

+ (NSString *) makePropertyparkingURL:(NSString *)userCd;

+ (NSString *) makeGetMsgURL:(NSString *)userCd requestId:(NSString *)requestId;

+ (NSDictionary *)makeDelayOrShortParm:(NSString *)userCd :(NSString *)requestId :(NSString *)minutes;

+ (NSDictionary *)makeForanswerParm:(NSString *)userCd;

+ (NSDictionary *)makeRequestForauthParm:(NSString *)userCd;

+ (NSDictionary *)makeTaskCancelParm:(NSString *)userCd :(NSString *)requestId;

//+ (NSDictionary *)makePropertiesParm:(NSString *)contractStatus;

//+ (NSDictionary *)makeDeleteBlackParm:(NSString *)userCd :(NSString *)blackUserCd;

+ (NSDictionary *)makeAgreeParkingParm:(NSString *)userCd :(NSString *)id;

+ (NSDictionary *)makeRefuseParkingParm:(NSString *)userCd :(NSString *)id;

+ (NSDictionary *)makePapuseParkingParm:(NSString *)userCd :(NSString *)id;

+ (NSDictionary *)makeRestartParkingParm:(NSString *)userCd :(NSString *)id;

+ (NSDictionary *)makeModifyParkingParm:(NSDictionary *)dic;

+ (NSDictionary *)makeDeleteParkingParm:(NSString *)id;

+ (NSDictionary *)makeRequestConfirmParm:(NSString *)userCd :(NSString *)requestId;

+ (NSDictionary *)makeEnforcerefuseParm:(NSString *)userCd :(NSString *)requestId;

+ (NSDictionary *)makeStartParkingParm:(NSString *)userCd :(NSString *)requestId :(NSString *)msg;

+ (NSString *)makeKeywordSearchURL:(NSString *)keyword;

+ (NSDictionary *)makeSearchAroundParm:(NSString *)userCd city:(NSString *)city destination:(NSString *)destination longitude:(double)longitude latitude:(double)latitude;


//+ (NSDictionary *)makeEnterprisesParm:(NSString *)contractStatus;
+ (NSDictionary *)makeAuditPropertiesParm:(NSString *)userCd propertyId:(NSString *)propertyId degree:(NSString *)degree contractStatus:(NSString *)contractStatus;

+ (NSDictionary *)makeAuditEnterprisesParm:(NSString *)userCd enterpriseId:(NSString *)enterpriseId contractStatus:(NSString *)contractStatus;

+ (NSDictionary *)makeSelectParkingParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime;

+ (NSDictionary *)makeAddParkForPlotParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime distance:(NSString *)distance licenseplate:(NSString *)licenseplate propertyId:(NSString *)propertyId;

+ (NSDictionary *)makeAddParkForAloneParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime distance:(NSString *)distance licenseplate:(NSString *)licenseplate parkingId:(NSString *)parkingId;

@end

