//
//  URLAndParmFactory.m
//  carshare
//
//  Created by 森鸿 on 2018/6/8.
//  Copyright © 2018年 senhong. All rights reserved.
//

#import "URLAndParmFactory.h"
#import "Constants.h"

@implementation URLAndParmFactory

+ (NSDictionary*)makePropertiesParm:(NSString *)contractStatus {
    return @{@"contractStatus": contractStatus};
}

+ (NSDictionary*)makeEnterprisesParm:(NSString *)contractStatus {
    return @{@"contractStatus": contractStatus};
    
}

+ (NSString *) makeMyWalletURL:(NSString *)userCd{
    return  [WALLET_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeMyCoucopURL:(NSString *)userCd{
    return  [COUPON_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeDiscountURL:(NSString *)userCd{
    return  [DISCOUNT_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeCashhistoryURL:(NSString *)userCd{
    return  [CASHHISTORY_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeSharedTaskURL:(NSString *)userCd{
    return  [sharetasks_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeSharedHistoryListURL:(NSString *)userCd{
    return  [sharedhistory_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeRequestHistoryListURL:(NSString *)requestId{
    return  [requesthistory_URL stringByAppendingFormat:@"/%@",requestId];
}

+ (NSString *) makePropertyURL:(NSString *)requestId{
    return  [property_URL stringByAppendingFormat:@"/%@",requestId];
}

+ (NSString *) makeEnterpriseURL:(NSString *)requestId{
    return  [enterprise_URL stringByAppendingFormat:@"/%@",requestId];
}

+ (NSString *) makeTaskRequestDetailURL:(NSString *)requestId{
    return  [taskrequest_URL stringByAppendingFormat:@"/%@",requestId];
}


+ (NSString *) makeTaskMakingDetailURL:(NSString *)requestId{
    return  [taskparkingtask_URL stringByAppendingFormat:@"/%@",requestId];
}


+ (NSString *) makeTaskFinishDetailURL:(NSString *)requestId{
    return  [NSString stringWithFormat:@"%@/%@", requesthistory_URL, requestId];
}

+ (NSString *) makeSharetaskURL:(NSString *)requestId{
    return  [sharetask_URL stringByAppendingFormat:@"/%@",requestId];
}

+ (NSString *) makeUserBlackListURL:(NSString *)userCd{
    return  [BlackList_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeTaskRequestURL:(NSString *)userCd{
    return  [taskrequests_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeTaskParkingURL:(NSString *)userCd{
    return  [taskparkingtasks_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeTaskHistoryURL:(NSString *)userCd{
    return  [taskhistory_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makeGetMsgURL:(NSString *)userCd requestId:(NSString *)requestId{
    return  [MESSGES stringByAppendingFormat:@"/%@/%@",userCd, requestId];
}

+ (NSString *) makeTaskWaitPayURL:(NSString *)userCd{
    return  [PAYMENT stringByAppendingFormat:@"%@",userCd];
}

+ (NSString *) makeUserparkingURL:(NSString *)userCd{
    return  [userparking_URL stringByAppendingFormat:@"/%@",userCd];
}

+ (NSString *) makePropertyparkingURL:(NSString *)userCd{
    return  [propertyparking_URL stringByAppendingFormat:@"/%@",userCd];
}



+ (NSDictionary *)makeForanswerParm:(NSString *)userCd{
    return  @{@"userCd":userCd};
}

+ (NSDictionary *)makeRequestForauthParm:(NSString *)userCd{
    return  @{@"userCd":userCd};
}


//+ (NSDictionary *)makePropertiesParm:(NSString *)contractStatus{
//    return  @{@"contractStatus":contractStatus};
//}


//+ (NSDictionary *)makeDeleteBlackParm:(NSString *)userCd :(NSString *)blackUserCd{
//    return  @{
//              @"userCd":userCd,
//              @"blackUserCd":blackUserCd,
//              };
//}

+ (NSDictionary *)makeDelayOrShortParm:(NSString *)userCd :(NSString *)requestId :(NSString *)minutes{
    return  @{
              @"userCd":userCd,
              @"requestId":[NSString stringWithFormat:@"%@", requestId],
              @"minutes":minutes
              };
    
}


+ (NSDictionary *)makeEnforcerefuseParm:(NSString *)userCd :(NSString *)requestId{
    return  @{
              @"userCd":userCd,
              @"requestId":requestId
              };
    
}

+ (NSDictionary *)makeRequestConfirmParm:(NSString *)userCd :(NSString *)requestId{
    return  @{
              @"userCd":userCd,
              @"requestId":[NSString stringWithFormat:@"%@", requestId]
              };
    
}


+ (NSDictionary *)makeTaskCancelParm:(NSString *)userCd :(NSString *)requestId{
    return  @{
              @"userCd":userCd,
              @"requestId":[NSString stringWithFormat:@"%@", requestId]
              };
}

+ (NSDictionary *)makeStartParkingParm:(NSString *)userCd :(NSString *)requestId :(NSString *)msg{
    return  @{
              @"userCd":userCd,
              @"requestId":[NSString stringWithFormat:@"%@", requestId],
              @"qrcode":msg
              };
}

+ (NSDictionary *)makeAgreeParkingParm:(NSString *)userCd :(NSString *)id{
    return  @{
              @"userCd":userCd,
              @"id":id
              };
}

+ (NSDictionary *)makeRefuseParkingParm:(NSString *)userCd :(NSString *)id{
    return  @{
              @"userCd":userCd,
              @"id":id
              };
}



+ (NSDictionary *)makePapuseParkingParm:(NSString *)userCd :(NSString *)id{
    return  @{
              @"userCd":userCd,
              @"id":id
              };
}

+ (NSDictionary *)makeRestartParkingParm:(NSString *)userCd :(NSString *)id{
    return  @{
              @"userCd":userCd,
              @"id":id
              };
}



+ (NSDictionary *)makeModifyParkingParm:(NSDictionary *)dic{
    return  @{
              @"id":[[dic objectForKey:@"Id"] stringValue],
              @"userCd":[dic objectForKey:@"userCd"],
              @"propertyCd":[dic objectForKey:@"propertyUserCd"],
              @"unitName":[dic objectForKey:@"unitName"],
              @"shareMethod":[dic objectForKey:@"shareMethod"],
              @"tuesdayShare":[dic objectForKey:@"tuesdayShare"],
              @"wednesdayShare":[dic objectForKey:@"wednesdayShare"],
              @"mondayShare":[dic objectForKey:@"mondayShare"],
              @"thursdayShare":[dic objectForKey:@"thursdayShare"],
              @"fridayShare":[dic objectForKey:@"fridayShare"],
              @"saturdayShare":[dic objectForKey:@"saturdayShare"],
              @"sundayShare":[dic objectForKey:@"sundayShare"],
              @"holidayShare":[dic objectForKey:@"holidayShare"],
              @"startTime":[dic objectForKey:@"startTime"],
              @"endTime":[dic objectForKey:@"endTime"],
              @"authorize":@"0"
              };
    
}


+ (NSDictionary *)makeDeleteParkingParm:(NSString *)id{
    return  @{
              @"parkingId":id
              };
}

+ (NSString *)makeKeywordSearchURL:(NSString *)keyword{
    return  [KeySearck stringByReplacingOccurrencesOfString:@"searchkey" withString:[NSString stringWithFormat: @"上海市%@", keyword]];
}

+ (NSDictionary *)makeSearchAroundParm:(NSString *)userCd city:(NSString *)city destination:(NSString *)destination longitude:(double)longitude latitude:(double)latitude{
    return  @{
              @"userCd":userCd,
              @"city":city,
              @"destination":destination,
              @"location":[NSString stringWithFormat: @"%lf,%lf", longitude, latitude]
              };
}




+ (NSDictionary *)makeAuditPropertiesParm:(NSString *)userCd propertyId:(NSString *)propertyId degree:(NSString *)degree contractStatus:(NSString *)contractStatus{
    return  @{
              @"userCd":userCd,
              @"propertyId":propertyId,
              @"degree":degree,
              @"contractStatus":contractStatus
              };
}

+ (NSDictionary *)makeAuditEnterprisesParm:(NSString *)userCd enterpriseId:(NSString *)enterpriseId contractStatus:(NSString *)contractStatus{
    return  @{
              @"userCd":userCd,
              @"enterpriseId":enterpriseId,
              @"contractStatus":contractStatus,
              };
}


+ (NSDictionary *)makeSelectParkingParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime{
    return  @{
              @"userCd":userCd,
              @"city":city,
              @"destination":address,
              @"location":location,
              @"startdatetime":starttime,
              @"enddatetime":overtime
              };
}


+ (NSDictionary *)makeAddParkForPlotParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime distance:(NSString *)distance licenseplate:(NSString *)licenseplate propertyId:(NSString *)propertyId{
    return  @{
              @"userCd":userCd,
              @"city":city,
              @"destination":[NSString stringWithFormat:@"%@", address],
              @"location":location,
              @"startdatetime":starttime,
              @"enddatetime":overtime,
              @"distance":[NSString stringWithFormat:@"%@", distance],
              @"licenseplate":licenseplate,
              @"propertyId":[NSString stringWithFormat:@"%@", propertyId],
              };
}



+ (NSDictionary *)makeAddParkForAloneParm:(NSString *)userCd city:(NSString *)city address:(NSString *)address location:(NSString *)location starttime:(NSString *)starttime overtime:(NSString *)overtime distance:(NSString *)distance licenseplate:(NSString *)licenseplate parkingId:(NSString *)parkingId{
    return  @{
              @"userCd":userCd,
              @"city":city,
              @"destination":[NSString stringWithFormat:@"%@", address],
              @"location":location,
              @"startdatetime":starttime,
              @"enddatetime":overtime,
              @"distance":[NSString stringWithFormat:@"%@", distance],
              @"licenseplate":licenseplate,
              @"parkingId":[NSString stringWithFormat:@"%@", parkingId],
              };
}




@end

