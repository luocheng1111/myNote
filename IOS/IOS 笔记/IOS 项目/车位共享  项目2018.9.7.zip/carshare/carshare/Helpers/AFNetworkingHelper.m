//
//  AFNetworkingHelper.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "AFNetworkingHelper.h"
#import "Constants.h"
#import "DialogFactory.h"
#import "LoginController.h"

static AFNetworkingHelper *_instance = nil;

@interface AFNetworkingHelper ()

@property (nonatomic,strong) AFHTTPSessionManager *manager;

@end

@implementation AFNetworkingHelper

+ (instancetype)shaerdInstance{
    static dispatch_once_t token;
    
    dispatch_once(&token, ^{
        _instance = [[super allocWithZone:NULL] init];
        [_instance initialization];
    });
    return  _instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone{
    return [AFNetworkingHelper shaerdInstance];
}

+ (id)copyWithZone:(struct _NSZone *)zone{
    return [AFNetworkingHelper shaerdInstance];
}

- (void)initialization{
    self.manager = [AFHTTPSessionManager manager];
}

- (void)httpRequest:(UIViewController *)controller
                url:(NSString *)url
            success:(void (^)(id responseObject))success
           onFinish:(void (^)(BOOL isError, NSString *errorMsg))finish{
    [self httpRequest:controller url:url parameters:nil success:success onFinish:finish cache:NO];
}


- (void)httpRequest:(UIViewController *)controller
                url:(NSString *)url
         parameters:(NSDictionary *)parm
            success:(void (^)(id responseObject))success
           onFinish:(void (^)(BOOL isError, NSString *errorMsg))finish{
    [self httpRequest:controller url:url parameters:parm success:success onFinish:finish cache:NO];
}



- (void)httpRequest:(UIViewController *)controller
                url:(NSString *)url
         parameters:(NSDictionary *)parm
            success:(void (^)(id responseObject))success
           onFinish:(void (^)(BOOL isError, NSString *errorMsg))finish
              cache:(BOOL)useCache{
    if(useCache == YES){
        _manager.requestSerializer.cachePolicy = NSURLRequestReturnCacheDataElseLoad;
    }else{
        _manager.requestSerializer.cachePolicy = NSURLRequestUseProtocolCachePolicy;
    }
    
    //申明返回的结果是json类型
    _manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //申明请求的数据是json类型
    _manager.requestSerializer=[AFJSONRequestSerializer serializer];
    //如果报接受类型不一致请替换一致text/html或别的
    _manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    if(isHttpLogPrint){
        NSLog(@"url:%@", url);
        NSLog(@"parm:%@", parm);
    }
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *accessToken =  [userDefaults objectForKey:@"accessToken"];
    if(accessToken !=nil){
        NSLog(@"Access-Token:%@", accessToken);
        [self.manager.requestSerializer setValue:accessToken forHTTPHeaderField:@"Access-Token"];
        [self.manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"content-type"];
    }
    
    //    NSString *pp = nil;
    //    if(parm!=nil){
    //        pp = [self convertToJsonData:parm];
    //    }
    //
    
    
    if(parm==nil){ //Get
        if(isHttpLogPrint){
            NSLog(@"Get 请求");
        }
        [self.manager GET:url parameters:parm progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSHTTPURLResponse * responses = (NSHTTPURLResponse *)task.response;
            if(isHttpLogPrint){ NSLog(@"结果:%ld %@", (long)responses.statusCode,responseObject); }
            if([responseObject isKindOfClass:[NSDictionary class]]){
                NSString *result = [responseObject objectForKey:@"result"];
                if(result!=nil && [result isEqualToString:@"false"]){
                    finish(true, [responseObject objectForKey:@"message"]);
                }else{
                    success(responseObject);
                    finish(false, nil);
                }
            }else{
                success(responseObject);
                finish(false, nil);
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSHTTPURLResponse * responses = (NSHTTPURLResponse *)task.response;
            int statusCode = [error.userInfo[@"Status Code"] intValue];
            if(isHttpLogPrint){ NSLog(@"出错 结果:%d %@", statusCode, error); }
            if (responses.statusCode == 401) {
                //自己想要进行的操作
                [DialogFactory showTwoBtnDialog:controller withTitle:@"提示" withMsg:@"401错误" isCancelable:YES btn1Text:@"取消" btn2Text:@"登录" handle1:^(UIAlertAction *action) {
                    
                } handle2:^(UIAlertAction *action) {
                    [LoginController Go:controller];
                }];
                finish(true, @"401");
            }else{
                finish(true, @"erroe");
            }
        }];
        
    }else{ //Post
        if(isHttpLogPrint){
            NSLog(@"Post 请求");
        }
        [self.manager POST:url parameters:parm progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSHTTPURLResponse * responses = (NSHTTPURLResponse *)task.response;
            if(isHttpLogPrint){ NSLog(@"成功 结果:%ld %@", (long)responses.statusCode,responseObject); }
            if([responseObject isKindOfClass:[NSDictionary class]]){
                NSString *result = [responseObject objectForKey:@"result"];
                if(result!=nil && [result isEqualToString:@"false"]){
                    finish(true, [responseObject objectForKey:@"message"]);
                }else{
                    success(responseObject);
                    finish(false, nil);
                }
            }else{
                success(responseObject);
                finish(false, nil);
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSHTTPURLResponse * responses = (NSHTTPURLResponse *)task.response;
            int statusCode = [error.userInfo[@"Status Code"] intValue];
            if(isHttpLogPrint){ NSLog(@"出错 结果:%d %@", statusCode, error); }
            if (responses.statusCode == 401) {
                //自己想要进行的操作
                [DialogFactory showTwoBtnDialog:controller withTitle:@"提示" withMsg:@"401错误" isCancelable:YES btn1Text:@"取消" btn2Text:@"登录" handle1:^(UIAlertAction *action) {
                    
                } handle2:^(UIAlertAction *action) {
                    [LoginController Go:controller];
                }];
                finish(true, @"401");
            }else{
                finish(true, @"erroe");
            }
        }];
        
    }
}






@end
