//
//  DialogHelper.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "DialogFactory.h"
#import <MBProgressHUD.h>
#import "SVProgressHUD.h"

@interface DialogFactory ()
@property (atomic, assign) BOOL canceled;


@end


@implementation DialogFactory

static float progress = 0.0f;

+ (void)showOneBtnDialog:(UIViewController *)controller withTitle:(NSString *)title withMsg:(NSString *)msg{
    [self showOneBtnDialog:controller withTitle:title withMsg:msg btnText:@"取消" action:nil];
}

+ (void)showOneBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg
                 btnText:(NSString *)btnText
                  action:(void (^)(UIAlertAction *action))action{
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    //     [alertVC addAction:[UIAlertAction actionWithTitle:@"YES" style:UIAlertActionStyleDefault handler:nil]];
    [alertVC addAction:[UIAlertAction actionWithTitle:btnText style:UIAlertActionStyleCancel handler:action]];
    //    _alertVC = alertVC;
    [controller presentViewController:alertVC animated:YES completion:nil];
    
    // 增加点击事件 如何声明静态变量
    //     UIWindow *alertWindow = (UIWindow *)[UIApplication sharedApplication].windows.lastObject;
    //     UITapGestureRecognizer tap = [[UITapGestureRecognizer alloc] initWithTarget:controller action:@selector(hideAlert)];
    //     [alertWindow addGestureRecognizer:tap];
}



- (void)hideAlert{
    //    UIWindow *alertWindow = (UIWindow *)[UIApplication sharedApplication].windows.lastObject;
    //    [alertWindow removeGestureRecognizer:tap];
    //    [_alertVC dismissViewControllerAnimated:YES completion:nil];
}

+ (void)showTwoBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg{
    [self showTwoBtnDialog:controller withTitle:title withMsg:msg isCancelable:false btn1Text:@"取消" btn2Text:@"确认" handle1:nil handle2:nil];
}

+ (void)showTwoBtnDialog:(UIViewController *)controller
               withTitle:(NSString *)title
                 withMsg:(NSString *)msg
            isCancelable:(BOOL)isCancelable
                btn1Text:(NSString *)btn1Text
                btn2Text:(NSString *)btn2Text
                 handle1:(void (^)(UIAlertAction *action))handle1
                 handle2:(void (^)(UIAlertAction *action))handle2{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:btn1Text style:UIAlertActionStyleCancel handler:handle1]];
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:btn2Text style:UIAlertActionStyleDefault handler:handle2]];
    
    // 由于它是一个控制器 直接modal出来就好了
    [controller presentViewController:alertController animated:YES completion:nil];
}



+ (void)showLoadingView{
    [self showLoadingView:@"" isWhiteStyle:true withLoadingCircleStyle:0 isMask:true isCancelable:true];
}

+ (void)showLoadingView:(NSString *)text{
    [self showLoadingView:text isWhiteStyle:false withLoadingCircleStyle:0 isMask:true isCancelable:true];
}

+ (void)showLoadingView:(NSString *)text isWhiteStyle:(BOOL)isWhiteStyle{
    [self showLoadingView:text isWhiteStyle:isWhiteStyle withLoadingCircleStyle:0 isMask:true isCancelable:true];
}

+ (void)showLoadingView:(NSString *)text
           isWhiteStyle:(BOOL)isWhiteStyle
 withLoadingCircleStyle:(NSInteger)circleStyle
                 isMask:(BOOL)isMask
           isCancelable:(BOOL)isCancelable{
    
    [self setLoadingCircleStyle:circleStyle];
    [self setViewStyle:isWhiteStyle];
    [self setCancelable:isCancelable];
    [self setMask:isMask];
    if(text!=nil && text.length>0){
        [SVProgressHUD showWithStatus:text];
    }else{
        [SVProgressHUD show];
    }
    
}




+ (void)dismissDialog{
    [SVProgressHUD dismiss];
    
}

+ (void)setViewStyle:(BOOL)isWhiteStyle{
    if(!isWhiteStyle){
        [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
    } else {
        [SVProgressHUD setDefaultStyle:SVProgressHUDStyleLight];
    }
}

+ (void)setLoadingCircleStyle:(NSInteger)style{
    if(style == 0){
        [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeNative];
    } else {
        [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeFlat];
    }
}

+ (void)setMask:(BOOL)isMask{
    if(isMask){
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    } else {
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    }
}

+ (void)setCancelable:(BOOL)isCancelable{
    if(isCancelable){
        __block id observer = [[NSNotificationCenter defaultCenter] addObserverForName:SVProgressHUDDidReceiveTouchEventNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            NSLog(@"11111");
            [DialogFactory dismissDialog];
            [[NSNotificationCenter defaultCenter] removeObserver:observer];
            observer = nil;
        }];
    }
}




+ (void)dismissLoadingView:(UIView *)view{
    [MBProgressHUD hideHUDForView:[self convertView:view] animated:YES];
}


+ (void)showProgressView{
    [self showProgressView:false isCancelable:true];
}

+ (void)showProgressView:(BOOL)isWhiteStyle isCancelable:(BOOL)isCancelable{
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];
    [SVProgressHUD setDefaultAnimationType:SVProgressHUDAnimationTypeNative];
    [self setViewStyle:isWhiteStyle];
    [self setCancelable:isCancelable];
    [SVProgressHUD showProgress:0 status:@"Loading..."];
    
}



+ (void)showTipsInCenter:(UIView *)view withText:(NSString *)text{
    [self showTips:view withText:text withStyle:1 withPosition:0];
}

+ (void)showTipsInBottom:(UIView *)view withText:(NSString *)text{
    [self showTips:view withText:text withStyle:1 withPosition:1];
}


+ (void)showTips:(UIView *)view withText:(NSString *)text withStyle:(NSInteger)tipStyle withPosition:(NSInteger)position{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self convertView:view] animated:YES];
    
    hud.mode = MBProgressHUDModeText;
    hud.label.text = text;
    //tipStyle 0：白底黑字（默认） 1：黑底白色
    if(tipStyle!=0){
        hud.color = [UIColor blackColor];
        hud.label.textColor = [UIColor whiteColor];
    }
    
    //withPosition 0：居中显示（默认） 1：底部显示
    if(position!=0){
        //调整显示位置
        hud.offset = CGPointMake(0.f, MBProgressMaxOffset);
    }
    //调整边框大小
    hud.margin = 10.f;
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (void)showInfoTip:(NSString *)text{
    [SVProgressHUD showInfoWithStatus:text];
}
+ (void)showSuccessTip:(NSString *)text{
    [SVProgressHUD showSuccessWithStatus:text];
}
+ (void)showErrorTip:(NSString *)text{
    [SVProgressHUD showErrorWithStatus:text];
}


+ (void)showOKDialog:(UIView *)view withText:(NSString *)text{
    [self showTipsWithImage:view withImage:@"ok" withText:text];
}


+ (void)showNODialog:(UIView *)view withText:(NSString *)text{
    [self showTipsWithImage:view withImage:@"no" withText:text];
}

+ (void)showTipsWithImage:(UIView *)view withImage:(NSString *)imageName withText:(NSString *)text{
    [self showTipsWithImage:view isWhiteStyle:false withImage:imageName withText:text];
}

+ (void)showTipsWithImage:(UIView *)view isWhiteStyle:(BOOL)isWhiteStyle withImage:(NSString *)imageName withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self convertView:view] animated:YES];
    //    hud.color = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeCustomView;
    
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    
    if(!isWhiteStyle){
        hud.color = [UIColor blackColor];
        hud.detailsLabel.textColor = [UIColor whiteColor];
    }
    
    // Looks a bit nicer if we make it square.
    hud.square = YES;
    hud.detailsLabel.font = [UIFont boldSystemFontOfSize:16];
    hud.detailsLabel.text = text;
    
    //调整显示位置
    hud.offset = CGPointMake(0.f, -20.f);
    
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (UIView *) convertView:(UIView *)view{
    UIWindow *window = [[[UIApplication sharedApplication] windows] lastObject];
    UIView *container = (view != nil? view:window);
    return container;
}

@end
