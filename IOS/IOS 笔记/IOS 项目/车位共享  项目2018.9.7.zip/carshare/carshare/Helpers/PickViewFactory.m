//
//  DialogHelper.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//  封装自：https://github.com/91renb/BRPickerView
//

#import "PickViewFactory.h"
#import <BRPickerView.h>


@interface PickViewFactory ()

@end


@implementation PickViewFactory



+ (void)showTimePickView:(NSString *)title
             resultBlock:(void (^)(NSString *selectValue))result{
    [self showTimePickView:title defaultTime:nil style:1 resultBlock:result];
}


// @param defaultTime              格式 13:00
// @param isAutoSelect             是否自动选择，即选择完(滚动完)执行结果回调，传选择的结果值
// @param themeColor               自定义主题颜色
// @param resultBlock              选择后的回调
+ (void)showTimePickView:(NSString *)title
             defaultTime:(NSString *)defaultTime
                   style:(NSInteger)style
             resultBlock:(void (^)(NSString *selectValue))result{

    
    //样式
    BRDatePickerMode mode;
    if(style==1){
        mode = BRDatePickerModeTime;
    }else if(style==2){
        mode = BRDatePickerModeHM;
    }else if(style==3){
        mode = BRDatePickerModeCountDownTimer;
    }else{
        mode = BRDatePickerModeTime;
    }
    
    //选择的范围
    NSDate *minDate = [NSDate br_setHour:00 minute:00];
    NSDate *maxDate = [NSDate br_setHour:23 minute:59];

    [BRDatePickerView showDatePickerWithTitle:title dateType:mode defaultSelValue:defaultTime minDate:minDate maxDate:maxDate isAutoSelect:YES themeColor:nil resultBlock:result cancelBlock:nil];
}

//defaultTime格式 2008-06-13
+ (void)showDatePickView:(NSString *)title
                  isShowYear:(BOOL)isShowYear
                 isShowMonth:(BOOL)isShowMonth
                   isShowDay:(BOOL)isShowDay
             defaultDateTime:(NSString *)defaultDateTime
                 resultBlock:(void (^)(NSString *selectValue))result{
    [self showDateTimePickView:title isShowYear:isShowYear isShowMonth:isShowMonth isShowDay:isShowDay isShowHour:false isShowMinute:false defaultDateTime:defaultDateTime resultBlock:result];
}


+ (void)showDateTimePickView:(NSString *)title
                  isShowYear:(BOOL)isShowYear
                 isShowMonth:(BOOL)isShowMonth
                   isShowDay:(BOOL)isShowDay
                  isShowHour:(BOOL)isShowHour
                isShowMinute:(BOOL)isShowMinute
             defaultDateTime:(NSString *)defaultDateTime
                 resultBlock:(void (^)(NSString *selectValue))result{
    //选择的范围
    NSDate *minDate = [NSDate br_setYear:1990 month:3 day:12];
    NSDate *maxDate = [NSDate br_setYear:2028 month:3 day:12];
    [self showDateTimePickView:title isShowYear:isShowYear isShowMonth:isShowMonth isShowDay:isShowDay isShowHour:isShowHour isShowMinute:isShowMinute defaultDateTime:defaultDateTime selectMinTime:minDate selectMaxTime:maxDate resultBlock:result];
}

+ (void)showDateTimePickView:(NSString *)title
                  isShowYear:(BOOL)isShowYear
                  isShowMonth:(BOOL)isShowMonth
                  isShowDay:(BOOL)isShowDay
                  isShowHour:(BOOL)isShowHour
                  isShowMinute:(BOOL)isShowMinute
             defaultDateTime:(NSString *)defaultDateTime
               selectMinTime:(NSDate *)selectMinTime
               selectMaxTime:(NSDate *)selectMaxTime
             resultBlock:(void (^)(NSString *selectValue))result{

    //样式
    BRDatePickerMode mode;
    
    if(isShowYear==true && isShowMonth==false && isShowDay==false && isShowHour==false && isShowMinute==false){
         // yyyy
        mode = BRDatePickerModeY;
    }
    
    if(isShowYear==true && isShowMonth==true && isShowDay==false && isShowHour==false && isShowMinute==false){
        // yyyy-MM
        mode = BRDatePickerModeYM;
    }
    
    if(isShowYear==true && isShowMonth==true && isShowDay==true && isShowHour==false && isShowMinute==false){
        // yyyy-MM-dd
        mode = BRDatePickerModeYMD;
        //mode = BRDatePickerModeDate;
    }
    
    if(isShowYear==false && isShowMonth==true && isShowDay==true && isShowHour==false && isShowMinute==false){
        // MM-dd
//        mode = BRDatePickerModeMD;
    }
    
    if(isShowYear==true && isShowMonth==true && isShowDay==true && isShowHour==true && isShowMinute==true){
        // yyyy-MM-dd HH:mm
        mode = BRDatePickerModeYMDHM;
        
    }
    
    if(isShowYear==false && isShowMonth==true && isShowDay==true && isShowHour==true && isShowMinute==true){
        // MM-dd HH:mm
        mode = BRDatePickerModeDateAndTime;
    }
    
    //选择的范围
//    NSDate *minDate = [NSDate br_setYear:1990 month:3 day:12];
//    NSDate *maxDate = [NSDate br_setYear:2028 month:3 day:12];
    [BRDatePickerView showDatePickerWithTitle:title dateType:mode defaultSelValue:defaultDateTime minDate:selectMinTime maxDate:selectMaxTime isAutoSelect:YES themeColor:nil resultBlock:result cancelBlock:nil];
}

//defaultTime格式 @"浙江省 杭州市 西湖区"
+ (void)showCityPickView:(NSString *)defaultValue
             resultBlock:(void (^)(BRProvinceModel *province, BRCityModel *city, BRAreaModel *area))result{
    
    [self showCityPickView:defaultValue showType:nil resultBlock:result];
}


//defaultTime格式 @"浙江省 杭州市 西湖区"
//showType: 0或nil 省市镇 1 省和市 2 省
+ (void)showCityPickView:(NSString *)defaultValue showType:(NSString *)showType
             resultBlock:(void (^)(BRProvinceModel *province, BRCityModel *city, BRAreaModel *area))result{
    
    NSArray *defaultSelArr = [defaultValue componentsSeparatedByString:@" "];
    
    BRAddressPickerMode showMode = BRAddressPickerModeArea;
    if(showType !=nil && [showType isEqualToString:@"1"]){
        showMode = BRAddressPickerModeCity;
    }else if(showType !=nil && [showType isEqualToString:@"2"]){
        showMode = BRAddressPickerModeProvince;
    }else{
        showMode = BRAddressPickerModeArea;
    }
    
    // dataSource 为空时，就默认使用框架内部提供的数据源（即 BRCity.plist）
    [BRAddressPickerView showAddressPickerWithShowType:showMode dataSource:nil defaultSelected:defaultSelArr isAutoSelect:YES themeColor:nil resultBlock:result cancelBlock:nil];
}


+ (void)showOneItemPickView:(NSString *)title defaultValue:(NSString *)defaultValue dataSource:(id)dataSource
             resultBlock:(void (^)(NSString *selectValue))result{
    [BRStringPickerView showStringPickerWithTitle:title dataSource:dataSource defaultSelValue:defaultValue resultBlock:result];
}

+ (void)showTwoItemPickView:(NSString *)title defaultSelArr:(id)defaultSelArr dataSource:(id)dataSource
                resultBlock:(void (^)(id selectValue))result{
    
    [BRStringPickerView showStringPickerWithTitle:title dataSource:dataSource defaultSelValue:defaultSelArr isAutoSelect:YES themeColor:nil resultBlock:result cancelBlock:nil];
}

@end
