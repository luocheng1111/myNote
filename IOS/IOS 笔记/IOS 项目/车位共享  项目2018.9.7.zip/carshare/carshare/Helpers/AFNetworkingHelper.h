//
//  AFNetworkingHelper.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>

@interface AFNetworkingHelper : NSObject

+ (instancetype)shaerdInstance;



- (void)httpRequest:(UIViewController *)controller
                url:(NSString *)url
            success:(void (^)(id responseObject))success
           onFinish:(void (^)(BOOL isError, NSString *errorMsg))finish;


- (void)httpRequest:(UIViewController *)controller
                url:(NSString *)url
         parameters:(NSDictionary *)parm
            success:(void (^)(id responseObject))success
           onFinish:(void (^)(BOOL isError, NSString *errorMsg))finish;

- (void)httpRequest:(NSString *)url
         parameters:(NSDictionary *)parm
            success:(void (^)(NSURLSessionDataTask *, id))success
           onFinish:(void (^)(NSURLSessionDataTask *, NSError *))finish
              cache:(BOOL)useCache;


@end
