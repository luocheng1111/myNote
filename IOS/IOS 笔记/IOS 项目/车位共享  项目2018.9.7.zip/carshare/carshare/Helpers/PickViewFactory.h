//
//  DialogHelper.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRPickerViewMacro.h"
#import "BRAddressModel.h"
@interface PickViewFactory : NSObject

// @param defaultTime              格式 13:00
// @param isAutoSelect             是否自动选择，即选择完(滚动完)执行结果回调，传选择的结果值
// @param themeColor               自定义主题颜色
// @param resultBlock              选择后的回调
+ (void)showTimePickView:(NSString *)title
             resultBlock:(void (^)(NSString *selectValue))result;

//defaultTime格式 13:00
+ (void)showTimePickView:(NSString *)title
             defaultTime:(NSString *)defaultTime
                   style:(NSInteger)style
             resultBlock:(void (^)(NSString *selectValue))result;


// @param defaultTime              格式 2008-06-13
+ (void)showDatePickView:(NSString *)title
              isShowYear:(BOOL)isShowYear
             isShowMonth:(BOOL)isShowMonth
               isShowDay:(BOOL)isShowDay
         defaultDateTime:(NSString *)defaultDateTime
             resultBlock:(void (^)(NSString *selectValue))result;

+ (void)showDateTimePickView:(NSString *)title
                  isShowYear:(BOOL)isShowYear
                 isShowMonth:(BOOL)isShowMonth
                   isShowDay:(BOOL)isShowDay
                  isShowHour:(BOOL)isShowHour
                isShowMinute:(BOOL)isShowMinute
             defaultDateTime:(NSString *)defaultDateTime
                 resultBlock:(void (^)(NSString *selectValue))result;

+ (void)showDateTimePickView:(NSString *)title
                  isShowYear:(BOOL)isShowYear
                 isShowMonth:(BOOL)isShowMonth
                   isShowDay:(BOOL)isShowDay
                  isShowHour:(BOOL)isShowHour
                isShowMinute:(BOOL)isShowMinute
             defaultDateTime:(NSString *)defaultDateTime
               selectMinTime:(NSDate *)selectMinTime
               selectMaxTime:(NSDate *)selectMaxTime
                 resultBlock:(void (^)(NSString *selectValue))result;

//defaultTime格式 @"浙江省 杭州市 西湖区"
+ (void)showCityPickView:(NSString *)defaultValue 
             resultBlock:(void (^)(BRProvinceModel *province, BRCityModel *city, BRAreaModel *area))result;

//defaultTime格式 @"浙江省 杭州市 西湖区"
//showType: 0或nil 省市镇 1 省和市 2 省
+ (void)showCityPickView:(NSString *)defaultValue showType:(NSString *)showType
             resultBlock:(void (^)(BRProvinceModel *province, BRCityModel *city, BRAreaModel *area))result;


+ (void)showOneItemPickView:(NSString *)title defaultValue:(NSString *)defaultValue dataSource:(id)dataSource
                resultBlock:(void (^)(NSString *selectValue))result;


+ (void)showTwoItemPickView:(NSString *)title defaultSelArr:(id)defaultSelArr dataSource:(id)dataSource
                resultBlock:(void (^)(id selectValue))result;
    
//+ (void)showTwoBtnDialog:(UIViewController *)controller
//               withTitle:(NSString *)title
//                 withMsg:(NSString *)msg;
//
//+ (void)showTwoBtnDialog:(UIViewController *)controller
//               withTitle:(NSString *)title
//                 withMsg:(NSString *)msg
//            isCancelable:(BOOL)isCancelable
//                btn1Text:(NSString *)btn1Text
//                btn2Text:(NSString *)btn2Text
//                handle1:(void (^)(UIAlertAction *action))handle1
//                handle2:(void (^)(UIAlertAction *action))handle2;
//
//        
//+ (void)showLoadingView;
//+ (void)showLoadingView:(NSString *)text;
//+ (void)showLoadingView:(NSString *)text isWhiteStyle:(BOOL)isWhiteStyle;
//+ (void)showLoadingView:(NSString *)text
//               isWhiteStyle:(BOOL)isWhiteStyle
//               withLoadingCircleStyle:(NSInteger)circleStyle
//               isMask:(BOOL)isMask
//               isCancelable:(BOOL)isCancelable;
//+ (void)dismissDialog;
//
//
//+ (void)showProgressView;
//+ (void)showProgressView:(BOOL)isWhiteStyle isCancelable:(BOOL)isCancelable;
//
//+ (void)showTipsInCenter:(UIView *)view withText:(NSString *)text;
//+ (void)showTipsInBottom:(UIView *)view withText:(NSString *)text;
//
//+ (void)showInfoTip:(NSString *)text;
//+ (void)showSuccessTip:(NSString *)text;
//+ (void)showErrorTip:(NSString *)text;
//
//+ (void)showOKDialog:(UIView *)view withText:(NSString *)text;
//+ (void)showNODialog:(UIView *)view withText:(NSString *)text;
//
//+ (void)showTipsWithImage:(UIView *)view withImage:(NSString *)imageName withText:(NSString *)text;
//+ (void)showTipsWithImage:(UIView *)view isWhiteStyle:(BOOL)isWhiteStyle withImage:(NSString *)imageName withText:(NSString *)text;



@end
