//
//  UIView+Corner.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/8.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Corner)

@property (nonatomic, assign) IBInspectable CGFloat cornerRadius;
@property (nonatomic, assign) IBInspectable UIColor *borderColor;
@property (nonatomic, assign) IBInspectable CGFloat borderWidth;

@end
