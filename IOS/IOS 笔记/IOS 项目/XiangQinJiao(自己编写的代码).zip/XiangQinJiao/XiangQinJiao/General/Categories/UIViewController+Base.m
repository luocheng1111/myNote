//
//  UIViewController+Base.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/8.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "UIViewController+Base.h"

@implementation UIViewController (Base)


- (SlideMenuController *)slideMenuController{
    
    UIViewController *controller = self.parentViewController;
    
    while (controller !=nil) {
        if(controller.class == SlideMenuController.class){
            return (SlideMenuController *)controller;
        }else{
            controller = controller.parentViewController;
        }
    }
    return nil;
    
}

- (IBAction)backButtonPressed:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
