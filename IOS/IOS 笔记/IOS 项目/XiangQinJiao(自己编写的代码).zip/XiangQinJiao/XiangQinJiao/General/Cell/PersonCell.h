//
//  PersonCell.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/23.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserInfo.h"

@interface PersonCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UIImageView *headImageView;
@property (nonatomic, weak) IBOutlet UIImageView *sexImageView;
@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel *ageLabel;
@property (nonatomic, weak) IBOutlet UILabel *heightLabel;
@property (nonatomic, weak) IBOutlet UILabel *recordLabel;
@property (nonatomic, weak) IBOutlet UILabel *addressLabel;
@property (nonatomic, weak) IBOutlet UILabel *salaryLabel;
@property (nonatomic, weak) IBOutlet UILabel *introduceLabel;
@property (nonatomic, weak) IBOutlet UILabel *timeLabel;
@property (nonatomic, weak) IBOutlet UIButton *helloButton;

- (void)loadData:(UserInfo *)userInfo;

@end
