//
//  URLMacro.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#ifndef URLMacro_h
#define URLMacro_h

#define BaseHost        @"http://cloud.bmob.cn/82d19b66f4dee40e"

#define URL_Login       @"http://cloud.bmob.cn/82d19b66f4dee40e/login"
#define URL_Register    @"http://cloud.bmob.cn/82d19b66f4dee40e/register"
#define URL_Infos       @"http://cloud.bmob.cn/82d19b66f4dee40e/infos"
#define URL_Publish     @"http://cloud.bmob.cn/82d19b66f4dee40e/publish"
#define URL_List        @"http://cloud.bmob.cn/82d19b66f4dee40e/list"

#define URL_UploadPrefix     @"https://api.bmob/cn/1/files/"
#define URL_DownloadPrefix   @"https://file.bmob.cn"

#endif /* URLMacro_h */
