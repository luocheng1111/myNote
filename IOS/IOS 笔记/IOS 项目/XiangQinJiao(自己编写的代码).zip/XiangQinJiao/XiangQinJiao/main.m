//
//  main.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/7.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <BmobSDK/Bmob.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        [Bmob registerWithAppKey:@"8516d8628bbd608c2b24f97f76c1d015"];
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
