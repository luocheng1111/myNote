//
//  RegisterViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "RegisterViewController.h"
#import "StringHelper.h"
#import "DialogHelper.h"
#import <BmobSDK/Bmob.h>
#import "UtilsMacro.h"

@interface RegisterViewController ()


@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}


- (BOOL)verify{
    NSString *username = [_textFields[0] text];
    if([StringHelper isEmpty:username]){
        [DialogHelper showTipsInCenter:self.view withText:@"请输入用户名"];
        return NO;
    }
    
    NSString *password = [_textFields[1] text];
    if([StringHelper isEmpty:password]){
        [DialogHelper showTipsInCenter:self.view withText:@"请输入密码"];
        return NO;
    }
    
    NSString *passwordAgain = [_textFields[2] text];
    if([StringHelper isEmpty:passwordAgain]){
        [DialogHelper showTipsInCenter:self.view withText:@"请再次输入密码"];
        return NO;
    }
    
    if(![password isEqualToString:passwordAgain]){
        [DialogHelper showTipsInCenter:self.view withText:@"两次输入的密码不一致"];
        return NO;
    }
    
    return YES;
}


- (IBAction)registerClick:(id)sender{
    [self.view endEditing:YES];
    
    if([self verify]){
        [DialogHelper showLoadingInView:self.view withText:@"加载中..."];
        NSString *username = [_textFields[0] text];
        NSString *password = [_textFields[1] text];

        BmobObject *obj = [[BmobObject alloc] initWithClassName:DBTableName_UserInfo];
        [obj setObject:username forKey:@"username"];
        [obj setObject:password forKey:@"password"];

        [obj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
//            NSLog(@"1 %ld",error.code);
            if (!error) {
                NSLog(@"插入用户表成功");
                //后面一系列操作;
                [self successWithTask];
            }else{
                [DialogHelper dismissLoadingInView:self.view];
                [self failureWithTask:error];
            }

        }];
    }
}



- (void)successWithTask{
    [DialogHelper dismissLoadingInView:self.view];
    [DialogHelper showTipsInBottom:self.view withText:@"用户注册成功"];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center postNotificationName:kNotificationTypeListDataChange object:nil];
    
    [self performSelector:@selector(goBack) withObject:nil afterDelay:0.3f];
}


- (void)failureWithTask:(NSError *)error{
    if (error.code==202||error.code==401) {
        [DialogHelper showTipsInCenter:self.view withText:@"此用户已注册，请重新填写"];
    }else{
        [DialogHelper showTipsInBottom:self.view withText:[[error userInfo] objectForKey:@"error"]];
    }
}



- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}



//创造虚拟数据
- (void)createData{
    for (int i=10000; i<10040; i++) {
        BmobObject *obj = [[BmobObject alloc] initWithClassName:DBTableName_UserInfo];
        [obj setObject:[NSString stringWithFormat:@"%d", i] forKey:@"username"];
        [obj setObject:@"123456" forKey:@"password"];
        
        [obj saveInBackgroundWithResultBlock:^(BOOL isSuccessful, NSError *error) {
            //            NSLog(@"1 %ld",error.code);
            if (!error) {
                NSLog(@"插入用户表成功");
                //后面一系列操作;
                //                [self successWithTask];
            }else{
                //                [DialogHelper dismissLoadingInView:self.view];
                //                [self failureWithTask:error];
            }
            
        }];
    }
}

- (IBAction)keyboardDownBtnClick:(UITextField *)field {
    NSInteger index = [self.textFields indexOfObject:field];
    if (index < _textFields.count - 1) {
        UITextField *nextField = _textFields[index + 1];
        [nextField becomeFirstResponder];
    } else {
        [field resignFirstResponder];
    }
}


@end
