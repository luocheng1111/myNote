//
//  LoginViewController.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/8.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseNavigationController.h"
@interface LoginViewController : BaseNavigationController

+ (void)Go:(UIViewController *)viewController;

@property (nonatomic,strong) IBOutletCollection(UITextField) NSArray *textFields; 

@end
