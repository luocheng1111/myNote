//
//  BaseController.h
//  DriverHelper
//
//  Created by 罗小成 on 2017/11/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseController : UIViewController


//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color;

@end
