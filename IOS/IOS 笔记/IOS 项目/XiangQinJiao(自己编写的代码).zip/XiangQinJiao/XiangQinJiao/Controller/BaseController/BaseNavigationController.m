//
//  BaseNavigationController.m
//  DriverHelper
//
//  Created by 罗小成 on 2017/11/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController



- (void) setBackBtnNull{
    UIBarButtonItem *item = [[UIBarButtonItem alloc] init];
    item.title = @"";
    self.navigationItem.backBarButtonItem = item;
}

- (void) setLeftBtn:(UIViewController *)controller string:(NSString *)string action:(SEL)action {
    controller.navigationItem.leftBarButtonItem = [self setBarButtonItem:controller string:string action:action];
}

- (void) setLeftBtn:(UIViewController *)controller image:(UIImage *)image action:(SEL)action {
    controller.navigationItem.leftBarButtonItem = [self setBarButtonItem:controller image:image action:action];
}

- (void) setRightBtn:(UIViewController *)controller string:(NSString *)string action:(SEL)action{
    controller.navigationItem.rightBarButtonItem = [self setBarButtonItem:controller string:string action:action];
}



- (UIBarButtonItem *) setBarButtonItem:(UIViewController *)controller string:(NSString *)string action:(SEL)action {
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.title = string;
    barButtonItem.tintColor = [UIColor whiteColor];
    [barButtonItem setTarget:controller];
    [barButtonItem setAction:action];
    return barButtonItem;
}

- (UIBarButtonItem *) setBarButtonItem:(UIViewController *)controller image:(UIImage *)image action:(SEL)action {
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.image = image;
    [barButtonItem setTarget:controller];
    [barButtonItem setAction:action];
    return barButtonItem;
}

- (IBAction)navigationBackClick{
   [self.navigationController popViewControllerAnimated:YES];
}

- (void)goBack{
    [self.navigationController popViewControllerAnimated:YES];
}

- (UIViewController *) getControllerByStoryBoardID:(NSString *)stodyboardID{
    return [self.storyboard instantiateViewControllerWithIdentifier:stodyboardID];
}


- (void) pushControllerByStoryBoardID:(NSString *)stodyboardID{
    UIViewController *controller = [self getControllerByStoryBoardID:stodyboardID];
    [self.navigationController pushViewController:controller animated:YES];
}

//- (void) pushControllerWithStoryBoardId:(NSString *)stodyboardID{
//    UIViewController *c = [self.storyboard instantiateViewControllerWithIdentifier:stodyboardID];
//    [self.navigationController pushViewController:c animated:YES];
//}


@end
