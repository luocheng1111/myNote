//
//  BaseNavigationController.h
//  DriverHelper
//
//  Created by 罗小成 on 2017/11/11.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "BaseController.h"

@interface BaseNavigationController : BaseController

- (void) setBackBtnNull;

- (void) setLeftBtn:(UIViewController *)controller string:(NSString *)string action:(SEL)action;

- (void) setLeftBtn:(UIViewController *)controller image:(UIImage *)image action:(SEL)action;

- (void) setRightBtn:(UIViewController *)controller string:(NSString *)string action:(SEL)action;

- (UIViewController *) getControllerByStoryBoardID:(NSString *)stodyboardID;

- (void) pushControllerByStoryBoardID:(NSString *)stodyboardID;

- (void)goBack;

@end
