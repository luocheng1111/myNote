//
//  PersonalViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/21.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "PersonalViewController.h"
#import "UserInfo.h"
#import "StringHelper.h"
#import "EditViewController.h"
#import <UIImageView+WebCache.h>
#import "UtilsMacro.h"
#import "DialogHelper.h"

@interface PersonalViewController ()

@property (nonatomic, assign) BOOL isMe;
@property (nonatomic, strong) UserInfo *userInfo;

@property (nonatomic, weak) IBOutlet UIImageView *headImageView;
@property (nonatomic, strong) IBOutletCollection(UILabel) NSArray *labels;
@property (strong, nonatomic) IBOutlet UIButton *helloBtn;


@end

@implementation PersonalViewController


+ (void)Go:(UIViewController *)viewController withObject:(UserInfo *)userInfo{
    PersonalViewController *controller = [viewController.storyboard instantiateViewControllerWithIdentifier:@"PersonalViewController"];
    controller.userInfo = userInfo;
    [viewController.navigationController pushViewController:controller animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initView];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self registerUserNotications];
}

- (void)dealloc{
    [self unregisterUserNotications];
}


- (void)registerUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(currentUserChange) name:kNotificationTypeCurrentUserChange object:nil];
}

- (void)unregisterUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self];
}


- (void)currentUserChange{
//    _userInfo = [UserInfo currentUser];
    if(_userInfo.objectId == [UserInfo currentUser].objectId){
        _userInfo = [UserInfo currentUser];
    }
    [self initData];
}



- (void)initView {
    _isMe = [_userInfo.objectId isEqualToString:[UserInfo currentUser].objectId];
    if (_isMe == NO) {
        self.navigationItem.rightBarButtonItem = nil;
        self.title = @"个人资料";
    }
    
    [self initData];
}

- (void)initData{
    UserInfo *convertUserInfo = [self convertUserInfoForPage:_userInfo];
    
    [_headImageView sd_setImageWithURL:[NSURL URLWithString:convertUserInfo.photo] placeholderImage:[UIImage imageNamed:@"personal_head"]];
    
    [_labels[0] setText:convertUserInfo.nickname];
    [_labels[1] setText:convertUserInfo.sex];
    [_labels[2] setText:convertUserInfo.record];
    [_labels[3] setText:convertUserInfo.salary];
    [_labels[4] setText:convertUserInfo.age];
    [_labels[5] setText:convertUserInfo.height];
    [_labels[6] setText:convertUserInfo.marital];
    [_labels[7] setText:convertUserInfo.address];
    [_labels[8] setText:convertUserInfo.contact];
    [_labels[9] setText:convertUserInfo.introduce];
    
    NSMutableArray *helloIds = [UserInfo currentUser].helloIds;
    if(![helloIds containsObject:_userInfo.objectId]){
        [_helloBtn setEnabled:YES];
    }else{
        _helloBtn.alpha=0.4;//透明度
        [_helloBtn setEnabled:NO];
        [_helloBtn setTitle:@"已打招呼" forState:UIControlStateDisabled];
    }
    [self.tableView reloadData];
}


- (IBAction)helloClick{
    [DialogHelper showLoadingInView:self.view withText:@"加载中..."];
    
    UserInfo *userInfo = [UserInfo currentUser];
    BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:DBTableName_UserInfo objectId:userInfo.objectId];
    //设置cheatMode为YES
    if(userInfo.helloIds == nil){
        userInfo.helloIds = [[NSMutableArray alloc] init];
    };
    [userInfo.helloIds addObject:_userInfo.objectId];
    [obj setObject:userInfo.helloIds forKey:@"helloIds"];
    //异步更新数据
    [obj updateInBackground];
    
    [self performSelector:@selector(helloOver:) withObject:userInfo afterDelay:0.3f];
}

- (void)helloOver:(UserInfo *)userInfo{
    [DialogHelper dismissLoadingInView:self.view];
    
    [UserInfo setCurrentUser:userInfo];
    self.helloBtn.enabled = NO;
    self.helloBtn.alpha=0.4;//透明度
    [DialogHelper showTipsInCenter:self.view withText:@"已成功打招呼"];
    [_helloBtn setTitle:@"已打招呼" forState:UIControlStateDisabled];
    
}

- (UserInfo *)convertUserInfoForPage:(UserInfo *)userInfo{
    UserInfo *convertUserInfo = [UserInfo new];
    
    convertUserInfo.objectId = userInfo.objectId;
    convertUserInfo.photo = userInfo.photo;
    convertUserInfo.username = userInfo.username;
    convertUserInfo.helloIds = userInfo.helloIds;
    convertUserInfo.createdAt = userInfo.createdAt;
    convertUserInfo.nickname = ![StringHelper isEmpty:userInfo.nickname] ? userInfo.nickname : @"-";;
    convertUserInfo.sex = ![StringHelper isEmpty:userInfo.sex] ? userInfo.sex : @"-";;
    convertUserInfo.record = ![StringHelper isEmpty:userInfo.record] ? userInfo.record : @"-";;
    convertUserInfo.marital = ![StringHelper isEmpty:userInfo.marital] ? userInfo.marital : @"-";;
    convertUserInfo.address = ![StringHelper isEmpty:userInfo.address] ? userInfo.address : @"-";;
    convertUserInfo.contact = ![StringHelper isEmpty:userInfo.contact] ? userInfo.contact : @"-";;
    convertUserInfo.introduce = ![StringHelper isEmpty:userInfo.introduce] ? userInfo.introduce : @" -";;
    NSInteger salary = [userInfo.salary intValue];
    convertUserInfo.salary = [NSString stringWithFormat:@"%ld", salary];
    NSInteger age = [userInfo.age intValue];
    convertUserInfo.age = [NSString stringWithFormat:@"%ld", age];
    NSInteger height = [userInfo.height intValue];
    convertUserInfo.height = [NSString stringWithFormat:@"%ld", height];
    return convertUserInfo;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if([UserInfo currentUser]==nil){
        return 2;
    }
    return (_isMe ? 2 : 3);
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return 114;
    } else if (indexPath.row == 1) {
        return [self theSecondCellHeight];
    } else {
        return 60;
    }
    return  0;
}

- (CGFloat)theSecondCellHeight {
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
    CGFloat width = screenSize.width - 64;
    CGSize size = CGSizeMake(width, 0);
    size = [_labels[9] sizeThatFits:size];
    return (size.height + 284);
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"ToEditViewController"]) {
        EditViewController *vierController = segue.destinationViewController;
        vierController.userInfo = _userInfo;
    }
}



@end
