//
//  UserViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/7.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "UserViewController.h"
#import "LoginViewController.h"
#import "UtilsMacro.h"
#import "DialogHelper.h"
#import "SlideMenuController.h"
#import "HomeViewController.h"
#import "UIViewController+Base.h"
#import <BmobSDK/Bmob.h>
#import "PersonalViewController.h"
#import "UserInfo.h"
#import "StringHelper.h"
#import <UIImageView+WebCache.h>


@interface UserViewController ()

@property(nonatomic, assign) BOOL isLogin;

@property(nonatomic, weak) IBOutlet UIImageView *headImageView;
@property(nonatomic, weak) IBOutlet UILabel  *nameLabel;

@end

@implementation UserViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置背景
    self.tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"menu_bg"]];
    
    _isLogin = ([UserInfo currentUser]==nil?NO:YES);
    [self refreshUI];
}


- (IBAction)headTapped{
    if(!_isLogin){
        [LoginViewController Go:[self convertSelfToHomeViewController]];
        [self.slideMenuController showContentViewController];
    }
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _isLogin?3:0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:{ //个人资料
            [PersonalViewController Go:[self convertSelfToHomeViewController] withObject:[UserInfo currentUser]];
            [self.slideMenuController showContentViewController];
            break;
        }
        case 1:{ //消息中心
            break;
        }
        case 2:{ //注销
            [UserInfo removeCurrentUser];
            _isLogin = NO;
            [self refreshUI];
            break;
        }
    }
}


- (void)refreshUI{
    if(_isLogin){ //登录
        UserInfo *userInfo = [UserInfo currentUser];
        _nameLabel.text = [StringHelper isEmpty:userInfo.nickname] ? userInfo.username : userInfo.nickname;
        
        //加载头像
        [_headImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.photo] placeholderImage:[UIImage imageNamed:@"default_user"]];
        
        //刷新用户列表
        [self.tableView reloadData];
    }else{ //未登录
        _headImageView.image = [UIImage imageNamed:@"default_user"];
        _nameLabel.text = @"点击头像登录";
        [self.tableView reloadData];
    }
}



- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self registerUserNotications];
}

- (void)dealloc{
    [self unregisterUserNotications];
}

- (void)registerUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(currentUserChange) name:kNotificationTypeCurrentUserChange object:nil];
}

- (void)unregisterUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self];
}

- (void)currentUserChange{
    _isLogin = ([UserInfo currentUser]==nil?NO:YES);
    [self refreshUI];
}

//因为HomeViewController有navigationController 方便跳转
- (UIViewController *)convertSelfToHomeViewController{
    HomeViewController *homeViewController = self.parentViewController.childViewControllers.lastObject.childViewControllers.firstObject;
    return homeViewController;
}

- (void)goViewControllerByIdentifier:(NSString *)identifier{
    // 导航效果
    HomeViewController *nav = self.parentViewController.childViewControllers.lastObject.childViewControllers.firstObject;
    UIViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:identifier];
    [nav.navigationController pushViewController:controller animated:YES];
    
    [self.slideMenuController showContentViewController];
}

@end
