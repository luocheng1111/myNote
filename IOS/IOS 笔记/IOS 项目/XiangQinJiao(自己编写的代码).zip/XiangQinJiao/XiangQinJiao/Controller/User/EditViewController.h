//
//  EditViewController.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/21.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserInfo.h"
#import "BaseNavigationController.h"

@interface EditViewController : BaseNavigationController

@property (nonatomic, strong) UserInfo *userInfo;

@end
