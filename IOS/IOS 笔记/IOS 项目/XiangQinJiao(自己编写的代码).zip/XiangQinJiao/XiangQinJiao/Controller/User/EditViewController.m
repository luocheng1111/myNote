//
//  EditViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/21.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "EditViewController.h"
#import "DialogHelper.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <BmobSDK/Bmob.h>
#import <UIImageView+WebCache.h>
#import "StringHelper.h"
#import <AFNetworking.h>
#import "UtilsMacro.h"

@interface EditViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, strong) UIImage *headImage;


@property (nonatomic, weak) IBOutlet UIImageView *headImageView;
@property (nonatomic, strong) IBOutletCollection(UITextField) NSArray *fields;
@property (nonatomic, weak) IBOutlet UITextView *textView;
@property (nonatomic, weak) IBOutlet UIScrollView *scrollView;

@end

@implementation EditViewController


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self registerNotifications];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self unregisterNotifications];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    
    [self initView];
}

- (void)initView {
    
    UserInfo *convertUserInfo = [self convertUserInfoForPage:_userInfo];
    
    [_headImageView sd_setImageWithURL:[NSURL URLWithString:convertUserInfo.photo] placeholderImage:[UIImage imageNamed:@"personal_head"]];
    
    [_fields[0] setPlaceholder:convertUserInfo.nickname];
    [_fields[1] setPlaceholder:convertUserInfo.sex];
    [_fields[2] setPlaceholder:convertUserInfo.record];
    [_fields[3] setPlaceholder:convertUserInfo.salary];
    [_fields[4] setPlaceholder:convertUserInfo.age];
    [_fields[5] setPlaceholder:convertUserInfo.height];
    [_fields[6] setPlaceholder:convertUserInfo.marital];
    [_fields[7] setPlaceholder:convertUserInfo.address];
    [_fields[8] setPlaceholder:convertUserInfo.contact];
    [_textView setText:convertUserInfo.introduce];
}


- (UserInfo *)convertUserInfoForPage:(UserInfo *)userInfo{
    UserInfo *convertUserInfo = [UserInfo new];
    convertUserInfo.objectId = userInfo.objectId;
    convertUserInfo.photo = userInfo.photo;
    convertUserInfo.username = userInfo.username;
    convertUserInfo.helloIds = userInfo.helloIds;
    convertUserInfo.createdAt = userInfo.createdAt;
    convertUserInfo.nickname = ![StringHelper isEmpty:userInfo.nickname] ? userInfo.nickname : @"-";;
    convertUserInfo.sex = ![StringHelper isEmpty:userInfo.sex] ? userInfo.sex : @"-";;
    convertUserInfo.record = ![StringHelper isEmpty:userInfo.record] ? userInfo.record : @"-";;
    convertUserInfo.marital = ![StringHelper isEmpty:userInfo.marital] ? userInfo.marital : @"-";;
    convertUserInfo.address = ![StringHelper isEmpty:userInfo.address] ? userInfo.address : @"-";;
    convertUserInfo.contact = ![StringHelper isEmpty:userInfo.contact] ? userInfo.contact : @"-";;
    convertUserInfo.introduce = ![StringHelper isEmpty:userInfo.introduce] ? userInfo.introduce : @" -";;
    NSInteger salary = [userInfo.salary intValue];
    convertUserInfo.salary = [NSString stringWithFormat:@"%ld", salary];
    NSInteger age = [userInfo.age intValue];
    convertUserInfo.age = [NSString stringWithFormat:@"%ld", age];
    NSInteger height = [userInfo.height intValue];
    convertUserInfo.height = [NSString stringWithFormat:@"%ld", height];
    return convertUserInfo;
}


- (IBAction)headTapped{
    [self keyBoardDimiss];
    
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    [sheet addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self openCamera];
    }]];
    
    [sheet addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self openPhotoLibrary];
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];

    [self presentViewController:sheet animated:YES completion:nil];
}

     
- (void)openCamera {
     [self getMediaFromSourceWithType:UIImagePickerControllerSourceTypeCamera];
}
     
- (void)openPhotoLibrary {
     [self getMediaFromSourceWithType:UIImagePickerControllerSourceTypePhotoLibrary];
}


- (void)getMediaFromSourceWithType:(UIImagePickerControllerSourceType)type {
    NSArray *types = [UIImagePickerController availableMediaTypesForSourceType:type];
    if ([UIImagePickerController isSourceTypeAvailable:type] && types.count > 0) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.mediaTypes = types;
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = type;
        [self presentViewController:picker animated:YES completion:nil];
    } else {
        NSString *text;
        
        if (type == UIImagePickerControllerSourceTypeCamera) {
            text = @"拍照功能不可用";
        } else {
            text = @"相册不可以访问";
        }
        
        [DialogHelper showTipsInCenter:self.view withText:text];
    }
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    NSString *type = info[UIImagePickerControllerMediaType];
    if ([type isEqual:(NSString *)kUTTypeImage]) {
        UIImage *editedImage = info[UIImagePickerControllerEditedImage];
        self.headImage = [self shrinkImage:editedImage size:CGSizeMake(100, 100)];
    }
    
    [picker dismissViewControllerAnimated:YES completion:^{
        if (_headImage != nil) {
            _headImageView.image = _headImage;
        }
    }];
}


- (UIImage *)shrinkImage:(UIImage *)original size:(CGSize)size {
    CGFloat scale = [[UIScreen mainScreen] scale];
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    CGFloat width = size.width * scale;
    CGFloat height = size.height * scale;
    uint32_t info = kCGImageAlphaPremultipliedFirst;
    
    CGContextRef context = CGBitmapContextCreate(nil, width, height, 8, 0, colorSpace, info);
    CGRect rect = CGRectMake(0, 0, width, height);
    CGContextDrawImage(context, rect, original.CGImage);
    CGImageRef shrunken = CGBitmapContextCreateImage(context);
    UIImage *finalImage = [UIImage imageWithCGImage:shrunken];
    
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    CGImageRelease(shrunken);
    
    return finalImage;
}



- (IBAction)submit{
    [self keyBoardDimiss];
    
    //因为是异步，所以这里逻辑有点乱
    [DialogHelper showLoadingInView:self.view withText:@"数据提交中..."];
    
    if(_headImage!=nil){
        [self uploadImageFile];
    }else{
        [self submitData:_userInfo.photo];
    }
}


- (void)submitData:(NSString *)photoUrl{

    _userInfo.photo = photoUrl;
    _userInfo.nickname = [StringHelper isEmpty:[_fields[0] text]]? _userInfo.nickname : [_fields[0] text];
    _userInfo.sex = [StringHelper isEmpty:[_fields[1] text]]? _userInfo.sex : [_fields[1] text];
    _userInfo.record = [StringHelper isEmpty:[_fields[2] text]]? _userInfo.record : [_fields[2] text];
    
    int number = [[_fields[3] text] intValue];
    if (number > 0) {
        _userInfo.salary = [NSNumber numberWithInt:number].stringValue;
    }
    
    number = [[_fields[4] text] intValue];
    if (number > 0) {
        _userInfo.age = [NSNumber numberWithInt:number].stringValue;
    }
    
    number = [[_fields[5] text] intValue];
    if (number > 0) {
        _userInfo.height = [NSNumber numberWithInt:number].stringValue;
    }
    
    _userInfo.marital = [StringHelper isEmpty:[_fields[6] text]]? _userInfo.marital : [_fields[6] text];
    _userInfo.address = [StringHelper isEmpty:[_fields[7] text]]? _userInfo.address : [_fields[7] text];
    _userInfo.contact = [StringHelper isEmpty:[_fields[8] text]]? _userInfo.contact : [_fields[8] text];
    _userInfo.introduce = [[_textView text] isEqualToString:@"-"]? _userInfo.introduce : [_textView text];
    
    BmobObject *obj = [BmobObject objectWithoutDatatWithClassName:DBTableName_UserInfo objectId:_userInfo.objectId];
    
    [obj saveAllWithDictionary:[UserInfo toDictionaryWithOutUserName:_userInfo]];
    //异步更新数据
    [obj updateInBackground];
    
    [self performSelector:@selector(successWithTask) withObject:nil afterDelay:0.3f];
}

- (void)successWithTask{
    [DialogHelper dismissLoadingInView:self.view];
    [DialogHelper showTipsInBottom:self.view withText:@"资料修改成功"];
    
    [UserInfo setCurrentUser:_userInfo];
    
    [self performSelector:@selector(goBack) withObject:nil afterDelay:0.3f];
}

-(void)uploadImageFile{
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSDictionary *parameters = @{
                                 @"user_id":@"557",
                                 @"token":@"1ab41dc945e4fcb3e996e98b7ce21d48",
                                 @"imgtype":@"1",
                                 @"rg_id":@"web",
                                 @"rg_ver":@"9999"
                                 };
    
    [manager POST:@"http://api.ruigushop.com/v0.1/upload/uploadImg" parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
//        NSData *data = [NSData dataWithContentsOfFile:@"/Users/luocheng/Desktop/IOS/AFNetwork_study01/aaa.png"];
        NSData *imageData = UIImagePNGRepresentation(_headImage);
        
        [formData appendPartWithFileData:imageData name:@"upfile" fileName:@"ccc.png" mimeType:@"image/png"];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        NSLog(@"%f",1.0 * uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"success--%@",responseObject);
//        NSData *jsonData = [responseObject dataUsingEncoding:NSUTF8StringEncoding];
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:nil];
        NSDictionary *dic = [responseObject objectForKey:@"data"];
        NSString *imageUrl = [dic objectForKey:@"url"];
        imageUrl = [imageUrl substringToIndex:[imageUrl length] - 5];
        NSLog(@"imageUrl %@", imageUrl);
        [self submitData:imageUrl];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"failure -- %@",error);
    }];
}


- (void)keyBoardDimiss{
    for(int i=0; i<self.fields.count; i++){
        [self.fields[i] resignFirstResponder];
    }
    [self.textView resignFirstResponder];
}


- (void)registerNotifications {
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(keyboardWillShow:)
                   name:UIKeyboardWillShowNotification object:nil];
    [center addObserver:self selector:@selector(keyboardWillHide:)
                   name:UIKeyboardWillHideNotification object:nil];
}

- (void)unregisterNotifications {
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self];
}

- (void)keyboardWillShow:(NSNotification *)sender {
    NSDictionary *info = sender.userInfo;
    CGRect bounds = [info[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat duration = [info[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    UIView *inputField = [self firstResponder];
    CGRect rect = [inputField convertRect:inputField.bounds toView:_scrollView];
    rect.origin.y += 8;
    
    void(^animations)(void) = ^{
        //
        UIEdgeInsets insets = _scrollView.contentInset;
        insets.bottom = bounds.size.height;
        _scrollView.contentInset = insets;
        
        //
        [_scrollView scrollRectToVisible:rect animated:NO];
    };
    
    if (duration > 0) {
        NSInteger value = [info[UIKeyboardAnimationCurveUserInfoKey] integerValue];
        UIViewAnimationOptions options = (value << 16);
        [UIView animateWithDuration:duration delay:0 options:options
                         animations:animations completion:nil];
    } else {
        animations();
    }
}

- (void)keyboardWillHide:(NSNotification *)sender {
    NSDictionary *info = sender.userInfo;
    CGFloat duration = [info[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    void(^animations)(void) = ^{
        //
        UIEdgeInsets insets = _scrollView.contentInset;
        insets.bottom = 0;
        _scrollView.contentInset = insets;
        
        //
        _scrollView.contentOffset = CGPointMake(0, 0);
    };
    
    if (duration > 0) {
        NSInteger value = [info[UIKeyboardAnimationCurveUserInfoKey] integerValue];
        UIViewAnimationOptions options = (value << 16);
        [UIView animateWithDuration:duration delay:0 options:options
                         animations:animations completion:nil];
    } else {
        animations();
    }
}

- (UIView *)firstResponder {
    if ([_textView isFirstResponder]) {
        return _textView;
    } else {
        for (UITextField *field in _fields) {
            if ([field isFirstResponder]) {
                return field;
            }
        }
    }
    return nil;
}

- (IBAction)textFieldDidEndOnExit:(UITextField *)field {
    NSInteger index = [_fields indexOfObject:field];
    if (index < _fields.count - 1) {
        UITextField *nextField = _fields[index + 1];
        [nextField becomeFirstResponder];
    } else {
        [_textView becomeFirstResponder];
    }
}

@end
