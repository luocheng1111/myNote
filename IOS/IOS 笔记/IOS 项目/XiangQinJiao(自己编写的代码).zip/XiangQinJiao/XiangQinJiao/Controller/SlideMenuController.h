//
//  SlideMenuController.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/7.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideMenuController : UIViewController

@property (nonatomic, weak) IBOutlet UIPanGestureRecognizer *pan; 
@property (nonatomic, assign) BOOL isPanEnabled;

- (void)showMenuViewController;

- (void)showContentViewController;



@end
