//
//  SlideMenuController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/7.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "SlideMenuController.h"
#import <Masonry.h>
@interface SlideMenuController ()

@property (nonatomic, weak) IBOutlet UIView *menuContainer;
@property (nonatomic, weak) IBOutlet UIView *contentContainer;

@property (nonatomic, strong) UIButton *maskButton;
@property (nonatomic, assign) BOOL folded;
@property (nonatomic, assign) CGPoint originalPoint;
@property (nonatomic, assign) CGFloat scaleFactor;
@property (nonatomic, assign) CGFloat offsetX;
@property (nonatomic, assign) CGFloat originalX;
@property (nonatomic, assign) CGFloat deltaAlphaFactor;
@property (nonatomic, assign) CGFloat deltaScaleFactor;
@property (nonatomic, assign) CGFloat miniumOffsetX;

@end

@implementation SlideMenuController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initParams];
}

- (void)initParams{
    _folded = YES;
    _scaleFactor = 0.95;
    _offsetX = self.view.frame.size.width/2+30;
    _deltaAlphaFactor = 1/_offsetX;
    _miniumOffsetX = _offsetX/2;
    _deltaScaleFactor = (1-_scaleFactor)/_offsetX;
        
}

- (void)showMenuViewController{
    self.folded = NO;
    
    [self setShadowVisible:YES];
    
    CGAffineTransform transform = CGAffineTransformMakeTranslation(_offsetX, 0);
    transform = CGAffineTransformScale(transform, _scaleFactor, _scaleFactor);
    [UIView animateWithDuration:0.35 animations:^{
        self.menuContainer.alpha=1;
        self.contentContainer.transform = transform;
    } completion:^(BOOL finished) {
        [self setMaskButtonVisiable:YES];
    }];
}

- (void)showContentViewController{
    self.folded = YES;
    
    [self setShadowVisible:NO];
    
    [UIView animateWithDuration:0.35 animations:^{
        self.menuContainer.alpha=0;
        self.contentContainer.transform = CGAffineTransformIdentity;
    } completion:^(BOOL finished) {
        [self setMaskButtonVisiable:NO];
    }];
}

- (void)setMaskButtonVisiable:(BOOL)visible{
    if(self.maskButton==nil){
        _maskButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_maskButton addTarget:self action:@selector(maskBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [_contentContainer addSubview:_maskButton];
        [_maskButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(_contentContainer).insets(UIEdgeInsetsZero);
        }];
    };
    
    self.maskButton.hidden = !visible;
}

- (void)setShadowVisible:(BOOL)visible{
    if(visible){
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:_contentContainer.layer.bounds];
        _contentContainer.layer.shadowPath = path.CGPath;
        _contentContainer.layer.shadowColor = [UIColor blackColor].CGColor;
        _contentContainer.layer.shadowOffset = CGSizeZero;
        _contentContainer.layer.shadowOpacity = 0.4;
        _contentContainer.layer.shadowRadius = 4.5;
        
    }else{
        _contentContainer.layer.shadowRadius = 0;
    }
}

- (IBAction)panned:(UIPanGestureRecognizer *)sender{
    if(!_isPanEnabled){
        return;
    }
    
    CGPoint point = [sender locationInView:self.view];
    switch (sender.state) {
            case UIGestureRecognizerStateBegan:{
                _originalPoint = point;
                [self setShadowVisible:YES];
            }
            break;
            case UIGestureRecognizerStateChanged:{
                CGFloat tx = point.x - _originalPoint.x + self.originalX;
                tx = tx < 0 ? 0 : tx;
                
                CGFloat s = 1- tx * self.deltaScaleFactor;
                s = s < 0 ? 0 : s;
                
                CGAffineTransform transform = CGAffineTransformMakeTranslation(tx, 0);
                transform = CGAffineTransformScale(transform, s, s);
                _contentContainer.transform = transform;
                
                CGFloat alpha = tx * self.deltaAlphaFactor;
                alpha = alpha>1 ? 1 : alpha;
                _menuContainer.alpha = alpha;
            }
            break;
            case UIGestureRecognizerStateEnded:
            case UIGestureRecognizerStateCancelled:{
                CGAffineTransform transform = _contentContainer.transform;
                if(transform.tx>=self.miniumOffsetX){
//                    self.folded = NO;
                    [self showMenuViewController];
                }else{
//                    self.folded = YES;
                    [self showContentViewController];
                }
            }
            break;
            
        
    }
}

- (CGFloat)originalX{
    return (_folded?0:_offsetX);
}

- (void)maskBtnClick{
    _folded = !_folded;
    [self showContentViewController];
}



@end
