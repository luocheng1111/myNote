//
//  FilterViewController.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "BaseNavigationController.h"

//委托方-创建一个协议
@protocol passValueDelegate <NSObject>
//协议定义一个传值的方法
- (void)changeFilter:(NSDictionary *)filterData;
@end

@interface FilterViewController : BaseNavigationController

@property (weak)id<passValueDelegate>delegate;

@property (nonatomic, strong) NSDictionary *filterData;

@end
