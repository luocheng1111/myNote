//
//  HomeViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/7.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "HomeViewController.h"
#import "UIViewController+Base.h"
#import <BmobSDK/Bmob.h>
#import "UserInfo.h"
#import "PersonCell.h"
#import "PersonalViewController.h"
#import <MJRefresh.h>
#import "DialogHelper.h"
#import "UtilsMacro.h"
#import "FilterViewController.h"


@interface HomeViewController ()<passValueDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, weak) IBOutlet UIView *searchContainer;
@property (nonatomic, weak) IBOutlet UITextField *field;

@property (nonatomic, strong) NSMutableArray *objects;
@property (nonatomic, assign) NSInteger page;
@property (nonatomic, assign) BOOL noMore;
@property (nonatomic, assign) NSInteger pageCount;
@property (nonatomic, assign) BOOL isFilterBack;
@property (nonatomic, assign) BOOL isTopSearch;
@property (nonatomic, assign) BOOL isRefresh;
@property (nonatomic, strong) NSString *searchStr;

@end

@implementation HomeViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.slideMenuController.isPanEnabled = YES;
    [self registerUserNotications];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.slideMenuController.isPanEnabled = NO;
}

- (void)dealloc{
    [self unregisterUserNotications];
}


- (void)registerUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self selector:@selector(dataChange) name:kNotificationTypeCurrentUserChange object:nil];
    [center addObserver:self selector:@selector(dataChange) name:kNotificationTypeListDataChange object:nil];
}

- (void)unregisterUserNotications{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center removeObserver:self];
}

- (void)dataChange{
    [_tableView.mj_header beginRefreshing];
}

- (void)changeFilter:(NSDictionary *)filterData{
    self.filterData = filterData;
    _isFilterBack = YES;
    [_tableView.mj_header beginRefreshing];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加下拉刷新 & 上拉加载更多
    [self addHeader];
    [self addFooter];
    
    //初始化数据
    [self initData];
    
    //设置滚蛋时关闭键盘
    _tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;

    // 上拉刷新加载数据
    [_tableView.mj_header beginRefreshing];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    _searchStr = _field.text;
    _field.text = @"";
    [_field resignFirstResponder];
    
    _isTopSearch = YES;
    
    [_tableView.mj_header beginRefreshing];
    
    return YES;
}


- (void)initData {
    _page = 0;
    _pageCount = 5;
    _noMore = NO;
    _isFilterBack = NO;
    _isTopSearch = NO;
    _isRefresh = NO;
    _objects = [[NSMutableArray alloc] init];
}


- (void)addHeader {
    MJRefreshNormalHeader *header =
    [MJRefreshNormalHeader headerWithRefreshingTarget:self
                                     refreshingAction:@selector(refresh)];
    header.lastUpdatedTimeLabel.hidden = NO;
    header.stateLabel.hidden = NO;
    _tableView.mj_header = header;
}

- (void)addFooter {
    MJRefreshBackNormalFooter *footer =
    [MJRefreshBackNormalFooter footerWithRefreshingTarget:self
                                         refreshingAction:@selector(loadMore)];
    footer.stateLabel.hidden = YES;
    _tableView.mj_footer = footer;
}

- (void)refresh {
    _isRefresh = YES;
    _page = 0;
    
    [self loadData];
}

- (void)loadMore {
    if(_noMore){
        if([_tableView.mj_footer isRefreshing]){
            [_tableView.mj_footer endRefreshing];
        }
        [DialogHelper showTipsInBottom:self.view withText:@"没有更多的数据了"];
    }else{
        self.page++;
        [self loadData];
    }
    
}

- (void)loadData {
    BmobQuery *query = [BmobQuery queryWithClassName:DBTableName_UserInfo];
    query.skip = _page*_pageCount;//跳过几条数据
    query.limit = _pageCount;//限制得到的结果数字
    [query orderByDescending:@"createdAt"];//倒叙查询，数据库的原因，为了新注册的用户显示在第一个
    
    if(_filterData != nil){
        //性别
        [query whereKey:@"sex" equalTo:_filterData[@"sex"]];
    
//        NSArray *array =  @[@{@"age":@{@"$gte":@20}},@{@"age":@{@"$lte":@30}}];
//        [query addTheConstraintByAndOperationWithArray:array];
        
        NSMutableArray *filterArray = [[NSMutableArray alloc] init];
        //年龄
        if(_filterData[@"minAge"]!=nil && _filterData[@"maxAge"]!=nil){
            [filterArray addObjectsFromArray: @[@{@"age":@{@"$gte":_filterData[@"minAge"]}},@{@"age":@{@"$lte":_filterData[@"maxAge"]}}]];
        }else{
            [query whereKey:@"age" greaterThanOrEqualTo:_filterData[@"minAge"]];
            [query whereKey:@"age" lessThanOrEqualTo:_filterData[@"maxAge"]];
        }

        //身高
        if(_filterData[@"minHeight"]!=nil && _filterData[@"maxHeight"]!=nil){
            [filterArray addObjectsFromArray: @[@{@"height":@{@"$gte":_filterData[@"minHeight"]}},@{@"height":@{@"$lte":_filterData[@"maxHeight"]}}]];
        }else{
            [query whereKey:@"height" greaterThanOrEqualTo:_filterData[@"minHeight"]];
            [query whereKey:@"height" lessThanOrEqualTo:_filterData[@"maxHeight"]];
        }

        //工资
        if(_filterData[@"minSalary"]!=nil && _filterData[@"maxSalary"]!=nil){
            [filterArray addObjectsFromArray: @[@{@"salary":@{@"$gte":_filterData[@"minSalary"]}},@{@"salary":@{@"$lte":_filterData[@"maxSalary"]}}]];

        }else{
            [query whereKey:@"salary" greaterThanOrEqualTo:_filterData[@"minSalary"]];
            [query whereKey:@"salary" lessThanOrEqualTo:_filterData[@"maxSalary"]];
        }

        if(filterArray.count>0){
            [query addTheConstraintByAndOperationWithArray:[filterArray copy]];
        }
    }
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        [self dimissRefreshAnim];
        if(array.count>0){
            if(_isRefresh){
                [_objects removeAllObjects];
            }
            for (BmobObject *obj in array) {
                [_objects addObject:[UserInfo toUserInfoByBmobObj:obj]];
            }
            [_tableView reloadData];
            
            if(array.count<_pageCount){
                _noMore = YES;
            }else{
                _noMore = NO;
            }
        }else{
            _noMore = YES;
            [_tableView reloadData];
            if(_isFilterBack){
                [DialogHelper showTipsInBottom:self.view withText:@"搜索无结果"];
            }else{
                if(_isRefresh){
//                    [DialogHelper showTipsInBottom:self.view withText:@"没有数据"];
                }else{
                    [DialogHelper showTipsInBottom:self.view withText:@"没有更多的数据了"];
                }
            }
        }
        if(_isTopSearch){
            [DialogHelper showTipsInBottom:self.view withText:@"因接口付费，所以此功能未开放"];
        }
        _isFilterBack = NO;
        _searchStr = @"";
        _isTopSearch = NO;
        _isRefresh = NO;
    }];
}

- (void)showRefreshAnim{
    if(![_tableView.mj_header isRefreshing]){
        [_tableView.mj_header endRefreshing];
    }
    
    if([_tableView.mj_footer isRefreshing]){
        [_tableView.mj_footer endRefreshing];
    }
}

- (void)dimissRefreshAnim{
    if([_tableView.mj_header isRefreshing]){
        [_tableView.mj_header endRefreshing];
    }
    
    if([_tableView.mj_footer isRefreshing]){
        [_tableView.mj_footer endRefreshing];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [PersonalViewController Go:self withObject:_objects[indexPath.row]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _objects.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"HomeViewCell";
    PersonCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell==nil){
        cell = [[PersonCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    UserInfo *userInfo = _objects[indexPath.row];
    [cell loadData:userInfo];
    return cell;
}


- (IBAction)showMenu:(id)sender {
    [self.slideMenuController showMenuViewController];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"ToFilterViewController"]) {
        FilterViewController *vierController = segue.destinationViewController;
        vierController.delegate = self;
        vierController.filterData = _filterData;
    }
}



@end
