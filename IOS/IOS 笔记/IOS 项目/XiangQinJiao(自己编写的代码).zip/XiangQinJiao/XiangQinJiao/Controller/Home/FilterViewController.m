//
//  FilterViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "FilterViewController.h"
#import "HomeViewController.h"
#import "StringHelper.h"

@interface FilterViewController ()

@property (nonatomic, weak) IBOutlet UITextField *sexField;
@property (nonatomic, strong) IBOutletCollection(UITextField) NSArray *ageFields;
@property (nonatomic, strong) IBOutletCollection(UITextField) NSArray *heightFields;
@property (nonatomic, strong) IBOutletCollection(UITextField) NSArray *salaryFields;
@property (nonatomic, weak) IBOutlet UIView *container;

@end

@implementation FilterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initView];
}


- (void)initView{
    NSString *text = _filterData[@"sex"];
    if (![StringHelper isEqual:text]) {
        _sexField.text = text;
    }
    
    NSNumber *number = _filterData[@"minAge"];
    if (number != nil) {
        [_ageFields[0] setText:[number stringValue]];
    }
    number = _filterData[@"maxAge"];
    if (number != nil) {
        [_ageFields[1] setText:[number stringValue]];
    }
    
    
    number = _filterData[@"minHeight"];
    if (number != nil) {
        [_heightFields[0] setText:[number stringValue]];
    }
    number = _filterData[@"maxHeight"];
    if (number != nil) {
        [_heightFields[1] setText:[number stringValue]];
    }
    
    
    number = _filterData[@"minSalary"];
    if (number != nil) {
        [_salaryFields[0] setText:[number stringValue]];
    }
    number = _filterData[@"maxSalary"];
    if (number != nil) {
        [_salaryFields[1] setText:[number stringValue]];
    }
}


- (IBAction)okButtonPressed {
    [self.view endEditing:YES];
    
//    HomeViewController *homeViewController = [self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-2];
//    homeViewController.filterData = [self dataFromFields];
    [self.delegate changeFilter:[self dataFromFields]];
    [self.navigationController popViewControllerAnimated:YES];
//    [self.navigationController popToViewController:homeViewController animated:true];
    
}

- (NSDictionary *)dataFromFields {
    NSMutableDictionary *data = [[NSMutableDictionary alloc] init];
    
    NSString *text = [_sexField text];
    if (![StringHelper isEmpty:text]) {
        if ([text isEqualToString:@"男"] || [text isEqualToString:@"女"]) {
            data[@"sex"] = text;
        }
    }
    
    
    text = [_ageFields[0] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"minAge"] = [NSNumber numberWithInteger:number];
        }
    }
    text = [_ageFields[1] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"maxAge"] = [NSNumber numberWithInteger:number];
        }
    }
    
    text = [_heightFields[0] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"minHeight"] = [NSNumber numberWithInteger:number];
        }
    }
    text = [_heightFields[1] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"maxHeight"] = [NSNumber numberWithInteger:number];
        }
    }
    
    text = [_salaryFields[0] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"minSalary"] = [NSNumber numberWithInteger:number];
        }
    }
    text = [_salaryFields[1] text];
    if (![StringHelper isEmpty:text]) {
        NSInteger number = [text integerValue];
        if (number > 0) {
            data[@"maxSalary"] = [NSNumber numberWithInteger:number];
        }
    }
    
    return data;
}

- (IBAction)clearButtonPressed {
    NSArray *subviews = _container.subviews;
    for (UIView *view in subviews) {
        if ([view isKindOfClass:UITextField.class]) {
            UITextField *field = (UITextField *)view;
            field.text = @"";
        }
    }
    [self.view endEditing:YES];
    
}

- (IBAction)keyboardDownBtnClick:(UITextField *)sender {
    [sender resignFirstResponder];
}



- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

@end
