//
//  DialogHelper.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD.h>

@interface DialogHelper : NSObject

+ (void)showLoadingInView:(UIView *)view;
+ (void)showLoadingInView:(UIView *)view withText:(NSString *)text;
+ (void)dismissLoadingInView:(UIView *)view;


+ (void)showTipsInCenter:(UIView *)view withText:(NSString *)text;
+ (void)showTipsInBottom:(UIView *)view withText:(NSString *)text;
+ (void)showTipsWithImageInView:(UIView *)view withText:(NSString *)text;
+ (void)showErrorTipsInView:(UIView *)view withText:(NSString *)text;

@end
