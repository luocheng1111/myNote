//
//  ConversionHelper.h
//  BlindDate
//
//  Created by wangbiao on 16/3/28.
//  Copyright © 2016年 wangbiao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StringHelper : NSObject

+ (BOOL)isEmpty:(NSString *)string;

+ (NSString *)convertToString:(NSNumber *)number defaultValue:(NSString *)value;
+ (NSDictionary *)timeIntervalFromDateString:(NSString *)string;
+ (NSString *)compareCurrentTime:(NSString *)string;

@end
