//
//  ConversionHelper.m
//  BlindDate
//
//  Created by wangbiao on 16/3/28.
//  Copyright © 2016年 wangbiao. All rights reserved.
//

#import "StringHelper.h"
#import "UtilsMacro.h"

@implementation StringHelper

+ (BOOL)isEmpty:(NSString *)string{
    if([string isKindOfClass:NSNull.class]){
        return YES;
    }
    if(string==nil){
        return YES;
    }
    if(string.length<=0){
        return YES;
    }
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    NSString *result = [string stringByTrimmingCharactersInSet:set];
    if(result.length<=0){
        return YES;
    }
    return NO;
}

+ (NSString *)convertToString:(NSNumber *)number defaultValue:(NSString *)value {
    if (number != nil && [number intValue] > 0) {
        return [NSString stringWithFormat:@"%d", [number intValue]];
    } else {
        return value;
    }
}


+ (NSDictionary *)timeIntervalFromDateString:(NSString *)string {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSDate *date = [formatter dateFromString:string];
    
    NSCalendarUnit flags = (NSCalendarUnitYear | NSCalendarUnitMonth |
                            NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute);
    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *componentsPast = [calendar components:flags fromDate:date];
    NSDateComponents *componentsNow = [calendar components:flags fromDate:[NSDate date]];
    
    NSRange range = [calendar rangeOfUnit:NSCalendarUnitDay
                                   inUnit:NSCalendarUnitMonth forDate:date];
    NSInteger daysInLastMonth = range.length;
    NSInteger years = componentsNow.year - componentsPast.year;
    NSInteger months = componentsNow.month - componentsPast.month + years * 12;
    NSInteger days = componentsNow.day - componentsPast.day + months * daysInLastMonth;
    NSInteger hours = componentsNow.hour - componentsPast.hour + days * 24;
    NSInteger minutes = componentsNow.minute - componentsPast.minute + hours * 60;
    
    NSDictionary *result = @{kDateTypeYears: [NSNumber numberWithInteger:years],
                             kDateTypeMonths: [NSNumber numberWithInteger:months],
                             kDateTypeDays: [NSNumber numberWithInteger:days],
                             kDateTypeHours: [NSNumber numberWithInteger:hours],
                             kDateTypeMinutes: [NSNumber numberWithInteger:minutes]};
    
    return result;
}

+ (NSString *) compareCurrentTime:(NSString *)str{
//    //时间
//    NSString *createdTimeStr = @"2017-11-25 13:04:07";
//    NSLog(@"---%@", str);
    //把字符串转为NSdate
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *timeDate = [dateFormatter dateFromString:str];
    
    //得到与当前时间差
    NSTimeInterval  timeInterval = [timeDate timeIntervalSinceNow];
//    NSLog(@"1-%lf",timeInterval);
    timeInterval = -timeInterval;
//    NSLog(@"2-%lf",timeInterval);
    double temp = 0;
    NSString *result;
    if (timeInterval < 60) {
        result = [NSString stringWithFormat:@"刚刚"];
    }else if((temp = timeInterval/60) < 60){
        result = [NSString stringWithFormat:@"%d分钟前",(int)temp];
    }else if((temp = timeInterval/3600) > 1 && (temp = timeInterval/3600) <24){
        result = [NSString stringWithFormat:@"%d小时前",(int)temp];
    }else if ((temp = timeInterval/3600) > 24 && (temp = timeInterval/3600) < 48){
        result = [NSString stringWithFormat:@"昨天"];
    }else if ((temp = timeInterval/3600) > 48 && (temp = timeInterval/3600) < 72){
        result = [NSString stringWithFormat:@"前天"];
    }else{
        result = str;
    }
    
    return result;
}


    //计算文字的大小
+ (CGSize)getSizeWithString:(NSString *)str withSize:(CGSize)size withFont:(UIFont *)font{
        //    假设最大CGSize maxSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
        //计算文本的大小
        CGSize newSize = [str sizeWithFont:font constrainedToSize:size];
        return newSize;
}




@end
