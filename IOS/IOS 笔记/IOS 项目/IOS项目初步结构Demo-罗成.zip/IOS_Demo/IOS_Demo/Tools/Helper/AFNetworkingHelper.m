//
//  AFNetworkingHelper.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "AFNetworkingHelper.h"

static AFNetworkingHelper *_instance = nil;

@interface AFNetworkingHelper ()

@property (nonatomic,strong) AFHTTPSessionManager *manager;

@end

@implementation AFNetworkingHelper

+ (instancetype)defaultHelper{
    static dispatch_once_t token;
    
    dispatch_once(&token, ^{
        _instance = [[super allocWithZone:NULL] init];
        [_instance initialization];
    });
    return  _instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone{
    return [AFNetworkingHelper defaultHelper];
}

+ (id)copyWithZone:(struct _NSZone *)zone{
    return [AFNetworkingHelper defaultHelper];
}

- (void)initialization{
    self.manager = [AFHTTPSessionManager manager];
}

- (void)sendRequestWithURLString:(NSString *)urlString
                      parameters:(NSDictionary *)parameters
                         success:(void (^)(NSURLSessionDataTask *, id))success
                         failure:(void (^)(NSURLSessionDataTask *, NSError *))failure
                           cache:(BOOL)useCache{
    if(useCache == YES){
        _manager.requestSerializer.cachePolicy = NSURLRequestReturnCacheDataElseLoad;
    }else{
        _manager.requestSerializer.cachePolicy = NSURLRequestUseProtocolCachePolicy;
    }
    
    if(parameters !=nil){ //Post
        [_manager POST:urlString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            @try{
                success(task,responseObject);
            } @catch(NSException *exception){
                NSLog(@"[%@]throws exception:%@",NSStringFromSelector(_cmd), exception);
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            @try{
                success(task,error);
            } @catch(NSException *exception){
                NSLog(@"[%@]throws exception:%@",NSStringFromSelector(_cmd), exception);
            }
        }];
    }else{ //Get
        [_manager GET:urlString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            @try{
                success(task,responseObject);
            } @catch(NSException *exception){
                NSLog(@"[%@]throws exception:%@",NSStringFromSelector(_cmd), exception);
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            @try{
                success(task,error);
            } @catch(NSException *exception){
                NSLog(@"[%@]throws exception:%@",NSStringFromSelector(_cmd), exception);
            }
        }];
    }
}


- (void)sendRequestWithURLString:(NSString *)urlString
                      parameters:(NSDictionary *)parameters
                         success:(void (^)(NSURLSessionDataTask *, id))success
                         failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    [self sendRequestWithURLString:urlString parameters:parameters success:success failure:failure cache:NO];
}


- (void)sendRequestWithURLString:(NSString *)urlString
                         success:(void (^)(NSURLSessionDataTask *, id))success
                         failure:(void (^)(NSURLSessionDataTask *, NSError *))failure
                           cache:(BOOL)useCache{
    [self sendRequestWithURLString:urlString parameters:nil success:success failure:failure cache:useCache];
}


- (void)sendRequestWithURLString:(NSString *)urlString
                         success:(void (^)(NSURLSessionDataTask *, id))success
                         failure:(void (^)(NSURLSessionDataTask *, NSError *))failure{
    [self sendRequestWithURLString:urlString parameters:nil success:success failure:failure cache:NO];
}

- (void)uploadWithURLString:(NSString *)urlString
                       data:(NSData *)data
                    success:(void (^)(NSURLResponse *, id))success
                    failure:(void (^)(NSURLResponse *, NSError *))failure{
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    [request addValue:@"b21fbd...." forHTTPHeaderField:@"X-Bmob-App..."];
    [request addValue:@"8f397...." forHTTPHeaderField:@"X-Bmob-REST..."];
    [request addValue:@"image/jpeg" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:data];
    
    [_manager dataTaskWithRequest:request completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        @try{
            if(error == nil){
                success(response, responseObject);
            }else{
                failure(response, responseObject);
            }
        } @catch(NSException *exception){
            NSLog(@"throws exception %@", exception);
        }
    }];
}




@end
