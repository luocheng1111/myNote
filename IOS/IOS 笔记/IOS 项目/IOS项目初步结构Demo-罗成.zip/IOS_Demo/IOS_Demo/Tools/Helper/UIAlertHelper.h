//
//  UIAlertHelper.h
//  DriverHelper
//
//  Created by 罗小成 on 2017/11/14.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertHelper : NSObject

+ (void)showAlertView:(NSString *)message viewController:(UIViewController *)controller;

//+ showSheetView:(NSString *)message;

@end
