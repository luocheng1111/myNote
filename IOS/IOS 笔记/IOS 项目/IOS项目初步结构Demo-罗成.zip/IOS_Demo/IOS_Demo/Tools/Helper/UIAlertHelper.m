//
//  UIAlertHelper.m
//  DriverHelper
//
//  Created by 罗小成 on 2017/11/14.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "UIAlertHelper.h"

@implementation UIAlertHelper

+ (void)showAlertView:(NSString *)message viewController:(UIViewController *)controller{
    UIAlertController *alerController = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];

    [alerController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];

    [controller presentViewController:alerController animated:YES completion:nil];
}

//+ (void)showSheetView:(NSString *)message{
//
//}

@end
