//
//  DialogHelper.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "DialogHelper.h"

@implementation DialogHelper

+ (void)showLoadingInView:(UIView *)view{
    [self showLoadingInView:view withText:@""];
}


+ (void)showLoadingInView:(UIView *)view withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
//    hud.color = [UIColor whiteColor];
    if(text.length>0){
        hud.label.text = text;
    }
    hud.mode = MBProgressHUDModeIndeterminate;
//    [hud showAnimated:YES];
    
}


+ (void)dismissLoadingInView:(UIView *)view{
    [MBProgressHUD hideHUDForView:[self convertView:view] animated:YES];
}


+ (void)showTipsInCenter:(UIView *)view withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    
    hud.color = [UIColor blackColor];
    hud.mode = MBProgressHUDModeText;
    hud.label.textColor = [UIColor whiteColor];
    hud.label.text = text;
    //调整边框大小
    hud.margin = 10.f;
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (void)showTipsInBottom:(UIView *)view withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    
   hud.color = [UIColor blackColor];
    hud.mode = MBProgressHUDModeText;
    hud.label.textColor = [UIColor whiteColor];
    hud.label.text = text;
    //调整边框大小
    hud.margin = 10.f;
    //调整显示位置
    hud.yOffset = 150.f;
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (void)showTipsWithImageInView:(UIView *)view withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self convertView:view] animated:YES];
//    hud.color = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeCustomView;
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"info"]];
    hud.detailsLabel.font = [UIFont boldSystemFontOfSize:16];
    hud.detailsLabel.text = text;
    
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (void)showErrorTipsInView:(UIView *)view withText:(NSString *)text{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[self convertView:view] animated:YES];
    //    hud.color = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeCustomView;
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"error"]];
    hud.detailsLabel.font = [UIFont boldSystemFontOfSize:16];
    hud.detailsLabel.text = text;
    
    [hud hideAnimated:YES afterDelay:1.5];
}

+ (UIView *) convertView:(UIView *)view{
    UIWindow *window = [[[UIApplication sharedApplication] windows] lastObject];
    UIView *container = (view != nil? view :window);
    return container;
}

@end
