//
//  LoginViewController.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/8.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "LoginViewController.h"
#import "StringHelper.h"
#import "DialogHelper.h"
#import "UserInfo.h"
#import "UtilsMacro.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

+ (void)Go:(UIViewController *)viewController{
    LoginViewController *controller = [viewController.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [viewController.navigationController pushViewController:controller animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}



- (BOOL)verify{
    NSString *username = [_textFields[0] text];
    if([StringHelper isEmpty:username]){
        [DialogHelper showTipsInCenter:self.view withText:@"请输入用户名"];
        return NO;
    }
    
    NSString *password = [_textFields[1] text];
    if([StringHelper isEmpty:password]){
        [DialogHelper showTipsInCenter:self.view withText:@"请输入密码"];
        return NO;
    }
    
    return YES;
}


- (IBAction)loginClick:(id)sender{
    [self.view endEditing:YES];
    
    if([self verify]){
        [DialogHelper showLoadingInView:self.view withText:@"加载中..."];
        
        NSString *username = [_textFields[0] text];
        NSString *password = [_textFields[1] text];
//        NSDictionary *parameters = @{@"username":username, @"password":password};
        
//        BmobQuery *query = [BmobQuery queryWithClassName:DBTableName_UserInfo];
//        [query whereKey:@"username" equalTo:username];
//        [query whereKey:@"password" equalTo:password];
//
//        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
//            if (!error) {
//                if(array.count>0){
//                    [self loginSuccess:array];
//                }else{
//                    [DialogHelper dismissLoadingInView:self.view];
//                    [DialogHelper showTipsInCenter:self.view withText:@"用户名或密码错误"];
//                }
//            }else{
//                [DialogHelper dismissLoadingInView:self.view];
//                [self failureWithTask:error];
//            }
//        }];

    }
}


- (void)loginSuccess:(NSArray *)array{
    [DialogHelper dismissLoadingInView:self.view];
    [DialogHelper showTipsInBottom:self.view withText:@"登录成功"];
    
//    BmobObject *obj = array.lastObject;
//    [UserInfo setCurrentUser:[UserInfo toUserInfoByBmobObj:obj]];

    [self performSelector:@selector(goBack) withObject:nil afterDelay:0.3f];
}


- (void)failureWithTask:(NSError *)error{
    [DialogHelper showTipsInBottom:self.view withText:[[error userInfo] objectForKey:@"error"]];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    [self.view endEditing:YES];
}

- (IBAction)keyboardDownBtnClick:(UITextField *)field {
    NSInteger index = [self.textFields indexOfObject:field];
    if (index < _textFields.count - 1) {
        UITextField *nextField = _textFields[index + 1];
        [nextField becomeFirstResponder];
    } else {
        [field resignFirstResponder];
    }
}

@end
