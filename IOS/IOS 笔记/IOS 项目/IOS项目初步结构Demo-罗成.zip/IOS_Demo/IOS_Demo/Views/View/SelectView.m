//
//  SelectView.m
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/2.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "SelectView.h"

@implementation SelectView{
    UIButton *_carBtn;
}


- (instancetype)initWithFrame:(CGRect)frame andBtn:(UIButton *)btn{
    self = [super initWithFrame:frame];
    if(self){
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.7];
        _carBtn = btn;
        [self createBtn];
    }
    return self;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
    }];
}

- (void)createBtn{
    for (int i=0; i<4; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(self.frame.size.width/4*i+self.frame.size.width/4/2-30, self.frame.size.height-80, 60, 60);
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d.png", (i+1)]] forState:UIControlStateNormal];
        [btn setTag:(i+1)];
        [self addSubview:btn];
    }
}

- (void)btnClick:(UIButton *)btn{
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
    }];
    [_carBtn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%ld.png", btn.tag]] forState:UIControlStateNormal];
}

@end
