//
//  SelectView.h
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/2.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectView : UIView



- (instancetype)initWithFrame:(CGRect)frame andBtn:(UIButton *)btn;

@end
