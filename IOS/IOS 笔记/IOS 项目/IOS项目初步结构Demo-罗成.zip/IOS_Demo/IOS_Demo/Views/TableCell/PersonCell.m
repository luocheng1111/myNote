//
//  PersonCell.m
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/23.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "PersonCell.h"
#import "StringHelper.h"
#import <UIImageView+WebCache.h>

@implementation PersonCell

- (void)loadData:(UserInfo *)userInfo{
    
    //头像
    [_headImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.photo] placeholderImage:[UIImage imageNamed:@"personal_head"]];
    
    
    // 昵称
    _nameLabel.text = [StringHelper isEmpty:userInfo.nickname] ? userInfo.username : userInfo.nickname;
    
    // 性别
    NSString *sex = userInfo.sex;
    if ([sex isEqualToString:@"男"]) {
        _sexImageView.image = [UIImage imageNamed:@"man"];
    } else if ([sex isEqualToString:@"女"]) {
        _sexImageView.image = [UIImage imageNamed:@"woman"];
    } else {
        _sexImageView.image = [UIImage imageNamed:@"woman"];
    }
    
    // 年龄
    NSInteger age = [userInfo.age intValue];
    NSString *text = (age > 0 ? [NSString stringWithFormat:@"%ld岁", age] : @"-岁");
    _ageLabel.text = text;
    
    // 身高
    NSInteger height = [userInfo.height intValue];
    text = (height > 0 ? [NSString stringWithFormat:@"身高: %ld", height] : @"身高: -");
    _heightLabel.text = text;
    
    // 学历
    NSString *record = ![StringHelper isEmpty:userInfo.record] ? userInfo.record :@"-";
    _recordLabel.text = [NSString stringWithFormat:@"学历: %@", record];
    
    // 地址
    NSString *address = ![StringHelper isEmpty:userInfo.address] ? userInfo.address :@"-";
    _addressLabel.text = address;
    
    // 月薪
    NSInteger salary = [userInfo.salary intValue];
    text = (salary > 0 ? [NSString stringWithFormat:@"月薪: %ld元", salary] : @"月薪: -");
    _salaryLabel.text = text;
    
    // 自我介绍
    NSString *introduce = ![StringHelper isEmpty:userInfo.introduce] ? userInfo.introduce :@"-";
    _introduceLabel.text = introduce;
    
    // 时间
    _timeLabel.text = [StringHelper compareCurrentTime:userInfo.createdAt];
    
    
    // 打招呼
    UserInfo *currentUser = [UserInfo currentUser];
    if (currentUser == nil) {
        [_helloButton setTitle:@"打招呼" forState:UIControlStateNormal];
    } else {
        BOOL isMe = [userInfo.objectId isEqualToString:currentUser.objectId];
        if(isMe){
            [_helloButton setTitle:@"自己" forState:UIControlStateNormal];
        }else{
            if(![currentUser.helloIds containsObject:userInfo.objectId]){
                [_helloButton setTitle:@"打招呼" forState:UIControlStateNormal];
            }else{
                [_helloButton setTitle:@"已打招呼" forState:UIControlStateNormal];
            }
        }
    }

}


@end
