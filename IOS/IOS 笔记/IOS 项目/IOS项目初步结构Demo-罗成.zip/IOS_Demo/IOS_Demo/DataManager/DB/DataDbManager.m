//
//  DataDbManager.m
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/14.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "DataDbManager.h"
//#import "TestSelectModel.h"
//#import "SubTestSelectModel.h"

@implementation DataDbManager

static sqlite3 *db;

+ (DataDbManager *)shareDataDbManager{
    static DataDbManager *dataDbManager = nil;
    if(dataDbManager == nil){
        dataDbManager = [[DataDbManager alloc] init];
    }
    return dataDbManager;
}

- (NSString *)dbPath{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"sqlite"];
    return path;
}

- (sqlite3 *)openDB{
    if (db!=nil){
        return db;
    }
    
    int result = sqlite3_open([self dbPath].UTF8String, &db);
    if(result==SQLITE_OK){
//                NSLog(@"打开数据库成功!");
    }else{
        NSLog(@"打开数据库失败!");
    }

    return db;
}

- (void)closeDB{
    int result = sqlite3_close(db);
    if(result==SQLITE_OK){
        db = nil;
        //        NSLog(@"关闭数据库成功!");
    }else{
        NSLog(@"关闭数据库失败!");
    }
    
}




//查询所有信息
- (NSArray *)queryAllData:(DataType)type{

    db = [self openDB];
    
    NSMutableArray *array = [NSMutableArray array];
    sqlite3_stmt *stmt = nil;
    
//    switch (type) {
//        case Chapter:{
//            NSString *sql = [NSString stringWithFormat:@"select pid,pname,pcount FROM firstlevel"];
//            int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, NULL);
//            if(result == SQLITE_OK){
//                while(sqlite3_step(stmt) ==  SQLITE_ROW){
//                    TestSelectModel *testSelectModel = [TestSelectModel new];
//                    testSelectModel.pid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 0)];
//                    testSelectModel.pname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 1)];
//                    testSelectModel.pcount = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 2)];
//
//                    [array addObject:testSelectModel];
//                }
//                }else{
//                NSLog(@"查询语句错误!");
//                }
//            }
//            break;
//        case Answer:{
//            NSString *sql = [NSString stringWithFormat:@"select mquestion,mdesc,mid,manswer,mimage,pid,pname,sid,sname,mtype FROM leaflevel"];
//            int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, NULL);
//            if(result == SQLITE_OK){
//                while(sqlite3_step(stmt) ==  SQLITE_ROW){
//                    AnswerModel *answerModel = [AnswerModel new];
//                    answerModel.mquestion = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 0)];
//                    answerModel.mdesc = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 1)];
//                    answerModel.mid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 2)];
//                    answerModel.manswer = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 3)];
//                    answerModel.mimage = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 4)];
//                    answerModel.pid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 5)];
//                    answerModel.pname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 6)];
//                    answerModel.sid = [NSString stringWithFormat:@"%.2f", sqlite3_column_double(stmt, 7)];
//                    answerModel.sname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 8)];
//                    answerModel.mtype = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 9)];
//                    [array addObject:answerModel];
//                }
//            }else{
//                NSLog(@"查询语句错误!");
//            }
//        }
//            break;
//        case SubChapter:{
//            NSString *sql = [NSString stringWithFormat:@"select pid,sname,scount,sid,serial FROM secondlevel"];
//            int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, NULL);
//            if(result == SQLITE_OK){
//                while(sqlite3_step(stmt) ==  SQLITE_ROW){
//                    SubTestSelectModel *subTestSelectModel = [SubTestSelectModel new];
//                    subTestSelectModel.pid = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 0)];
//                    subTestSelectModel.sname = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 1)];
//                    subTestSelectModel.scount = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 2)];
//                    subTestSelectModel.sid = [NSString stringWithFormat:@"%.2f", sqlite3_column_double(stmt, 3)];
//                    subTestSelectModel.serial = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 4)];
//                    [array addObject:subTestSelectModel];
//                }
//            }else{
//                NSLog(@"查询语句错误!");
//            }
//        }
//            break;
//        default:
//            break;
//    }

    sqlite3_finalize(stmt);
    [self closeDB];
    
    return array;

}



@end
