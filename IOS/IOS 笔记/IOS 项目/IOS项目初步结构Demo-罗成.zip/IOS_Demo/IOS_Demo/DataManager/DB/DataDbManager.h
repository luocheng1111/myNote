//
//  DataDbManager.h
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/14.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "sqlite3.h"

typedef enum{
    Chapter,//章节练习数据
    Answer,//答题数据
    SubChapter,//专项
}DataType;

@interface DataDbManager : NSObject

+ (DataDbManager *) shareDataDbManager;

//数据库路径
- (NSString *)dbPath;

//打开数据库
- (sqlite3 *)openDB;

//关闭数据库
- (void)closeDB;

//查询所有信息
- (NSArray *)queryAllData:(DataType)type;
//- (void)deleteStudentWithStudentNum:(NSInteger)studentNum;
@end
