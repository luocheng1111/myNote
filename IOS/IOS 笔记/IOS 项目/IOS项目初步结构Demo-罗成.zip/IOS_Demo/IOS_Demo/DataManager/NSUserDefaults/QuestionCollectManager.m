//
//  QuestionCollectManager.m
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import "QuestionCollectManager.h"

@implementation QuestionCollectManager

+(NSArray *) getWrongQuestion{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"WRONG_QUESTION"];
    if(array!=nil){
        return array;
    }else{
        return @[];
    }
}


+(void) addWrongQuestion:(int)mid{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"WRONG_QUESTION"];
    NSMutableArray *muArr = [[NSMutableArray alloc] initWithArray:array];
    [muArr addObject:[NSString stringWithFormat:@"%d",mid]];
    [[NSUserDefaults standardUserDefaults] setObject:muArr forKey:@"WRONG_QUESTION"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


+(void) removeWrongQuestion:(int)mid{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"WRONG_QUESTION"];
    NSMutableArray *muArr = [[NSMutableArray alloc] initWithArray:array];
    for (int i=(int)array.count-1; i>=0; i--) {
        if([muArr[i] intValue]==mid){
            [muArr removeObjectAtIndex:i];
        }
    }
    [[NSUserDefaults standardUserDefaults] setObject:muArr forKey:@"WRONG_QUESTION"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


+(NSArray *) getCollectionQuestion{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"COLLECTION_QUESTION"];
    if(array!=nil){
        return array;
    }else{
        return @[];
    }
}


+(void) addCollectionQuestion:(int)mid{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"COLLECTION_QUESTION"];
    NSMutableArray *muArr = [[NSMutableArray alloc] initWithArray:array];
    [muArr addObject:[NSString stringWithFormat:@"%d",mid]];
    [[NSUserDefaults standardUserDefaults] setObject:muArr forKey:@"COLLECTION_QUESTION"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


+(void) removeCollectionQuestion:(int)mid{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"COLLECTION_QUESTION"];
    NSMutableArray *muArr = [[NSMutableArray alloc] initWithArray:array];
    for (int i=(int)array.count-1; i>=0; i--) {
        if([muArr[i] intValue]==mid){
            [muArr removeObjectAtIndex:i];
        }
    }
    [[NSUserDefaults standardUserDefaults] setObject:muArr forKey:@"COLLECTION_QUESTION"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



+(NSArray *) getSorce{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"MY_SORCE"];
    if(array!=nil){
        return array;
    }else{
        return @[];
    }
}


+(void) setSorce:(int)sorce{
    NSArray *array = [[NSUserDefaults standardUserDefaults] objectForKey:@"MY_SORCE"];
    NSMutableArray *muArr = [[NSMutableArray alloc] initWithArray:array];
    [muArr addObject:[self getNowTime]];
    NSLog(@"%@",[self getNowTime]);
    [muArr addObject:[NSString stringWithFormat:@"%d",sorce]];
    [[NSUserDefaults standardUserDefaults] setObject:muArr forKey:@"MY_SORCE"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(NSString *)getNowTime{
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [NSDateFormatter new];
    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss"];
    return [formatter stringFromDate:date];
}

@end
