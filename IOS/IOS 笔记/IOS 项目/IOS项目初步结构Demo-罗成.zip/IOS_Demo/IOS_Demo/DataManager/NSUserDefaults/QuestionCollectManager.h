//
//  QuestionCollectManager.h
//  StudyDrive
//
//  Created by 罗小成 on 2017/10/24.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QuestionCollectManager : NSObject

+(NSArray *) getWrongQuestion;
+(void) addWrongQuestion:(int)mid;
+(void) removeWrongQuestion:(int)mid;

+(NSArray *) getCollectionQuestion;
+(void) addCollectionQuestion:(int)mid;
+(void) removeCollectionQuestion:(int)mid;

+(NSArray *) getSorce;
+(void) setSorce:(int)sorce;

@end
