//
//  UtilsMacro.h
//  XiangQinJiao
//
//  Created by 罗小成 on 2017/11/9.
//  Copyright © 2017年 罗小成. All rights reserved.
//

#ifndef UtilsMacro_h
#define UtilsMacro_h

#define DBTableName_UserInfo @"UserInfo"

#define kNotificationTypeCurrentUserChange @"CurrentUserChange"
#define kNotificationTypeRemoveCurrentUser @"RemoveCurrentUser"
#define kNotificationTypeListDataChange @"ListDataChange"

// 日期键值
#define kDateTypeYears @"years"
#define kDateTypeMonths @"months"
#define kDateTypeDays @"days"
#define kDateTypeHours @"hours"
#define kDateTypeMinutes @"minutes"

#endif /* UtilsMacro_h */
