//
//  UserInfo.h
//  BlindDate
//
//  Created by wangbiao on 16/3/28.
//  Copyright © 2016年 wangbiao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfo : NSObject<NSCoding>

@property (nonatomic, strong) NSString *objectId;

@property (nonatomic, strong) NSString *photo;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSString *nickname;
@property (nonatomic, strong) NSString *sex;
@property (nonatomic, strong) NSString *record;

@property (nonatomic, strong) NSString *salary;
@property (nonatomic, strong) NSString *age;
@property (nonatomic, strong) NSString *height;

@property (nonatomic, strong) NSString *marital;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *contact;
@property (nonatomic, strong) NSString *introduce;
@property (nonatomic, strong) NSMutableArray *helloIds;

@property (nonatomic, strong) NSString *createdAt;

+ (instancetype)currentUser;
+ (void)setCurrentUser:(UserInfo *)userInfo;
+ (void)removeCurrentUser;

+ (NSDictionary *)toDictionaryWithOutUserName:(UserInfo *)userInfo;


@end
