//
//  UserInfo.m
//  BlindDate
//
//  Created by wangbiao on 16/3/28.
//  Copyright © 2016年 wangbiao. All rights reserved.
//

#import "UserInfo.h"
#import "StringHelper.h"
#import "UtilsMacro.h"

@implementation UserInfo

- (void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeObject:_objectId forKey:@"objectId"];
    [coder encodeObject:_photo forKey:@"photo"];
    [coder encodeObject:_username forKey:@"username"];
    [coder encodeObject:_nickname forKey:@"nickname"];
    [coder encodeObject:_helloIds forKey:@"helloIds"];
    [coder encodeObject:_sex forKey:@"sex"];
    [coder encodeObject:_record forKey:@"record"];
    [coder encodeObject:_salary forKey:@"salary"];
    [coder encodeObject:_age forKey:@"age"];
    [coder encodeObject:_height forKey:@"height"];
    [coder encodeObject:_marital forKey:@"marital"];
    [coder encodeObject:_address forKey:@"address"];
    [coder encodeObject:_contact forKey:@"contact"];
    [coder encodeObject:_introduce forKey:@"introduce"];
    [coder encodeObject:_createdAt forKey:@"createdAt"];
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    if (self = [super init]) {
        _objectId = [coder decodeObjectForKey:@"objectId"];
        _photo = [coder decodeObjectForKey:@"photo"];
        _username = [coder decodeObjectForKey:@"username"];
        _nickname = [coder decodeObjectForKey:@"nickname"];
        _helloIds = [coder decodeObjectForKey:@"helloIds"];
        _sex = [coder decodeObjectForKey:@"sex"];
        _record = [coder decodeObjectForKey:@"record"];
        _salary = [coder decodeObjectForKey:@"salary"];
        _age = [coder decodeObjectForKey:@"age"];
        _height = [coder decodeObjectForKey:@"height"];
        _marital = [coder decodeObjectForKey:@"marital"];
        _address = [coder decodeObjectForKey:@"address"];
        _contact = [coder decodeObjectForKey:@"contact"];
        _introduce = [coder decodeObjectForKey:@"introduce"];
        _createdAt = [coder decodeObjectForKey:@"createdAt"];
    }
    
    return self;
}

+ (NSDictionary *)toDictionaryWithOutUserName:(UserInfo *)userInfo {
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    if(userInfo.objectId!=nil){
        [dic setObject:userInfo.objectId forKey:@"objectId"];
    }
    if(userInfo.photo!=nil){
        [dic setObject:userInfo.photo forKey:@"photo"];
    }
    if(userInfo.nickname!=nil){
        [dic setObject:userInfo.nickname forKey:@"nickname"];
    }
    if(userInfo.helloIds!=nil){
        [dic setObject:userInfo.helloIds forKey:@"helloIds"];
    }
    if(userInfo.sex!=nil){
        [dic setObject:userInfo.sex forKey:@"sex"];
    }
    if(userInfo.record!=nil){
        [dic setObject:userInfo.record forKey:@"record"];
    }
    if(userInfo.salary!=nil){
        [dic setObject:@([userInfo.salary intValue]) forKey:@"salary"];
    }
    if(userInfo.age!=nil){
        [dic setObject:@([userInfo.age intValue]) forKey:@"age"];
    }
    if(userInfo.height!=nil){
        [dic setObject:@([userInfo.height intValue]) forKey:@"height"];
    }
    if(userInfo.marital!=nil){
        [dic setObject:userInfo.marital forKey:@"marital"];
    }
    if(userInfo.address!=nil){
        [dic setObject:userInfo.address forKey:@"address"];
    }
    if(userInfo.contact!=nil){
        [dic setObject:userInfo.contact forKey:@"contact"];
    }
    if(userInfo.introduce!=nil){
        [dic setObject:userInfo.introduce forKey:@"introduce"];
    }
//    if(userInfo.createdAt!=nil){
//        [dic setObject:userInfo.createdAt forKey:@"createdAt"];
//    }
    NSLog(@"%@",dic);
    return dic;
}


+ (instancetype)currentUser{
    UserInfo *userInfo = [NSKeyedUnarchiver unarchiveObjectWithFile:[self filePath]];
    return userInfo;
}


+ (void)setCurrentUser:(UserInfo *)userInfo{
    [NSKeyedArchiver archiveRootObject:userInfo toFile:[self filePath]];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center postNotificationName:kNotificationTypeCurrentUserChange object:nil];
}


+ (void)removeCurrentUser{
    NSFileManager *manager = [NSFileManager defaultManager];
    [manager removeItemAtPath:[self filePath] error:nil];
}


+ (NSString *)filePath{
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *filePath = [documentPath stringByAppendingPathComponent:@"userinfo.archiver"];
    return filePath;
}


@end
