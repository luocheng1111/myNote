//
//  ViewController.swift
//  ThirdPro
//
//  Created by wangyu on 16/3/24.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var nsSelector: UIPickerView!
    
    let name = ["范冰冰", "李冰冰", "王菲", "杨幂"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nsSelector.dataSource = self
        nsSelector.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // returns the number of 'columns' to display.
    @available(iOS 2.0, *)
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int{
        return 1
    }
    
    // returns the # of rows in each component..
    @available(iOS 2.0, *)
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
         return name.count
    }
    
    @available(iOS 2.0, *)
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return name[row]
    }
	
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "GotoGallery"){
            let index = nsSelector.selectedRowInComponent(0)
            print(index)
            
            let imageName : String?
            switch index {
            case 0:
                imageName = "fanbingbing"
            case 1:
                imageName = "libingbing"
            case 2:
                imageName = "wangfei"
            case 3:
                imageName = "yangmi"
            default:
                imageName = nil
            }
            
            let vc = segue.destinationViewController as! SecondController
            vc.nameText = name[index]
            vc.imageName = imageName
            
        }
    }
    
    
    @IBAction func close(segue: UIStoryboardSegue){
        print("second close")
    }
 
    
    


}

