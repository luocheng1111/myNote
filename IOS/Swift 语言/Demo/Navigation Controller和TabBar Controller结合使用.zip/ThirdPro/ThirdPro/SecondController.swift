//
//  ViewController.swift
//  ThirdPro
//
//  Created by wangyu on 16/3/24.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit
import Social

class SecondController: UIViewController {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    
    var nameText: String?
    var imageName: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let imageName = imageName{
            image.image = UIImage(named: imageName)
            navigationItem.title = nameText!
        }
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
    @IBAction func shard(sender: UIBarButtonItem) {
        let share:SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        share.setInitialText("分享测试")
        share.addImage(image.image)
        self.presentViewController(share, animated: true, completion: nil)
    }
    
}

