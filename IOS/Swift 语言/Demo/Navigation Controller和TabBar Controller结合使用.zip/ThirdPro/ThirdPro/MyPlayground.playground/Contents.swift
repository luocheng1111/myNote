//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

var point = (200, "OK")
point.0
point.1

var (x, y) = point
x
y

let point2 = (x:3, y:2)
point2.x
point2.y
point2.0
point2.1

let point3:(x:Int, y:Int) = (4,5)
point3.x
point3.y

