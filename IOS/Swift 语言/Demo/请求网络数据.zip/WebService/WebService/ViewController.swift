//
//  ViewController.swift
//  WebService
//
//  Created by wangyu on 16/4/7.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class ViewController: UIViewController, NSURLConnectionDataDelegate {
    
    @IBOutlet weak var label: UILabel!

    var responseData:NSMutableData = NSMutableData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Post_异步()
        label.text = "111"
        print("请求Next")
    }
    
  
    
    func Get_同步(){
        //创建NSURL对象
        let url:NSURL! = NSURL(string: "http://www.weather.com.cn/data/cityinfo/101010100.html")
        //创建请求对象
        let urlRequest = NSURLRequest(URL: url)
        //响应对象
        var response:NSURLResponse?
        do{
            //发送请求
            let data:NSData = try NSURLConnection.sendSynchronousRequest(urlRequest, returningResponse: &response)
            print(data)
            let str = NSString(data: data, encoding: NSUTF8StringEncoding)
            print(str)
        } catch let error as NSError{
            print(error.code)
            print(error.description)
        }
    }
    
    
    func Get_异步(){
        let url:NSURL! = NSURL(string: "http://www.1052.com")
        let urlRequest = NSURLRequest(URL: url)
        let connection = NSURLConnection(request: urlRequest, delegate: self)
        connection?.start()
        print(connection)
    }
    
    
    //
    func connection(connection: NSURLConnection, didReceiveResponse response: NSURLResponse){
        
        responseData.length = 0
        
        print("请求成功")
        print(response)
    }
    
    //Get_异步 请求成功建立连接后，开始接收数据，如果数据量很多，它会被调用多次
    func connection(connection: NSURLConnection, didReceiveData data: NSData){
        responseData.appendData(data)

        
        
    }
    
    //Get_异步 成功完成数据加载，在connection:didReceiveData方法之后执行
    func connectionDidFinishLoading(connection: NSURLConnection){
        label.text = "222"
        print("请求完成")
        
        var responseString:NSString! = NSString(data: responseData, encoding: NSUTF8StringEncoding)
        
        var startPos = responseString.rangeOfString("{").location
        responseString = responseString.substringFromIndex(startPos)
        var endPos = responseString.rangeOfString("</GetCollectintDateByStringResult>").location
        responseString = responseString.substringToIndex(endPos)
        
        print(responseString)
        
        //解析数据
        let json =  try! NSJSONSerialization.JSONObjectWithData(responseString.dataUsingEncoding(NSUTF8StringEncoding)!, options: NSJSONReadingOptions.AllowFragments)
        let collectionDatas = json.objectForKey("CollectionDatas") as! NSArray
        print(collectionDatas.count)
        for json in collectionDatas{
            print(json.objectForKey("DateTime") as! NSString)
            let sensorDatas  = json.objectForKey("SensorDatas") as! NSArray
            for json2 in sensorDatas{
                print(json2.objectForKey("value"))
            }
        }
        
    }
    
    func Post_同步(){
        let url:NSURL! = NSURL(string: "http://210.5.155.249:81/PaddyForLD/MyService.asmx")
        var urlRequest:NSMutableURLRequest = NSMutableURLRequest(URL: url)
        urlRequest.HTTPMethod = "POST"
        
        let body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body><GetCollectintDateByString xmlns=\"http://tempuri.org/\"><c>{\"CollectionID\":\"670A5BD9-7D93-41C0-96B5-1007F23A4136\",\"StartTime\":\"2016-04-05\",\"EndTime\":\"2016-04-06\",\"DataNum\":1000}</c></GetCollectintDateByString></soap12:Body></soap12:Envelope>"
        let postData = body.dataUsingEncoding(NSASCIIStringEncoding)
        urlRequest.HTTPBody = postData
        let header:Dictionary<String, String> = ["Content-Type":"text/xml; charset=utf-8"]
        urlRequest.allHTTPHeaderFields = header
        //响应对象
        var response:NSURLResponse?
        
        do{
            let data = try NSURLConnection.sendSynchronousRequest(urlRequest, returningResponse: &response)
            let str = NSString(data: data, encoding: NSUTF8StringEncoding)
            print(str)
            
        } catch let error as NSError{
            print(error.code)
            print(error.description)
        }
    }
    
    func Post_异步()  {
        let url = NSURL(string: "http://210.5.155.249:81/PaddyForLD/MyService.asmx")
        var request = NSMutableURLRequest(URL: url!);
        request.HTTPMethod = "POST"
        let body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body><GetCollectintDateByString xmlns=\"http://tempuri.org/\"><c>{\"CollectionID\":\"670A5BD9-7D93-41C0-96B5-1007F23A4136\",\"StartTime\":\"2016-04-05\",\"EndTime\":\"2016-04-06                                                                                                     \",\"DataNum\":1000}</c></GetCollectintDateByString></soap12:Body></soap12:Envelope>"
        
        
        
        let postData = body.dataUsingEncoding(NSASCIIStringEncoding)
        request.HTTPBody = postData
        
        let header:Dictionary<String, String> = ["Content-Type":"text/xml; charset=utf-8"]
        request.allHTTPHeaderFields = header
        
        let conn = NSURLConnection(request: request, delegate: self)
        conn?.start()
    }
    
    
    
    
    func requestWebService_Get2_同步(){
        //创建NSURL对象
        let url = NSURL(string:"http://www.weather.com.cn/data/cityinfo/101010100.html")!
        //创建请求对象
        let request = NSURLRequest(URL: url)
        let session = NSURLSession.sharedSession()
        
        let semaphore = dispatch_semaphore_create(0)
        print("0000")
        let dataTask = session.dataTaskWithRequest(request,
                                                   completionHandler: {(data, response, error) -> Void in
                                                    if error != nil{
                                                        print(error?.code)
                                                        print(error?.description)
                                                    }else{
                                                        let str = NSString(data: data!, encoding: NSUTF8StringEncoding)
                                                        print(str)
                                                        self.label.text = "2222"
                                                        print("1111")
                                                    }
                                                    
                                                           (semaphore)
        }) as NSURLSessionTask
        
        print("222")
        //使用resume方法启动任务
        dataTask.resume()
        print("3333")
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER)
        print("数据加载完毕！")
    
    }
    

    
    func requestWebService_Post(){
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://210.5.155.249:81/PaddyForHLJ/MyService.asmx")!)
        
        request.HTTPMethod = "POST"
        let postString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body><GetALLSensorKindToString xmlns=\"http://tempuri.org/\"><c1>string</c1></GetALLSensorKindToString></soap12:Body></soap12:Envelope>"
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        let dir:Dictionary<String, String> = ["Content-Type":"text/xml; charset=utf-8"]
        
        
        request.allHTTPHeaderFields = dir
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString!)")
            
        }
        task.resume()

        
        
//        let url = NSURL(string: "http://210.5.155.249:81/PaddyForHLJ/MyService.asmx")!
//        
//        let datt = NSString(string: "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"><soap12:Body><GetALLSensorKindToString xmlns=\"http://tempuri.org/\"><c1>string</c1></GetALLSensorKindToString></soap12:Body></soap12:Envelope>")
//        let aaa = datt.dataUsingEncoding(NSUTF8StringEncoding)
//        
//        //创建请求对象
//        let urlRequest = NSMutableURLRequest(URL: url)
//        urlRequest.HTTPMethod = "POST"
//        urlRequest.HTTPBody = aaa
//        let result:NSURLConnection! = NSURLConnection(request: urlRequest, delegate: self)
//        print(result)
    }
    
    
    

    
    
    
    


    

   



}

