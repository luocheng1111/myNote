//
//  AppDelegate.swift
//  jpushtest
//
//  Created by wangyu on 16/5/9.
//  Copyright © 2016年 shagri. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        
        
        print("000")
        //        self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
        //        self.window.backgroundColor = [UIColor whiteColor];
        //        [self.window makeKeyAndVisible];
        
//        self.window = UIWindow(frame: UIScreen.mainScreen().bounds)
//        self.window?.backgroundColor = UIColor.whiteColor();
//        self.window?.makeKeyAndVisible();
        

        

//        NSString *advertisingId = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
        
        //Required
        if (UIDevice.currentDevice().systemVersion.compare("8.0.0") == .OrderedSame || UIDevice.currentDevice().systemVersion.compare("8.0.0") == .OrderedDescending){
            print("1111")
            JPUSHService.registerForRemoteNotificationTypes(1, categories: nil)
        }else{
            print("2222")
            JPUSHService.registerForRemoteNotificationTypes(1, categories: nil)
        }
//        if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
//            //可以添加自定义categories
//            [JPUSHService registerForRemoteNotificationTypes:(UIUserNotificationTypeBadge |
//                UIUserNotificationTypeSound |
//                UIUserNotificationTypeAlert)
//                categories:nil];
//        } else {
//            //categories 必须为nil
//            [JPUSHService registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge |
//                UIRemoteNotificationTypeSound |
//                UIRemoteNotificationTypeAlert)
//                categories:nil];
//        }
        
        
       
        
        //Required
        //如需兼容旧版本的方式，请依旧使用[JPUSHService setupWithOption:launchOptions]方式初始化和同时使用pushConfig.plist文件声明appKey等配置内容。
//        [JPUSHService setupWithOption:launchOptions appKey:appKey
//            channel:channel
//            apsForProduction:isProduction
//            advertisingIdentifier:advertisingId];
        print("44444")
        JPUSHService.setupWithOption(launchOptions, appKey: "849b623969ca34723c0638cf", channel: "App Store", apsForProduction: true, advertisingIdentifier: nil)
        var defaultCenter:NSNotificationCenter = NSNotificationCenter.defaultCenter();
        defaultCenter.addObserver(self, selector: "networkDidReceiveMessage:", name: kJPFNetworkDidReceiveMessageNotification, object: nil)
        return true
    }
    
    func networkDidReceiveMessage(notification:NSNotification){
        print(notification)
    }
    
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData){
        print("555")
        JPUSHService.registerDeviceToken(deviceToken)
    }

    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]){
        print("6666")
        print(userInfo)
        JPUSHService.handleRemoteNotification(userInfo)
    }
    
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject], fetchCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void){
        print("777")
        JPUSHService.handleRemoteNotification(userInfo);
        completionHandler(UIBackgroundFetchResult.NewData)
    }
    
    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError){
        print("error")
    }
    
    
    
  

}

