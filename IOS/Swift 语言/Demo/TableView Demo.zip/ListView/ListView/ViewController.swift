//
//  ViewController.swift
//  ListView
//
//  Created by wangyu on 16/3/30.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

var todos: [TodoModel] = []
var filteredTodos: [TodoModel] = []

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchDisplayDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let todoModel1:TodoModel = TodoModel(id:"1", image: "child-selected", title: "1. 去游乐场", date: dateFormString("2014-11-02")!)
        let todoModel2:TodoModel = TodoModel(id:"2", image: "shopping-cart-selected", title: "2. 购物", date: dateFormString("2014-10-28")!)
        let todoModel3:TodoModel = TodoModel(id:"3", image: "phone-selected", title: "3. 打电话", date: dateFormString("2014-10-30")!)
        let todoModel4:TodoModel = TodoModel(id:"4", image: "travel-selected", title: "4. Travel to Europe", date: dateFormString("2014-10-31")!)
        
        todos.append(todoModel1)
        todos.append(todoModel2)
        todos.append(todoModel3)
        todos.append(todoModel4)
        
        navigationItem.leftBarButtonItem = editButtonItem()
        
        //开始时，隐藏searchbar
        var contentOffset = tableView.contentOffset
        contentOffset.y += (searchDisplayController?.searchBar.frame.size.height)!
        tableView.contentOffset = contentOffset
    }
    
    
    func dateFormString(dateStr:String) -> NSDate? {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.dateFromString(dateStr)
        return date
    }
    
    
    //tableView的总数
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if tableView == searchDisplayController?.searchResultsTableView{
            return filteredTodos.count
        }else{
            return todos.count
        }
        
    }

    //设置TableViewCell内容
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        //根据Identifer获得TableViewCell
        let cell = self.tableView.dequeueReusableCellWithIdentifier("todoCell")! as UITableViewCell
        
        let todo:TodoModel
        
        if tableView == searchDisplayController?.searchResultsTableView{
            todo = filteredTodos[indexPath.row] as TodoModel
        }else{
            todo = todos[indexPath.row] as TodoModel
        }
        
        //这里通过tag获取控件，也可以自定义方式获取控件
        let image = cell.viewWithTag(100) as! UIImageView
        let text = cell.viewWithTag(101) as! UILabel
        let date = cell.viewWithTag(102) as! UILabel
        
        image.image = UIImage(named: todo.image)
        text.text = todo.title
        
        //根据选择国家不同，现实时间的样式不同，现实样式和国家习惯相匹配
        let locale = NSLocale.currentLocale()
        let dateFormat = NSDateFormatter.dateFormatFromTemplate("yyyy-MM-dd", options: 0, locale: locale)
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = dateFormat
        date.text = dateFormatter.stringFromDate(todo.date)
        
        return cell
    }
    
    //设置TabelViewCell的高，这个值和storyboard匹配
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    //tableView 删除及处理
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath){
        //这里可能为删除，可能为添加，可能为其他
        if editingStyle == UITableViewCellEditingStyle.Delete{
            todos.removeAtIndex(indexPath.row)
            self.tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
            self.tableView.reloadData()
        }
    }
    
    
 	override func setEditing(editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        self.tableView.setEditing(editing, animated: animated)
    }
    
    
    //编辑模式下，可否拖动表视图 true 可以 false 不可以
    func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool{
        return true
    }
    
    //拖动后都处理
    func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath){
        //下面写不写都不影响结果，不知原因
        let todo = todos.removeAtIndex(sourceIndexPath.row);
        todos.insert(todo, atIndex: destinationIndexPath.row)
        self.tableView.reloadData()

    }
    
   
    //searchBar 搜索处理
    func searchDisplayController(controller: UISearchDisplayController, shouldReloadTableForSearchString searchString: String?) -> Bool{
        
        filteredTodos = todos.filter(){
            $0.title.rangeOfString(searchString!) != nil
        }
        
        return true
    }
    
    
    @IBAction func close(segue:UIStoryboardSegue){
        self.tableView.reloadData()
    }
    
    //跳转
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "EditTodo" {
            let vc = segue.destinationViewController as! DetailViewController
            let indexPath = tableView.indexPathForSelectedRow
            if let index = indexPath{
                vc.todo = todos[index.row]
            }
        }
    }
    
}

