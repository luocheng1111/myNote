//
//  DetailViewController.swift
//  ListView
//
//  Created by wangyu on 16/3/30.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var childBtn: UIButton!
    @IBOutlet weak var phoneBtn: UIButton!
    @IBOutlet weak var shoppingBtn: UIButton!
    @IBOutlet weak var traveBtn: UIButton!
    @IBOutlet weak var todoItem: UITextField!
    @IBOutlet weak var todoDate: UIDatePicker!

    var todo: TodoModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let todo = todo{
            navigationController?.title = "修改Todo"
            
            switch todo.image{
            case "child-selected":
                childBtn.selected = true
            case "phone-selected":
                phoneBtn.selected = true
            case "shopping-cart-selected":
                shoppingBtn.selected = true
            case "travel-selected":
                traveBtn.selected = true
            default:
                break;
            }
            todoItem.text = todo.title
            todoDate.setDate(todo.date, animated: false)

        }else{
            navigationController?.title = "新增Todo"
            childBtn.selected = true

        }
    }

    func resetBtn(){
        childBtn.selected = false
        phoneBtn.selected = false
        shoppingBtn.selected = false
        traveBtn.selected = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func childTapped(sender: AnyObject) {
        resetBtn()
        childBtn.selected = true
    }
    
    @IBAction func phoneTapped(sender: AnyObject) {
        resetBtn()
        phoneBtn.selected = true
    }
    
   
    @IBAction func shoppingTapped(sender: AnyObject) {
        resetBtn()
        shoppingBtn.selected = true
    }
  
    
    @IBAction func traveTapped(sender: AnyObject) {
        resetBtn()
        traveBtn.selected = true
    }
    
    @IBAction func okTapped(sender: AnyObject) {
        var image = ""
        if childBtn.selected{
            image = "child-selected"
        }else if phoneBtn.selected{
            image = "shopping-cart-selected"
        }else if shoppingBtn.selected{
            image = "phone-selected"
        }else if traveBtn.selected{
            image = "travel-selected"
        }
        
        
        if todo == nil{
            let uuid = NSUUID().UUIDString
            todo = TodoModel(id: uuid, image: image, title: todoItem.text!, date: todoDate.date)
            todos.append(todo!)
        }else{
            todo?.image = image
            todo?.title = todoItem.text!
            todo?.date = todoDate.date
        }
        
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        todoItem.resignFirstResponder()
    }
}
