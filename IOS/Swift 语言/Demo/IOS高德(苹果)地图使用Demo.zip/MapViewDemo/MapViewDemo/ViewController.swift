//
//  ViewController.swift
//  MapViewDemo
//
//  Created by wangyu on 16/6/2.
//  Copyright © 2016年 shagri. All rights reserved.
// 可借鉴：http://www.hangge.com/blog/cache/detail_787.html

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var queryLocation: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* 地图类型
           MKMapType.Standard  标准地图类型 默认为此
           MKMapType.Satellite 卫星地图类型 在此类型中没有街道名称等信息
           MKMapType.Hybrid    混合地图类型 此类型数载卫星地图上标街道等信息
         */
        mapView.mapType = MKMapType.Standard
        mapView.delegate = self
    }

    func mapViewDidFailLoadingMap(mapView: MKMapView, withError error: NSError){
        print("地图加载失败")
        print("失败原因："+error.description)
    }
    
    @IBAction func query(sender: AnyObject) {
        
        if queryLocation.text == nil{
            return
        }
        
        var geocoder = CLGeocoder()
        geocoder.geocodeAddressString(queryLocation.text!)
        { (placemarks, error) in
            
            if placemarks?.count > 0{
                print("查询记录数:\(placemarks?.count)")
                self.mapView.removeAnnotations(self.mapView.annotations)
            }
            
            for item in placemarks!{
                let placemark = item as CLPlacemark
                
                //调整地图位置和缩放比例，后两个是地图的范围，跨度，单位是米，越小越精确
                let viewRegion = MKCoordinateRegionMakeWithDistance((placemark.location?.coordinate)!, 10000, 10000)
                //设置显示区域
                self.mapView.setRegion(viewRegion, animated: true)
                
                
                //设置点击大头针后显示信息
               let annotation = MKPointAnnotation()
                annotation.coordinate = (placemark.location?.coordinate)!
                //设置点击大头针之后显示的标题
                annotation.title = "标题"
                //设置点击大头针之后显示的描述
                annotation.subtitle = "上海大学"
                
                //添加大头针
                self.mapView.addAnnotation(annotation)
            }
        }
        
    }
    
    //自定义大头针
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView?{
        var annotationView = self.mapView.dequeueReusableAnnotationViewWithIdentifier("PIN_ANNOTATION") as? MKPinAnnotationView
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "PIN_ANNOTATION")
        }
        
        //设置大头针颜色, 默认红色
        annotationView?.pinColor = MKPinAnnotationColor.Green
        //设置大头针的动画效果, 默认关闭
        annotationView?.animatesDrop = true
        //设置点击大头针后是否显示信息, 默认开启
        annotationView?.canShowCallout = true
        
        
        return annotationView!
    }
    

}

