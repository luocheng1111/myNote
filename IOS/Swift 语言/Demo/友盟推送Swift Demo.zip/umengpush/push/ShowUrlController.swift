//
//  ViewController.swift
//  push
//
//  Created by wangyu on 16/5/9.
//  Copyright © 2016年 shagri. All rights reserved.
//

import UIKit

class ShowUrlController: UIViewController {
    
    @IBOutlet weak var webView: UIWebView!
    
    var url:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(url != nil){
            
//            let alert = UIAlertView(title: "111", message: url!, delegate: nil, cancelButtonTitle: "cancel");
//            alert.show();
            
            let nsUrl = NSURL(string: url!)
            let request = NSURLRequest(URL:nsUrl!)
            self.webView.loadRequest(request)
        }else{
            let alert = UIAlertView(title: "提示", message: "网址为空!", delegate: nil, cancelButtonTitle: "cancel");
            alert.show();
        }
    }
    
    
    
}

