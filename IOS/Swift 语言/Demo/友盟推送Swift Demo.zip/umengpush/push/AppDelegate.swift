//
//  AppDelegate.swift
//  push
//
//  Created by wangyu on 16/5/9.
//  Copyright © 2016年 shagri. All rights reserved.
//

import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    
    var window: UIWindow?
 

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {

//        let alert = UIAlertView(title: "didFinishLaunchingWithOptions", message: launchOptions==nil ? "launchOptions为空" : "launchOptions不为空", delegate: nil, cancelButtonTitle: "cancel");
//        alert.show();
        
        //当程序在后台呗销毁时，点击通知进入App时，launchOptions的值为推送传递的值
        if(launchOptions != nil){
            
            let data = try? NSJSONSerialization.dataWithJSONObject(launchOptions!, options: NSJSONWritingOptions.PrettyPrinted)
            var json = JSON(data: data!)
            print("json\(json)")
            let json2 = json["UIApplicationLaunchOptionsRemoteNotificationKey"]
            let url = json2["url"].string
            print("url:\(url)")
            
            //跳转显示url界面
            let viewController = self.window?.rootViewController?.childViewControllers[0] as! ViewController
            viewController.toShowUrlController(url!);
            
        }

        UMessage.startWithAppkey("5730021467e58eef99001575", launchOptions: launchOptions)
        
        //register remoteNotification types （iOS 8.0及其以上版本）
        var action1:UIMutableUserNotificationAction = UIMutableUserNotificationAction();
        action1.identifier = "action1_identifier";
        action1.title="Accept";
        action1.activationMode = UIUserNotificationActivationMode.Foreground;//当点击的时候启动程序
        
        var action2:UIMutableUserNotificationAction = UIMutableUserNotificationAction();
        action2.identifier = "action2_identifier";
        action2.title="Reject";
        action2.activationMode = UIUserNotificationActivationMode.Background;//当点击的时候不启动程序，在后台处理
        action2.authenticationRequired = true;//需要解锁才能处理，如果action.activationMode = UIUserNotificationActivationModeForeground;则这个属性被忽略；
        action2.destructive = true;
        
        var categorys:UIMutableUserNotificationCategory = UIMutableUserNotificationCategory();
        categorys.identifier = "category1";//这组动作的唯一标示
        categorys.setActions([action1, action2], forContext: UIUserNotificationActionContext.Default)
        
        var userSettings = UIUserNotificationSettings(forTypes: [.Sound, .Alert, .Badge], categories: [categorys])
        UMessage.registerRemoteNotificationAndUserNotificationSettings(userSettings)

        //for log（optional）
        UMessage.setLogEnabled(false);

        return true
    }
    
    

    
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData){
        //获取deviceToken
        var characterSet: NSCharacterSet = NSCharacterSet(charactersInString: "<>")
        var deviceTokenString: String = (deviceToken.description as NSString).stringByTrimmingCharactersInSet(characterSet).stringByReplacingOccurrencesOfString(" ", withString: "") as String
        print("deviceToken:\(deviceTokenString)")

        UMessage.registerDeviceToken(deviceToken)
    }
    

    
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]){
        do{
            var data = try NSJSONSerialization.dataWithJSONObject(userInfo, options: NSJSONWritingOptions.PrettyPrinted)
            var json = JSON(data: data)
            print(json)
            var url = json["url"].string!
            print("url:\(url)")
            let viewController = self.window?.rootViewController?.childViewControllers[0] as! ViewController
            if(application.applicationState == UIApplicationState.Active){
                //当前界面是在前台收到通知时
                viewController.showPushMsgAlert(url);
            }else if(application.applicationState == UIApplicationState.Inactive){
                //当前界面是在后台未被销毁收到通知，点击通知进入APP
                viewController.toShowUrlController(url);
            }
        } catch{
            
        }
    }
    
    
    
    
    //发送通知消息
    func scheduleNotification(content:String){
        //创建UILocalNotification来进行本地消息通知
        let localNotification = UILocalNotification()
        //推送时间（设置为30秒以后）
        localNotification.fireDate = NSDate(timeIntervalSinceNow: 0)
        //时区
        localNotification.timeZone = NSTimeZone.defaultTimeZone()
        //推送内容
        localNotification.alertBody = content
        //声音
        localNotification.soundName = UILocalNotificationDefaultSoundName
        //额外信息
        localNotification.userInfo = ["ItemID":"shagri"]
        UIApplication.sharedApplication().scheduleLocalNotification(localNotification)
        
    }

    

}

