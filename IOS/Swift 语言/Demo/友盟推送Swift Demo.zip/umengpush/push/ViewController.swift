//
//  ViewController.swift
//  push
//
//  Created by wangyu on 16/5/9.
//  Copyright © 2016年 shagri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var url:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("viewDidLoad")
        
        
    }

    func test(){
        print("ViewController里的test()")
    }
    
    
    func showPushMsgAlert(msg:String){
        let alertController = UIAlertController(title: "推送通知", message: "跳转且显示网址:\(msg),是否同意？", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.Cancel){(alertAction) -> Void in
            print("取消")
            })
        alertController.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.Default){(alertAction) -> Void in
            print("确定")
            self.toShowUrlController(msg);
            })
        //显示
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    
    
    func toShowUrlController(url:String){
        self.url = url;
        self.performSegueWithIdentifier("showUrl", sender:nil)
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?){
        if(segue.identifier == "showUrl"){
            var secondController = segue.destinationViewController as! ShowUrlController
            secondController.url = url 
        }
    }
    
   
}

