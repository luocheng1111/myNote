//
//  ViewController.swift
//  IOS3
//
//  Created by wangyu on 16/4/1.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loadHtmlString(sender: AnyObject) {
        //通过NSBundle获得index.html所在资源目录的全路径
        let htmlPath:String! = NSBundle.mainBundle().pathForResource("index", ofType: "html")
        //获得index.html所在的基本路径
        let bundleUrl = NSURL.fileURLWithPath(NSBundle.mainBundle().bundlePath)
        
        //将index.html的内容读取到String对象中，读取过程中，encoding指定为NSUTF8StringEncoding
        let html = try? String(contentsOfFile: htmlPath, encoding: NSUTF8StringEncoding)
        //baseURL参数用于设定主页文件到基本路径，即index.html所在到资源目录
        self.webView.loadHTMLString(html!, baseURL: bundleUrl)
 

        
        
    }

    @IBAction func LoadData(sender: AnyObject) {
        //通过NSBundle获得index.html所在资源目录的全路径
        let htmlPath = NSBundle.mainBundle().pathForResource("index", ofType: "html")
        //获得index.html所在的基本路径
        let url = NSURL.fileURLWithPath(NSBundle.mainBundle().bundlePath)
        //使用NSData而没有用NSString读取文件，这是因为NSData是一种二进制到字节数组类型
        let htmlData = NSData(contentsOfFile: htmlPath!)
        //装载WebView，同时指定字符集，因为NSData没有字符集到概念
        webView.loadData(htmlData!, MIMEType: "text/html", textEncodingName: "UTF-8", baseURL: url)
    }
    
    @IBAction func LoadRequest(sender: AnyObject) {
        let url = NSURL(string: "http://www.sina.com.cn")
        let request = NSURLRequest(URL: url!)
        webView.loadRequest(request)
        self.webView.delegate = self
    }
    
    //UIWebViewDelegate委托定义方法
    func webViewDidFinishLoad(webView: UIWebView) {
        //        NSLog("%@", webView.stringByEvaluatingJavaScriptFromString("document.body.innerHTML")!)
        print(webView.stringByEvaluatingJavaScriptFromString("document.body.innerHTML")!)
    }

}

