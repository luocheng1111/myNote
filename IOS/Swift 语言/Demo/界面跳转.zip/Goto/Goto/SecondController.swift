//
//  ViewController.swift
//  Goto
//
//  Created by wangyu on 16/4/19.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class SecondController: UIViewController {
    
    var with:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("with:\(with)")
    }
    
  
    
    
}

