//
//  ViewController.swift
//  Goto
//
//  Created by wangyu on 16/4/19.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func goto(sender: AnyObject) {
        self.performSegueWithIdentifier("Goto", sender: sender)
    }
    
    @IBAction func close(segue:UIStoryboardSegue){
        print("close")
        var vc = segue.destinationViewController as! ViewController
        print(vc.label.text)
        
        var vc2 = segue.sourceViewController as! SecondController
        print(vc2.with)
        label.text = "CCC"
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        print(segue.identifier)
        
        var vc = segue.destinationViewController as! SecondController
        vc.with = "I'm One"
    }

}

