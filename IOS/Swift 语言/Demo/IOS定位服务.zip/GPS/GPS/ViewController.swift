//
//  ViewController.swift
//  GpsForIOS
//
//  Created by wangyu on 16/6/1.
//  Copyright © 2016年 shagri. All rights reserved.
//

import UIKit
//记得导入此包
import CoreLocation
import AddressBook

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var jdu: UILabel!
    @IBOutlet weak var wdu: UILabel!
    @IBOutlet weak var gdu: UILabel!
    @IBOutlet weak var reverseToLocation: UILabel!
    @IBOutlet weak var loaction: UITextField!
    @IBOutlet weak var reverseToJW1: UILabel!
    @IBOutlet weak var reverseToJW2: UILabel!
    //定位管理类
    var locationManager:CLLocationManager!
    var currLocation:CLLocation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.locationManager = CLLocationManager()
        self.locationManager.delegate = self
        
        /**定位精度，有6个取值，精度越高越耗电，
           车载导航时建议用 kCLLocationAccuracyBestForNavigation(导航最高精度，有外接电源时才能使用)
           步行时建议使用   kCLLocationAccuracyHundredMeters(精确到100米)
           设备电池供电时   kCLLocationAccuracyBest(设备使用电池供电时最高的精度)
        **/
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        //距离过滤器，设备移动后获得位置信息的最小距离，单位：米
        self.locationManager.distanceFilter = 1000.0
        
        self.locationManager.requestWhenInUseAuthorization()
        self.locationManager.requestAlwaysAuthorization();
    }
    
    
    @IBAction func startGPS(sender: AnyObject) {
        //开始定位 如果想程序进入时定位，结束时停止定位，则可以在viewWillAppear()里调用开始定位，在viewWillDisappear()里调用停止定位
        if CLLocationManager.locationServicesEnabled(){
            self.locationManager.startUpdatingLocation();
        }
    }
    
    
    @IBAction func stopGPS(sender: AnyObject) {
        //停止定位
        self.locationManager.stopUpdatingLocation();
        
    }
    
    
    //定位成功监听 里面可以获得到定位到经纬度
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        print("定位信息监听方法")
        
        currLocation = locations.last! as CLLocation
        jdu.text = "经度:"+currLocation.coordinate.longitude.description
        wdu.text = "纬度:"+currLocation.coordinate.latitude.description
        gdu.text = "高度:"+currLocation.altitude.description
        print("水平精度:\(currLocation.horizontalAccuracy)")
        print("垂直精度:\(currLocation.verticalAccuracy)")
        print("方向:\(currLocation.course)")
        print("速度:\(currLocation.speed)")

    }
    
    
    //定位失败监听 当定位授权被拒绝时，调用开始定位服务时，会调用次方法，而不会调用定位信息监听方法
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError){
        print("error")
        print(error.localizedDescription)
        
    }
    
    //授权状态发生变化时调用
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        switch status {
        case .AuthorizedAlways:
            print("已经授权")
        case .AuthorizedWhenInUse:
            print("使用时授权")
        case .Denied:
            print("拒绝")
        case .Restricted:
            print("受限")
        case .NotDetermined:
            print("用户还未确定")
        default:
            print("其他情况")
        }
    }
    
    
    
    //反编译地理位置
    @IBAction func reverseToLocation(sender: AnyObject) {
        let geocoder = CLGeocoder();
        geocoder.reverseGeocodeLocation(self.currLocation)
        { (placemarks, error) in
            if placemarks?.count > 0{
                let placemark = placemarks![0] as CLPlacemark
                
                
                
                print("-----以福泉北路388号 虹桥东方国信 为例得出来的结果---------------")
                print(placemark.name);//地名 Optional("虹桥东方国信商务广场2号楼")
                print(placemark.location);//位置 Optional(<+31.23054014,+121.35701644> +/- 100.00m (speed -1.00 mps / course -1.00) @ 16/6/2 中国标准时间 下午2:19:08)
                print(placemark.region);//区域 Optional(CLCircularRegion (identifier:'<+31.23051800,+121.35684500> radius 197.19', center:<+31.23051800,+121.35684500>, radius:197.19m))
                print(placemark.thoroughfare);//街道 Optional("福泉北路388号")
                print(placemark.subThoroughfare); //街道相关信息，例如门牌等 nil
                print(placemark.locality); // 城市 Optional("上海市")
                print(placemark.subLocality); // 城市相关信息，例如标志性建筑 Optional("长宁区")
                print(placemark.administrativeArea); // 州 Optional("上海市")
                print(placemark.subAdministrativeArea); //其他行政区域信息 nil
                print(placemark.postalCode); //邮编 nil
                print(placemark.ISOcountryCode); //国家编码 Optional("CN")
                print(placemark.country); //国家 Optional("中国")
                print(placemark.inlandWater); //水源、湖泊 nil
                print(placemark.ocean); // 海洋 nil
                print(placemark.areasOfInterest); //关联的或利益相关的地标 nil
                
                print(placemark.addressDictionary);//详细地址信息字典, Optional([SubLocality: 长宁区, Street: 福泉北路388号, State: 上海市, CountryCode: CN, Thoroughfare: 福泉北路388号, Name: 虹桥东方国信商务广场2号楼, Country: 中国, FormattedAddressLines: <__NSArrayM 0x157f044c0>(中国上海市长宁区新泾镇福泉北路388号), City: 上海市])
                print("----------------------------------")
            
                //第二种获取信息的方法，
                let addressDictionary = placemark.addressDictionary! as NSDictionary
                let state = addressDictionary.objectForKey(kABPersonAddressStateKey) as! NSString //州，省
                let city = addressDictionary.objectForKey(kABPersonAddressCityKey) as! NSString //城市
                let address = addressDictionary.objectForKey(kABPersonAddressStreetKey) as! NSString //街道信息
                print(addressDictionary.objectForKey(kABPersonAddressZIPKey) as? NSString)
                print(addressDictionary.objectForKey(kABPersonAddressCountryKey) as! NSString) //国家
                print(addressDictionary.objectForKey(kABPersonAddressCountryCodeKey) as! NSString) //国家代码

                self.reverseToLocation.text = "\(placemark.name!)";
//                self.reverseToLocation.text = "\(placemark.locality!)\(placemark.subLocality!)\(placemark.thoroughfare!)";
            }
            
        }
    }
    
    //地理位置反编译成经纬度
    @IBAction func reverseToJW(sender: AnyObject) {
        if self.loaction.text == nil{
            return
        }
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(self.loaction.text!)
        { (placemarks, error) in
            if placemarks!.count > 0{
                print("查询到的记录数:\(placemarks?.count)")
                let placemark = placemarks![0] as CLPlacemark
                let addressDictionary = placemark.addressDictionary! as NSDictionary
                
                var address = addressDictionary.objectForKey(kABPersonAddressStreetKey) as? NSString
                var state = addressDictionary.objectForKey(kABPersonAddressStateKey) as? NSString
                var city = addressDictionary.objectForKey(kABPersonAddressCityKey) as? NSString
                print("city:\(city)")
                print("state:\(state)")
                print("address:\(address)")
                
                let location = placemark.location?.coordinate
                
                self.reverseToJW1.text = "经度:\(location?.longitude.description)";
                self.reverseToJW2.text = "纬度:\(location?.latitude.description)";
            }
        }
    }

}

