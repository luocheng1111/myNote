//
//  ViewController.swift
//  QRCodeStudy
//
//  Created by wangyu on 16/4/26.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate,UIAlertViewDelegate {

    
    var session:AVCaptureSession!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

   
    @IBAction func qrCode(sender: AnyObject) {
        do{
            let captureDevice:AVCaptureDevice! = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        
            let input:AVCaptureDeviceInput! = try AVCaptureDeviceInput(device: captureDevice)
        
            let output:AVCaptureMetadataOutput = AVCaptureMetadataOutput()
            //设置可探测区域
            output.rectOfInterest = computeRectOfInterest()
            //设置对那类元数据感兴趣，这里指定为对二维码数据感兴趣
            output.metadataObjectTypes = [AVMetadataObjectTypeQRCode]
            //设置结果回调
            output.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        
            session = AVCaptureSession()
            session.addInput(input)
            session.addOutput(output)
        
            //界面添加摄像头
            let preview:AVCaptureVideoPreviewLayer! = AVCaptureVideoPreviewLayer(session: session)
            preview.videoGravity = AVLayerVideoGravityResizeAspectFill
            preview.frame = UIScreen.mainScreen().bounds
            view.layer.insertSublayer(preview, atIndex:0)
        
            //在界面中添加一个绿框
            addQRCodeRect()
            
            //开始扫描二维码
            session.startRunning()
            
        }catch _ as NSError{
            //打印错误消息
            let errorAlert = UIAlertView(title: "提醒",
                                         message: "请在iPhone的\"设置-隐私-相机\"选项中,允许本程序访问您的相机",
                                         delegate: self,
                                         cancelButtonTitle: "确定")
            errorAlert.show()
        }


    }
    
    //计算中间可探测区域
    func computeRectOfInterest() -> CGRect{

        let windowSize:CGSize = UIScreen.mainScreen().bounds.size;
        let scanSize:CGSize = CGSizeMake(windowSize.width*3/4, windowSize.width*3/4);
        var scanRect:CGRect = CGRectMake((windowSize.width-scanSize.width)/2,
                                         (windowSize.height-scanSize.height)/2, scanSize.width, scanSize.height);
        //计算rectOfInterest 注意x,y交换位置
        scanRect = CGRectMake(scanRect.origin.y/windowSize.height,
                              scanRect.origin.x/windowSize.width,
                              scanRect.size.height/windowSize.height,
                              scanRect.size.width/windowSize.width);
        return scanRect
    }
    
    
    //在界面中添加一个绿框，
    func addQRCodeRect(){
        //添加中间的探测区域绿框
        let scanRectView = UIView();
        self.view.addSubview(scanRectView)
        
        //这行代码要和可探测代码保持一致
        let windowSize:CGSize = UIScreen.mainScreen().bounds.size;
        //这行代码要和可探测代码保持一致
        let scanSize:CGSize = CGSizeMake(windowSize.width*3/4, windowSize.width*3/4);
        
        scanRectView.frame = CGRectMake(0, 0, scanSize.width, scanSize.height);
        scanRectView.center = CGPointMake(CGRectGetMidX(UIScreen.mainScreen().bounds), CGRectGetMidY(UIScreen.mainScreen().bounds));
        scanRectView.layer.borderColor = UIColor.greenColor().CGColor
        scanRectView.layer.borderWidth = 1;
    }
    
    
    //扫描结果回调
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!){
        
        var stringValue:String?
        
        if metadataObjects.count > 0 {
            let metadataObject = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
            stringValue = metadataObject.stringValue
            
            if stringValue != nil{
                self.session.stopRunning()
            }
            
        }
        self.session.stopRunning()
        
        //输出结果
        print("二维码扫描结果:\(stringValue!)")
        let alertView = UIAlertView(title: "二维码", message: stringValue,
                                    delegate: self, cancelButtonTitle: "确定")
        alertView.show()
    }

    //消息框确认后消失
    func alertView(alertView: UIAlertView, willDismissWithButtonIndex buttonIndex: Int) {
        //继续扫描
        self.session.startRunning()
    }

    
}

