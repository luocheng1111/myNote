//
//  ViewController.swift
//  ListViewRefresh
//
//  Created by wangyu on 16/4/26.
//  Copyright © 2016年 luocheng. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    var data = ["Label"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        var refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "下拉刷新")
        refreshControl.addTarget(self, action: "refreshTableView", forControlEvents: UIControlEvents.ValueChanged)
        self.refreshControl = refreshControl
    }

    func refreshTableView(){
        if(self.refreshControl?.refreshing == true) {
            self.refreshControl?.attributedTitle = NSAttributedString(string: "加载中...")
            //添加新的数据
            self.data.append("New Lable")
            //结束刷新
            self.refreshControl?.endRefreshing()
            
            self.refreshControl?.attributedTitle = NSAttributedString(string: "下拉刷新")
            self.tableView.reloadData()
        }
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return data.count
    }
    

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = self.tableView.dequeueReusableCellWithIdentifier("cell") as! UITableViewCell!
        cell.textLabel?.text = data[indexPath.row]
        return cell
    }
    
  
}

