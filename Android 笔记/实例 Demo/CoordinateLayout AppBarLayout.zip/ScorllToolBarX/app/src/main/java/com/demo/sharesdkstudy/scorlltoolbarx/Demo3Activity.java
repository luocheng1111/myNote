package com.demo.sharesdkstudy.scorlltoolbarx;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Demo3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo3);

        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        AppBarLayout appbar = (AppBarLayout) findViewById(R.id.app_bar);

        setSupportActionBar(toolbar);
        toolbar.setVisibility(View.INVISIBLE);

        appbar.addOnOffsetChangedListener(new AppBarStateChangeListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, AppBarStateChangeListener.AppBarState state) {
                Log.d("STATE", state.name());
                if( state == AppBarState.EXPANDED ) {
                    //展开状态
                    toolbar.setVisibility(View.INVISIBLE);

                }else if(state == AppBarState.COLLAPSED){
                    //折叠状态
                    toolbar.setVisibility(View.VISIBLE);

                }else {
                    //中间状态
                    toolbar.setVisibility(View.INVISIBLE);
                }
            }
        });




    }


}
