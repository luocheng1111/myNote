package com.android.contentprovider.service;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class DataBaseHelper extends SQLiteOpenHelper {

	private static final  String  DATABASENAME="test.db";
	
	private static final  int VERSION=1;
	
	
	public DataBaseHelper(Context context)
	{
		this(context, DATABASENAME, null, VERSION);
	}
	
	
	public DataBaseHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
	
	}


	public void onCreate(SQLiteDatabase db) {
		
		db.execSQL("create table person (personId Integer primary key autoincrement,name varchar(20),age Integer)");

	}


	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	

	}

}
