package com.android.contentprovider.service;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class PersonProvider extends ContentProvider {

	
	private static UriMatcher uriMathcher=new UriMatcher(UriMatcher.NO_MATCH);
	
	private static final int ALLPERSON=1;
	
	
	private static final int PERSON=2;
	
	//uriע��
	
	static
	{
		//Uri.parse("content://com.android.person.personProvider/person") ���������м�¼
		uriMathcher.addURI("com.android.person.personProvider", "person", ALLPERSON);
		
		//Uri.parse("content://com.android.person.personProvider/person/10") ����person�� id=10������¼
		
		uriMathcher.addURI("com.android.person.personProvider", "person/#", PERSON);
	}
	
	
	
	
	private DataBaseHelper dataBaseHelper;
	
	public boolean onCreate() {
		dataBaseHelper=new DataBaseHelper(this.getContext());
		return true;
	}

	//Uri.parse("content://com.android.person.personProvider/person") ���������м�¼
	//Uri.parse("content://com.android.person.personProvider/person/10") ����person�� id=10������¼
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {

		SQLiteDatabase db=dataBaseHelper.getReadableDatabase();
		
		int code=uriMathcher.match(uri);//content://com.android.person.personProvider/person
		
		switch (code) {
		case ALLPERSON://��ѯ����person��¼
			return db.query("person", projection, selection, selectionArgs, null, null, sortOrder);
			

		case PERSON://��ѯ����person��¼
			
		   long id=	ContentUris.parseId(uri);
			return db.query("person", projection, "personId=?", new String[]{String.valueOf(id)}, null, null, sortOrder);
			
			
			
			default:
				throw new IllegalArgumentException("unkown uri :"+uri.toString()); 
		}
		
	
	}

	//Uri.parse("content://com.android.person.personProvider/person") ���������м�¼
	//Uri.parse("content://com.android.person.personProvider/person/10") ����person�� id=10������¼
	public Uri insert(Uri uri, ContentValues values) {

		 SQLiteDatabase db=  dataBaseHelper.getWritableDatabase();
		   int code=uriMathcher.match(uri);
		
		    switch (code) {
			case ALLPERSON:
				//content://com.android.person.personProvider/person 
				// �µ�uri  content://com.android.person.personProvider/person/10
				long id=db.insert("person", "name", values);
				
			return 	ContentUris.withAppendedId(uri, id);

			case PERSON://
				//content://com.android.person.personProvider/person/10
				long id1=db.insert("person", "name", values);
				String path=uri.toString();
				String uriPath=path.substring(0, path.lastIndexOf("/"));
				return Uri.parse(uriPath+"/"+id1);
				
			default:
				throw new IllegalArgumentException("unkown uri :"+uri.toString()); 
			}
		   
	
	}
	//Uri.parse("content://com.android.person.personProvider/person") ���������м�¼
	//Uri.parse("content://com.android.person.personProvider/person/10") ����person�� id=10������¼
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		 SQLiteDatabase db=  dataBaseHelper.getWritableDatabase();
		 int code= uriMathcher.match(uri);
		 switch (code) {
		case ALLPERSON://ɾ��person���еļ�¼
			
			return db.delete("person", selection, selectionArgs);


		case PERSON://ɾ������person��¼
			
		  long id=	ContentUris.parseId(uri);//���� uri���id��ֵ
		 return  db.delete("person", "personId=?",new String[]{String.valueOf(id)});
		 
		default:
			throw new IllegalArgumentException("unkown uri :"+uri.toString()); 

		}

	}
	//Uri.parse("content://com.android.person.personProvider/person") ���������м�¼
	//Uri.parse("content://com.android.person.personProvider/person/10") ����person�� id=10������¼
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		 SQLiteDatabase db=  dataBaseHelper.getWritableDatabase();
		 int code=  uriMathcher.match(uri);
		 switch (code) {
		case ALLPERSON://�������еļ�¼
			
			return db.update("person", values, selection, selectionArgs);
			
		case PERSON://���µ���person
			
		    long id=	ContentUris.parseId(uri);
			return db.update("person", values, "personId=?", new String[]{String.valueOf(id)});

			
		default:
			throw new IllegalArgumentException("unkown uri :"+uri.toString()); 
		}

	}

	public String getType(Uri uri) {

		int code=  uriMathcher.match(uri);

		 switch (code) {
		case ALLPERSON://����
			
			return "vnd.android.cursor.dir/person";

		case PERSON://����
			return "vnd.android.cursor.item/person";
			
		default:
			throw new IllegalArgumentException("unkown uri :"+uri.toString()); 
		}

	}

}
