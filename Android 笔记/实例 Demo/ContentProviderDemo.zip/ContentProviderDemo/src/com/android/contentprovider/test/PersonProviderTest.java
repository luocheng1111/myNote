package com.android.contentprovider.test;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.AndroidTestCase;

public class PersonProviderTest extends AndroidTestCase {

	
	
	   public void testAddPerson()
	   {
		 ContentResolver  contentResolver=  this.getContext().getContentResolver();//ContentResolver����ContentProvider
		   
		 ContentValues values=new ContentValues();
		 values.put("name","abc");
		 values.put("age", 33);
		 System.out.println(contentResolver.insert(Uri.parse("content://com.android.person.personProvider/person/11"), values));
	   }
	   
	   public void testDeletePerson()
	   {
		   ContentResolver  contentResolver=  this.getContext().getContentResolver();//ContentResolver����ContentProvider
		   
		   contentResolver.delete(Uri.parse("content://com.android.person.personProvider/person/13"), null, null);
	   }
	   
	   public void testUpdatePerson()
	   {
		   ContentResolver  contentResolver=  this.getContext().getContentResolver();//ContentResolver����ContentProvider
		   
		   ContentValues values=new ContentValues();
		   values.put("name","zhaoliu" );
		   values.put("age", 30);
		   contentResolver.update(Uri.parse("content://com.android.person.personProvider/person/12"), values, null, null);
	   }
	   
	   public void testFindPerson()
	   {
		   ContentResolver  contentResolver=  this.getContext().getContentResolver();//ContentResolver����ContentProvider
		   Cursor c=  contentResolver.query(Uri.parse("content://com.android.person.personProvider/person/12"), new String[]{"*"}, null, null, null);
	       while(c.moveToNext())
	       {
	    	   System.out.println(c.getInt(c.getColumnIndex("personId"))+","+
	    			   c.getString(c.getColumnIndex("name"))+","+
	    			   c.getInt(c.getColumnIndex("age")));
	       }
	   }
}
