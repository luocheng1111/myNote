package com.example.actionbardemo;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MainActivity extends Activity implements ActionBar.OnNavigationListener{

	ActionBar actionBar;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		actionBar = getActionBar();
//		actionBar.setDisplayShowHomeEnabled(true);
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setTitle("aaa");
//		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
//		actionBar.addTab(actionBar.newTab().setText("Tab1").setTabListener(this));
//		actionBar.addTab(actionBar.newTab().setText("Tab2").setTabListener(this));
//		actionBar.addTab(actionBar.newTab().setText("Tab3").setTabListener(this));
//		actionBar.addTab(actionBar.newTab().setText("Tab4").setTabListener(this));
		String[] str = { "1", "2", "3", "4", "5" };
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
		actionBar.setListNavigationCallbacks(new ArrayAdapter<String>(
				MainActivity.this,
				android.R.layout.simple_spinner_item, str),
				MainActivity.this);
	}

	// 我们可以看到，actonbar的用法跟选项菜单是一样的  
    @Override  
    public boolean onCreateOptionsMenu(Menu menu) {  
        // Inflate the menu; this adds items to the action bar if it is present.  
        getMenuInflater().inflate(R.menu.main, menu);  
        return true;  
    }  
  
    @Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        switch (item.getItemId()) {  
        case R.id.action_refresh:  
            Toast.makeText(this, "Menu Item refresh selected",  
                    Toast.LENGTH_SHORT).show();  
            break;  
        case R.id.action_about:  
            Toast.makeText(this, "Menu Item about selected", Toast.LENGTH_SHORT)  
                    .show();  
            break;  
        case R.id.action_edit:  
            Toast.makeText(this, "Menu Item edit selected", Toast.LENGTH_SHORT)  
                    .show();  
            break;  
        case R.id.action_search:  
            Toast.makeText(this, "Menu Item search selected",  
                    Toast.LENGTH_SHORT).show();  
            break;  
        case R.id.action_help:  
            Toast.makeText(this, "Menu Item  help selected",  
                    Toast.LENGTH_SHORT).show();  
            break;  
        default:  
            break;  
        }  
        return super.onOptionsItemSelected(item);  
    }

	@Override
	public boolean onNavigationItemSelected(int arg0, long arg1) {
		// TODO Auto-generated method stub
		return false;
	}

}  

