package com.example.ssss.http;


import android.os.Handler;
import android.os.Message;



public class HttpClient {
    /**
     * 获取网络接口数据
     * @param param 请求参数
     */
    public static void getNetData(final String param, final Handler handler){
        // 利用postDelayed方法模拟网络请求数据的耗时操作
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                switch (param){
                    case "normal":
                        Message message1 = handler.obtainMessage();
                        message1.what = 0;
                        message1.obj = "根据参数"+param+"的请求网络数据成功";
                        handler.sendMessage(message1);
//                        handler.onSuccess("根据参数"+param+"的请求网络数据成功");
                        break;
                    case "failure":
                        Message message2 = handler.obtainMessage();
                        message2.what = 1;
                        message2.obj = "请求失败：参数有误";
                        handler.sendMessage(message2);
//                        handler.onFailure("请求失败：参数有误");
                        break;
                    case "error":
                        Message message3 = handler.obtainMessage();
                        message3.what = 2;
                        message3.obj = " ";
                        handler.sendMessage(message3);
                        break;
                }
//                handler.onComplete();
            }
        },2000);
    }
}