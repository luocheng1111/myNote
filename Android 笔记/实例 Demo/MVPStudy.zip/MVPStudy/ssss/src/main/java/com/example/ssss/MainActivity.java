package com.example.ssss;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ssss.http.HttpClient;

public class MainActivity extends AppCompatActivity {


    //进度条
    ProgressDialog progressDialog;
    TextView text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView)findViewById(R.id.text);

        initProgressDialog();

    }

    // button 点击事件调用方法
    public void onClick(View v){
        switch(v.getId()){
            case R.id.btn1:
                showLoading();
                HttpClient.getNetData("normal", handler);
            break;
            case R.id.btn2:
                showLoading();
                HttpClient.getNetData("failure", handler);
                break;
            case R.id.btn3:
                showLoading();
                HttpClient.getNetData("error", handler);
                break;
        }

    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0://接收登录
                    hideLoading();
                    text.setText(msg.obj.toString());
                    break;
                case 1://接收登录
                    hideLoading();
                    Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
                    text.setText(msg.obj.toString());
                    break;
                case 2://接收登录
                    hideLoading();
                    Toast.makeText(MainActivity.this, "网络请求数据出现异常", Toast.LENGTH_SHORT).show();
                    text.setText("网络请求数据出现异常");
            }
        }
    };







    public void initProgressDialog(){
        // 初始化进度条
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("正在加载数据");
    }



    public void showLoading() {
        if (!progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    public void hideLoading() {
        if (progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }




}
