package com.android.radionbutton.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity {
  
	
	private RadioGroup classRadioGroup;
	
	private RadioGroup sexRadioGroup;
	
	
	
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //��ʼ�� �ؼ�
        classRadioGroup=  (RadioGroup) this.findViewById(R.id.classRadioGroup);
        sexRadioGroup=  (RadioGroup) this.findViewById(R.id.sexRadioGroup);
        
        classRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			
			public void onCheckedChanged(RadioGroup group, int checkedId) {
			
				RadioButton radioButton=(RadioButton) MainActivity.this.findViewById(checkedId);
				
				//Toast Ҫ�� ����Ҫ���������߳�
				Toast.makeText(MainActivity.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
			}
		});
        sexRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				RadioButton radioButton=(RadioButton) MainActivity.this.findViewById(sexRadioGroup.getCheckedRadioButtonId());
				//Toast Ҫ�� ����Ҫ���������߳�
				Toast.makeText(MainActivity.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
			}
		});
        
    }
}