package com.example.junitest.test;

import com.example.service.PersonService;

import android.test.AndroidTestCase;

public class PersonServiceTest extends AndroidTestCase {

	public void testSave() throws Exception {
		PersonService p = new PersonService();
		p.save(null);
	}
	
	public void testAdd() throws Exception{
		PersonService p = new PersonService();
		p.add(2, 4);
	}
}
