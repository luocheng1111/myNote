package com.example.service;

public class PersonService {

	public void save(String str){
		str.substring(6);
	}
	
	public void add(int a, int b) throws Exception{
		System.out.println("a + b = " + (a + b));
	}
}
