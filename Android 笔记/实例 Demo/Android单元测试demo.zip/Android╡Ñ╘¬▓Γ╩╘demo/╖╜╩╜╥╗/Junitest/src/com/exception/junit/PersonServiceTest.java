package com.exception.junit;

import com.example.service.PersonService;

import android.test.AndroidTestCase;

public class PersonServiceTest extends AndroidTestCase {

	public void testSave()  throws Exception {
		PersonService personService = new PersonService();
		personService.save(null);
	}
	
	
	public void testAdd() throws Exception {
		PersonService personService = new PersonService();
		personService.add(1, 2);
	}
	
	
	
}
