package com.example.studyforwebview.service;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;

// android api �� json��ʽ ��ȫ֧��
public class PersonService {

	
	private WebView htmlWebView;
	
	private Context context;
	
	public PersonService(WebView htmlWebView,Context context){
		
		this.htmlWebView=htmlWebView;
		this.context=context;
	}
	
	public void load(){
		JSONArray  jsonArray=new JSONArray();
		try {
			JSONObject  jsonObject1=new JSONObject();
			jsonObject1.put("id", 1);
			jsonObject1.put("name","����");
			jsonObject1.put("tel", "5556");
			
			JSONObject  jsonObject2=new JSONObject();
			jsonObject2.put("id", 2);
			jsonObject2.put("name","�ϼ�");
			jsonObject2.put("tel", "5558");
			
			JSONObject  jsonObject3=new JSONObject();
			jsonObject3.put("id", 3);
			jsonObject3.put("name","�Ϻ�");
			jsonObject3.put("tel", "5560");
			
			JSONObject  jsonObject4=new JSONObject();
			jsonObject4.put("id", 4);
			jsonObject4.put("name","����");
			jsonObject4.put("tel", "5562");
			
			jsonArray.put(jsonObject1);
			jsonArray.put(jsonObject2);
			jsonArray.put(jsonObject3);
			jsonArray.put(jsonObject4);
			
			//�˵ط��ᱨһ��������ʾ���������������һ�����߳�����ִ�С�
			htmlWebView.loadUrl("javascript:show('"+jsonArray.toString()+"')");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	public void callPhone(String phoneNumber){
		Intent intent=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+phoneNumber));
		context.startActivity(intent);
	}
	   
}
