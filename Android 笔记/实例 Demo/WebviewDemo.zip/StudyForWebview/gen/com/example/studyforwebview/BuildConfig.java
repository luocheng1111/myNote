/** Automatically generated file. DO NOT MODIFY */
package com.example.studyforwebview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}