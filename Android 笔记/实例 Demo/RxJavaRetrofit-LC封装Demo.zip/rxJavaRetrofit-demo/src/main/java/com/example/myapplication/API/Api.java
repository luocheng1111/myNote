package com.example.myapplication.API;



import com.example.myapplication.model.HttpResult;
import com.example.myapplication.model.Movie;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;


/**
 * Created by liukun on 16/3/9.
 */
public interface Api {

    public static final String BASE_URL_DOUBAN = "https://api.douban.com/v2/movie/";

//    @GET("top250")
//    Call<MovieEntity> getTopMovie(@Query("start") int start, @Query("count") int count);

//    @GET("top250")
//    Observable<MovieEntity> getTopMovie(@Query("start") int start, @Query("count") int count);

//    @GET("top250")
//    Observable<HttpResult<List<Subject>>> getTopMovie(@Query("start") int start, @Query("count") int count);

    @GET("top250")
    Observable<HttpResult<List<Movie>>> getTopMovie(@Query("start") int start, @Query("count") int count);


}
