package com.example.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.example.myapplication.API.Api;
import com.example.myapplication.API.ApiCallback;
import com.example.myapplication.API.ApiRequest;
import com.example.myapplication.model.HttpResult;
import com.example.myapplication.model.Movie;

import java.util.List;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void onClick(View v){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.douban.com/v2/movie/")//基础URL 建议以 / 结尾
                .addConverterFactory(GsonConverterFactory.create())//设置 Json 转换器
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())//RxJava 适配器
                .build();

        Api doubanApi = retrofit.create(Api.class);

        doubanApi.getTopMovie(0,10)
                .subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<HttpResult<List<Movie>>>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        Log.i("111", "onSubscribe: ");
                    }

                    @Override
                    public void onNext(HttpResult<List<Movie>> value) {
                        Log.i("111", "onNext: ");
                        Log.i("111", "onNext: "+value.toString());
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.i("111", "onError: ");
                    }

                    @Override
                    public void onComplete() {
                        Log.i("111", "onComplete: ");
                    }
                });

    }


    public void onClick2(View v){

        Observer observer = new ApiCallback<List<Movie>>() {
            @Override
            public void onSuccess(List<Movie> movieList) {
                Log.e("result", "请求成功: "+movieList.size());
            }

            @Override
            public void onFinished() {
//                dismissWaitingDialog();
            }
        };

//        RxRetrofitClient.getInstance(this).getTopMovie(observer,0,10);
        ApiRequest.getTopMovie(this, observer,0,10);
    }
}
