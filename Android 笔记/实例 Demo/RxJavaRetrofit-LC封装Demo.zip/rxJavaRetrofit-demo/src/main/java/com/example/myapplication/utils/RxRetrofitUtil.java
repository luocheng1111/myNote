package com.example.myapplication.utils;

import android.content.Context;

import com.example.myapplication.API.Api;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by liukun on 16/3/9.
 */
public class RxRetrofitUtil {

    public Api doubanApi;
    public static Context context;


    //在访问HttpMethods时创建单例
    private static class SingletonHolder{
        private static final RxRetrofitUtil INSTANCE = new RxRetrofitUtil();
    }

    //获取单例
    public static RxRetrofitUtil getInstance(Context context){
        RxRetrofitUtil.context = context;
        return SingletonHolder.INSTANCE;
    }


    //构造方法私有
    private RxRetrofitUtil() {
        //手动创建一个OkHttpClient并设置超时时间
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        //设置超时
        builder.connectTimeout(15, TimeUnit.SECONDS);
        builder.readTimeout(20, TimeUnit.SECONDS);
        builder.writeTimeout(20, TimeUnit.SECONDS);

         // cookie持久化管理 用于实现用户免登陆过程
//       builder.cookieJar(new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(context)));

        // 添加各种插入器
        addInterceptor(builder);

        // 创建Retrofit实例
        Retrofit retrofit = new Retrofit.Builder()
                 .client(builder.build())
                 .addConverterFactory(GsonConverterFactory.create())
                 .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                 .baseUrl(Api.BASE_URL_DOUBAN)
                 .build();

        // 创建API接口类
        doubanApi = retrofit.create(Api.class);
    }


    private static void addInterceptor(OkHttpClient.Builder builder) {
        // 添加统一的Header
        builder.addInterceptor(new HttpHeaderInterceptor());

        //添加缓存控制策略 缓存大小为10M
        //已实现 当有网络时,读取网络数据,并缓存数据,没有网络时,读取本地缓存数据
        Cache cache = new Cache(context.getCacheDir(), 10 * 1024 * 1024);
        builder.cache(cache);
        builder.addInterceptor(new LocalCacheInterceptor());
        builder.addNetworkInterceptor(new HttpCacheInterceptor());

        // 添加日志拦截器
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(logging);

        // 添加调试工具 需要翻墙才可使用
//        builder.networkInterceptors().add(new StethoInterceptor());
    }

    /**
     * 本地缓存拦截器，请求前根据网络情况设置缓存是从本地缓存读取还是从网络请求获取
     */
    public static class LocalCacheInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException {
            //如果没有网络,则设置数据从本地缓存读取,如果有网络,则清除Cache-Control,让数据从网络获取
            if (!NetworkUtil.isNetworkConnected(context)) {
                CacheControl cacheControl = new CacheControl.Builder().maxAge(Integer.MAX_VALUE, TimeUnit.SECONDS).maxStale(Integer.MAX_VALUE, TimeUnit.SECONDS).build();
                Request request = chain.request().newBuilder().cacheControl(cacheControl).build();
                return chain.proceed(request);
            }else{
                Request request = chain.request().newBuilder().removeHeader("Cache-Control").build();
                return chain.proceed(request);
            }

        }
    }




    /**
     * 网络缓存拦截器，设置缓存是从本地缓存读取还是从网络请求获取
     * 此方法主要用于请求数据后修改Cache-Control配置信息, 因为请求数据后,此数据有可能被更改,需要重新设置
     *
     */
    public static class HttpCacheInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException {
            Response response = chain.proceed(chain.request());
           // max-age: 设置时间后, 代表这段时间内不管有没有网, 都读缓存
           // max-stale 设置网络未连接的情况下缓存时间
            CacheControl cacheControl = new CacheControl.Builder().maxAge(0, TimeUnit.SECONDS).maxStale(5, TimeUnit.DAYS).build();
            return response.newBuilder()
                    .header("Cache-Control", cacheControl.toString())
                    .removeHeader("Pragma").build();
        }
    }



    /**
     * 网络请求公共头信息插入器
     *
     * Created by XiaoFeng on 17/1/18.
     */
    public static class HttpHeaderInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
//            Request original = chain.request();
//            Request request = original.newBuilder()
//                    .header("User-Agent", "Android, xxx")
//                    .header("Accept", "application/json")
//                    .header("Content-type", "application/json")
//                    .method(original.method(), original.body())
//                    .build();
            return chain.proceed(chain.request());
        }
    }


    /**
     * 请求网络
     *
     */
    public static <T> void requestNetWork(Observable<T> o, Observer<T> s){
        o.subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(s);
    }





}
