package com.example.myapplication.API;

import android.content.Context;

import com.example.myapplication.model.HttpResult;
import com.example.myapplication.model.Movie;
import com.example.myapplication.utils.RxRetrofitUtil;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.functions.Function;

/**
 * Created by liukun on 16/3/10.
 */
public class ApiRequest {

    /**
     * 用于获取豆瓣电影Top250的数据
     *
     * @param subscriber 由调用者传过来的观察者对象
     * @param start      起始位置
     * @param count      获取长度
     */

    public static void getTopMovie(Context context, Observer<HttpResult<List<Movie>>> subscriber, int start, int count) {
        //设置请求参数和返回值类型
        Observable observable = RxRetrofitUtil.getInstance(context).doubanApi.getTopMovie(start, count)
                .map(new HttpResultFunc<List<Movie>>());


        //请求网络
        RxRetrofitUtil.requestNetWork(observable, subscriber);
    }


    /**
     * 对HttpResult 返回结果做预处理，对逻辑错误抛出异常
     * 用来统一处理Http的resultCode,并将HttpResult的Data部分剥离出来返回给subscriber
     * {
     * "  code":"200",
     * "  message":"Return Successd!",
     * "  data":{
     * "      name":"张三"
     * "      age":3
     * }
     *
     * @param <T> Subscriber真正需要的数据类型，也就是Data部分的数据类型
     */
    private static class HttpResultFunc<T> implements Function<HttpResult<T>, T> {

        @Override
        public T apply(HttpResult<T> httpResult) throws Exception {
//            if (restResult.getRes() != RESTResult.SUCCESS) {
////                    throw new ApiException(restResult.getRes(), restResult.getMsg());
////          }
////          return restResult.getData();
            return httpResult.getSubjects();


        }
    }


}



