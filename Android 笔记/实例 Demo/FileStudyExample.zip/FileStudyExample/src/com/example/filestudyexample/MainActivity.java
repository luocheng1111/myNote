package com.example.filestudyexample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	String fileName = "example";
	
	EditText et_;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		et_ = (EditText) findViewById(R.id.et_);
	}

	public void onClick(View v){
		switch (v.getId()) {
		case R.id.btn_save:
			save(fileName, et_.getText().toString());
			break;
		case R.id.btn_get:
			String fileContent = get(fileName);
			Toast.makeText(this, fileContent, Toast.LENGTH_SHORT).show();
			break;
		}
		
	}
	
	
	public void save(String name, String data){
		FileOutputStream out = null;
		BufferedWriter writer = null;
		try {
			out = openFileOutput(name, Context.MODE_PRIVATE);
			writer = new BufferedWriter(new OutputStreamWriter(out)) ;
			writer.write(data);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				if(writer != null){
					writer.close();
				}
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		Toast.makeText(this, "�洢�ɹ�", Toast.LENGTH_SHORT).show();
	}
	
	public String get(String fileName){
		StringBuilder fileContent = new StringBuilder();
		FileInputStream in = null;
		BufferedReader reader = null;
		try {
			in = openFileInput(fileName);
			reader = new BufferedReader(new InputStreamReader(in)) ;
			String line = "";
			while((line = reader.readLine()) != null){
				fileContent.append(line);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(reader != null){
					reader.close();
				}
				in.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return fileContent.toString();
	}

}
