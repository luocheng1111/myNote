package com.example.applemac.danmu;

import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import master.flame.danmaku.controller.IDanmakuView;
import master.flame.danmaku.danmaku.loader.ILoader;
import master.flame.danmaku.danmaku.loader.IllegalDataException;
import master.flame.danmaku.danmaku.loader.android.DanmakuLoaderFactory;
import master.flame.danmaku.danmaku.model.BaseDanmaku;
import master.flame.danmaku.danmaku.model.DanmakuTimer;
import master.flame.danmaku.danmaku.model.IDanmakus;
import master.flame.danmaku.danmaku.model.IDisplayer;
import master.flame.danmaku.danmaku.model.android.BaseCacheStuffer;
import master.flame.danmaku.danmaku.model.android.DanmakuContext;
import master.flame.danmaku.danmaku.model.android.Danmakus;
import master.flame.danmaku.danmaku.model.android.SpannedCacheStuffer;
import master.flame.danmaku.danmaku.parser.BaseDanmakuParser;
import master.flame.danmaku.danmaku.parser.IDataSource;
import master.flame.danmaku.danmaku.util.IOUtils;

public class MainActivity extends AppCompatActivity {

//    private BaseDanmakuParser mParser;//解析器对象
    private IDanmakuView mDanmakuView;
//    private DanmakuContext mDanmakuContext;
    DanmuControl danmuControl;

//    private BaseCacheStuffer.Proxy mCacheStufferAdapter = new BaseCacheStuffer.Proxy() {
//
//        private Drawable mDrawable;
//
//        @Override
//        public void prepareDrawing(final BaseDanmaku danmaku, boolean fromWorkerThread) {
//            if (danmaku.text instanceof Spanned) { // 根据你的条件检查是否需要需要更新弹幕
//                // FIXME 这里只是简单启个线程来加载远程url图片，请使用你自己的异步线程池，最好加上你的缓存池
//                new Thread() {
//
//                    @Override
//                    public void run() {
//                        String url = "http://www.bilibili.com/favicon.ico";
//                        InputStream inputStream = null;
//                        Drawable drawable = mDrawable;
//                        if(drawable == null) {
//                            try {
//                                URLConnection urlConnection = new URL(url).openConnection();
//                                inputStream = urlConnection.getInputStream();
//                                drawable = BitmapDrawable.createFromStream(inputStream, "bitmap");
//                                mDrawable = drawable;
//                            } catch (MalformedURLException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            } finally {
//                                IOUtils.closeQuietly(inputStream);
//                            }
//                        }
//                        if (drawable != null) {
//                            drawable.setBounds(0, 0, 100, 100);
//                            SpannableStringBuilder spannable = createSpannable(drawable);
//                            danmaku.text = spannable;
//                            if(mDanmakuView != null) {
//                                mDanmakuView.invalidateDanmaku(danmaku, false);
//                            }
//                            return;
//                        }
//                    }
//                }.start();
//            }
//        }
//
//        @Override
//        public void releaseResource(BaseDanmaku danmaku) {
//            // TODO 重要:清理含有ImageSpan的text中的一些占用内存的资源 例如drawable
//        }
//    };
//
//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //实例化
        mDanmakuView = (IDanmakuView) findViewById(R.id.danmaku_view);

        danmuControl = new DanmuControl(this, mDanmakuView);

//        mDanmakuContext = DanmakuContext.create();
//
//
//        // 设置弹幕的最大显示行数
//        HashMap<Integer, Integer> maxLinesPair = new HashMap<Integer, Integer>();
//        maxLinesPair.put(BaseDanmaku.TYPE_SCROLL_RL, 3); // 滚动弹幕最大显示3行
//
//
//        // 设置是否禁止重叠
//        HashMap<Integer, Boolean> overlappingEnablePair = new HashMap<Integer, Boolean>();
//        overlappingEnablePair.put(BaseDanmaku.TYPE_SCROLL_LR, true);
//        overlappingEnablePair.put(BaseDanmaku.TYPE_FIX_BOTTOM, true);
//
//
//        mDanmakuContext.setDanmakuStyle(IDisplayer.DANMAKU_STYLE_STROKEN, 3) //设置描边样式
//                .setDuplicateMergingEnabled(false)
//                .setScrollSpeedFactor(1.2f) //是否启用合并重复弹幕
//                .setScaleTextSize(1.2f) //设置弹幕滚动速度系数,只对滚动弹幕有效
//                .setCacheStuffer(new SpannedCacheStuffer(), mCacheStufferAdapter) // 图文混排使用SpannedCacheStuffer  设置缓存绘制填充器，默认使用{@link SimpleTextCacheStuffer}只支持纯文字显示, 如果需要图文混排请设置{@link SpannedCacheStuffer}如果需要定制其他样式请扩展{@link SimpleTextCacheStuffer}|{@link SpannedCacheStuffer}
//                //        .setCacheStuffer(new BackgroundCacheStuffer())  // 绘制背景使用BackgroundCacheStuffer
//                .setMaximumLines(maxLinesPair) //设置最大显示行数
//                .preventOverlapping(overlappingEnablePair)
//                .setDanmakuMargin(40); //设置防弹幕重叠，null为允许重叠
//
//
//        if (mDanmakuView != null) {
////            mParser = createParser(this.getResources().openRawResource(R.raw.comments)); //创建解析器对象，从raw资源目录下解析comments.xml文本
//            mDanmakuView.setCallback(new master.flame.danmaku.controller.DrawHandler.Callback() {
//                @Override
//                public void updateTimer(DanmakuTimer timer) {
//                }
//
//                @Override
//                public void drawingFinished() {
//
//                }
//
//                @Override
//                public void danmakuShown(BaseDanmaku danmaku) {
//                    Log.d("DFM", "danmakuShown(): text=" + danmaku.text);
//                }
//
//                @Override
//                public void prepared() {
//                    mDanmakuView.start();
//                }
//            });
//        }
//
//        mDanmakuView.setOnDanmakuClickListener(new IDanmakuView.OnDanmakuClickListener() {
//
//            @Override
//            public boolean onDanmakuClick(IDanmakus danmakus) {
//                Log.d("DFM", "onDanmakuClick: danmakus size:" + danmakus.size());
//                BaseDanmaku latest = danmakus.last();
//                if (null != latest) {
//                    Log.d("DFM", "onDanmakuClick: text of latest danmaku:" + latest.text);
//                    return true;
//                }
//                return false;
//            }
//
//            @Override
//            public boolean onDanmakuLongClick(IDanmakus danmakus) {
//                return false;
//            }
//
//            @Override
//            public boolean onViewClick(IDanmakuView view) {
////                mMediaController.setVisibility(View.VISIBLE);
//                return false;
//            }
//        });
//
//        mDanmakuView.prepare(new BaseDanmakuParser() {
//
//            @Override
//            protected Danmakus parse() {
//                return new Danmakus();
//            }
//        }, mDanmakuContext);
//        mDanmakuView.showFPS(false); //是否显示FPS
//        mDanmakuView.enableDanmakuDrawingCache(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        danmuControl.onResume();
    }



    @Override
    protected void onPause() {
        super.onPause();
        danmuControl.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        danmuControl.onDestroy();
    }



    /**
     * 创建解析器对象，解析输入流
     * @param stream
     * @return
     */
    private BaseDanmakuParser createParser(InputStream stream) {

        if (stream == null) {
            return new BaseDanmakuParser() {

                @Override
                protected Danmakus parse() {
                    return new Danmakus();
                }
            };
        }

        // DanmakuLoaderFactory.create(DanmakuLoaderFactory.TAG_BILI) //xml解析
        // DanmakuLoaderFactory.create(DanmakuLoaderFactory.TAG_ACFUN) //json文件格式解析
        ILoader loader = DanmakuLoaderFactory.create(DanmakuLoaderFactory.TAG_BILI);

        try {
            loader.load(stream);
        } catch (IllegalDataException e) {
            e.printStackTrace();
        }
        BaseDanmakuParser parser = new BiliDanmukuParser();
        IDataSource<?> dataSource = loader.getDataSource();
        parser.load(dataSource);
        return parser;

    }


    /**
     * 添加文本弹幕
     * danmuControl.showTextDanmu(new Danmu("测试测试"));
     */
    public void addDanmaku(View v) {
//        BaseDanmaku danmaku = danmuControl.mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
//        if (danmaku == null || mDanmakuView == null) {
//            return;
//        }
//
//        danmaku.text = "这是一条弹幕" + System.nanoTime();
//        danmaku.padding = 5;
//        danmaku.priority = 0;  //0 表示可能会被各种过滤器过滤并隐藏显示 //1 表示一定会显示, 一般用于本机发送的弹幕
//        danmaku.isLive = false; //是否是直播弹幕
//        danmaku.setTime(mDanmakuView.getCurrentTime() + 1200);
//        danmaku.textSize = 25f ;
//        danmaku.textColor = Color.RED;
//        danmaku.textShadowColor = Color.WHITE; //阴影/描边颜色
//        danmaku.borderColor = Color.GREEN; //边框颜色，0表示无边框
//        mDanmakuView.addDanmaku(danmaku);

        danmuControl.showTextDanmu(new Danmu("测试测试"));

    }


    private void setData() {
        List<Danmu> danmus = new ArrayList<Danmu>();
        Danmu danmu1 = new Danmu("姜文博大傻逼", "Like", R.drawable.ic_default_header);
        Danmu danmu2 = new Danmu("这是一条弹幕啦啦啦", "Comment", R.drawable.ic_default_header);
        Danmu danmu3 = new Danmu("姜文博大大傻逼", "Like", R.drawable.ic_default_header);
        Danmu danmu4 = new Danmu("这又是一条弹幕啦啦啦", "Comment", R.drawable.wat);
        Danmu danmu5 = new Danmu("姜文博大大大傻逼", "Like", R.drawable.wat);
        Danmu danmu6 = new Danmu("这还是一条弹幕啦啦啦", "Comment", R.drawable.wat);
        danmus.add(danmu1);
        danmus.add(danmu2);
        danmus.add(danmu3);
        danmus.add(danmu4);
        danmus.add(danmu5);
        danmus.add(danmu6);
        Collections.shuffle(danmus);
        danmuControl.showDanmuList(danmus);
    }

    /**
     * 添加图文混排弹幕
     */
     public void addDanmaKuShowTextAndImage(View v) {
//        BaseDanmaku danmaku = danmuControl.mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
//        Drawable drawable = getResources().getDrawable(R.mipmap.ic_launcher);
//        drawable.setBounds(0, 0, 100, 100);
//        SpannableStringBuilder spannable = createSpannable(drawable);
//        danmaku.text = spannable;
//        danmaku.padding = 5;
//        danmaku.priority = 1;  // 一定会显示, 一般用于本机发送的弹幕
//        danmaku.isLive = false;
//         danmaku.setTime(mDanmakuView.getCurrentTime() + 1200);
//        danmaku.textSize = 25f;
//        danmaku.textColor = Color.RED;
//        danmaku.textShadowColor = 0; // 重要：如果有图文混排，最好不要设置描边(设textShadowColor=0)，否则会进行两次复杂的绘制导致运行效率降低
//        danmaku.underlineColor = Color.GREEN;
//        mDanmakuView.addDanmaku(danmaku);

//         danmuControl.showShowTextAndLocalImageDanma(new Danmu("测试测试", R.mipmap.ic_launcher));

         setData();
    }

    /**
     * 创建图文混排模式
     * @param drawable
     * @return
     */
    private SpannableStringBuilder createSpannable(Drawable drawable) {
        String text = "bitmap";
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(text);
        ImageSpan span = new ImageSpan(drawable);//ImageSpan.ALIGN_BOTTOM);
        spannableStringBuilder.setSpan(span, 0, text.length(), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.append("图文混排");
        spannableStringBuilder.setSpan(new BackgroundColorSpan(Color.parseColor("#8A2233B1")), 0, spannableStringBuilder.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        return spannableStringBuilder;
    }






}
