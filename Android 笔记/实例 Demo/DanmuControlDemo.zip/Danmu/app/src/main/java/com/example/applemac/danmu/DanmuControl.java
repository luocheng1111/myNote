package com.example.applemac.danmu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.nfc.Tag;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.text.style.ImageSpan;
import android.util.Log;
import android.util.TypedValue;

import java.util.HashMap;
import java.util.List;

import master.flame.danmaku.controller.DrawHandler;
import master.flame.danmaku.controller.IDanmakuView;
import master.flame.danmaku.danmaku.model.BaseDanmaku;
import master.flame.danmaku.danmaku.model.DanmakuTimer;
import master.flame.danmaku.danmaku.model.IDisplayer;
import master.flame.danmaku.danmaku.model.android.BaseCacheStuffer;
import master.flame.danmaku.danmaku.model.android.DanmakuContext;
import master.flame.danmaku.danmaku.model.android.Danmakus;
import master.flame.danmaku.danmaku.model.android.SpannedCacheStuffer;
import master.flame.danmaku.danmaku.parser.BaseDanmakuParser;

/**
 * Created by luocheng on 2019/3/20.
 */

public class DanmuControl {

    private static final String TAG = "DanmuControl";

    private static final int PINK_COLOR   = 0xffff5a93;//粉红
    private static final int ORANGE_COLOR = 0xffff815a;//橙色
    private static final int BLACK_COLOR  = 0xb2000000;//半透明黑色

    //这两个用来控制两行弹幕之间的间距
    private int DANMU_PADDING       = 8;
    private int DANMU_PADDING_INNER = 7;
    private int DANMU_RADIUS        = 11;//圆角半径

    //弹幕字体的大小
    private float DANMU_TEXT_SIZE = 10;

    //弹幕颜色 测试时如果此颜色为白色 要注意背景色是不是白色
    private int DANMU_TEXT_COLOR = Color.RED;
    //阴影/描边颜色
    private int DANMU_TEXT_SHARDOWCOLOR = Color.WHITE;
    //弹幕边框的颜色 0表示无边框
    private int DANMU_TEXT_BOARDCOLOR = 0;

    //头像的大小
    private int   BITMAP_WIDTH    = 18;
    private int   BITMAP_HEIGHT   = 18;

    private Context mContext;
    public IDanmakuView mDanmakuView;
    public DanmakuContext mDanmakuContext;


    public DanmuControl(Context context, IDanmakuView danmakuView) {
        this.mContext = context;
        initSize(context);
        initDanmuConfig();
        initDanmuView(danmakuView);
    }

    /**
     * 对数值进行转换(dp转px, sp转px)，适配手机，必须在初始化之前，否则有些数据不会起作用
     */
    private void initSize(Context context) {
        BITMAP_WIDTH = dp2pxConvertInt(context, BITMAP_HEIGHT);
        BITMAP_HEIGHT = dp2pxConvertInt(context, BITMAP_HEIGHT);
//        EMOJI_SIZE = DpOrSp2PxUtil.dp2pxConvertInt(context, EMOJI_SIZE);
        DANMU_PADDING =dp2pxConvertInt(context, DANMU_PADDING);
        DANMU_PADDING_INNER = dp2pxConvertInt(context, DANMU_PADDING_INNER);
        DANMU_RADIUS = dp2pxConvertInt(context, DANMU_RADIUS);
        DANMU_TEXT_SIZE = sp2px(context, DANMU_TEXT_SIZE);
    }

    public int dp2pxConvertInt(Context context, float dpValue) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dpValue, context.getResources().getDisplayMetrics());
    }

    public float sp2px(Context context, float spValue) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, spValue, context.getResources().getDisplayMetrics());
    }

    /**
     * 初始化配置
     */
    private void initDanmuConfig() {
        // 设置弹幕的最大显示行数
        HashMap<Integer, Integer> maxLinesPair = new HashMap<Integer, Integer>();
        maxLinesPair.put(BaseDanmaku.TYPE_SCROLL_RL, 2); // 滚动弹幕最大显示行数


        // 设置是否禁止重叠
        HashMap<Integer, Boolean> overlappingEnablePair = new HashMap<Integer, Boolean>();
        overlappingEnablePair.put(BaseDanmaku.TYPE_SCROLL_LR, true);
        overlappingEnablePair.put(BaseDanmaku.TYPE_FIX_BOTTOM, true);

        mDanmakuContext = DanmakuContext.create();
        mDanmakuContext.setDanmakuStyle(IDisplayer.DANMAKU_STYLE_STROKEN, 3) //设置描边样式
                .setDuplicateMergingEnabled(false)
                .setScrollSpeedFactor(1.2f) //是否启用合并重复弹幕
                .setScaleTextSize(1.2f) //设置弹幕滚动速度系数,只对滚动弹幕有效
                .setCacheStuffer(new BackgroundCacheStuffer(), mCacheStufferAdapter) // 图文混排使用SpannedCacheStuffer  设置缓存绘制填充器，默认使用{@link SimpleTextCacheStuffer}只支持纯文字显示, 如果需要图文混排请设置{@link SpannedCacheStuffer}如果需要定制其他样式请扩展{@link SimpleTextCacheStuffer}|{@link SpannedCacheStuffer}
                .setMaximumLines(maxLinesPair) //设置最大显示行数
                .preventOverlapping(overlappingEnablePair);
//                .setDanmakuMargin(40);
    }


    /**
     * 绘制背景(自定义弹幕样式)
     */
    private class BackgroundCacheStuffer extends SpannedCacheStuffer {
        // 通过扩展SimpleTextCacheStuffer或SpannedCacheStuffer个性化你的弹幕样式
        final Paint paint = new Paint();

        @Override
        public void measure(BaseDanmaku danmaku, TextPaint paint, boolean fromWorkerThread) {
//            danmaku.padding = 20;  // 在背景绘制模式下增加padding
            super.measure(danmaku, paint, fromWorkerThread);
        }

        @Override
        public void drawBackground(BaseDanmaku danmaku, Canvas canvas, float left, float top) {
            paint.setAntiAlias(true);
//            if (!danmaku.isGuest && danmaku.userId == mGoodUserId && mGoodUserId != 0) {
//                paint.setColor(PINK_COLOR);//粉红 楼主
//            } else if (!danmaku.isGuest && danmaku.userId == mMyUserId
//                    && danmaku.userId != 0) {
//                paint.setColor(ORANGE_COLOR);//橙色 我
//            } else {
//                paint.setColor(BLACK_COLOR);//黑色 普通
//            }
//            if (danmaku.isGuest) {//如果是赞 就不要设置背景
//                paint.setColor(Color.TRANSPARENT);
//            }
//
//            //绘制弧度背景
//            canvas.drawRoundRect(new RectF(left + DANMU_PADDING_INNER, top + DANMU_PADDING_INNER
//                            , left + danmaku.paintWidth - DANMU_PADDING_INNER + 6,
//                            top + danmaku.paintHeight - DANMU_PADDING_INNER + 6),//+6 主要是底部被截得太厉害了，+6是增加padding的效果
//                    DANMU_RADIUS, DANMU_RADIUS, paint);
        }

        @Override
        public void drawStroke(BaseDanmaku danmaku, String lineText, Canvas canvas, float left, float top, Paint paint) {
            // 禁用描边绘制
        }
    }


    private void initDanmuView(IDanmakuView danmakuView) {
        this.mDanmakuView = danmakuView;
        mDanmakuView.setCallback(new DrawHandler.Callback() {
            @Override
            public void prepared() {
                mDanmakuView.start();
            }

            @Override
            public void updateTimer(DanmakuTimer timer) {

            }

            @Override
            public void danmakuShown(BaseDanmaku danmaku) {

            }

            @Override
            public void drawingFinished() {

            }
        });

        mDanmakuView.prepare(new BaseDanmakuParser() {

            @Override
            protected Danmakus parse() {
                return new Danmakus();
            }
        }, mDanmakuContext);
        mDanmakuView.enableDanmakuDrawingCache(true);
    }


    private BaseCacheStuffer.Proxy mCacheStufferAdapter = new BaseCacheStuffer.Proxy() {

        @Override
        public void prepareDrawing(final BaseDanmaku danmaku, boolean fromWorkerThread) {
//            if (danmaku.text instanceof Spanned) { // 根据你的条件检查是否需要需要更新弹幕
//            }
        }

        @Override
        public void releaseResource(BaseDanmaku danmaku) {
            // TODO 重要:清理含有ImageSpan的text中的一些占用内存的资源 例如drawable
            if (danmaku.text instanceof Spanned) {
                danmaku.text = "";
            }
        }
    };




    public void hide() {
        if (mDanmakuView != null) {
            mDanmakuView.hide();
        }
    }

    public void show() {
        if (mDanmakuView != null) {
            mDanmakuView.show();
        }
    }

    public void onResume() {
        if (mDanmakuView != null && mDanmakuView.isPrepared() && mDanmakuView.isPaused()) {
            mDanmakuView.resume();
        }
    }

    public void onPause() {
        if (mDanmakuView != null && mDanmakuView.isPrepared()) {
            mDanmakuView.pause();
        }
    }

    public void onDestroy() {
        if (mDanmakuView != null) {
            mDanmakuView.release();
            mDanmakuView = null;
        }
    }

//
    public void showDanmuList(final List<Danmu> danmuLists) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < danmuLists.size(); i++) {
                    showLiveDanma(danmuLists.get(i));
                }
            }
        }).start();
    }




    //danmuControl.showTextDanmu(new Danmu("测试测试"));
    public void showTextDanmu(Danmu danmu) {
        showDanmu(danmu.content);
    }

    //danmuControl.showShowTextAndLocalImageDanma(new Danmu("测试测试", R.mipmap.ic_launcher));
    public void showTextAndLocalImageDanma(Danmu danmu) {
        if(danmu.imgId>0) {
            Drawable drawable = mContext.getResources().getDrawable(danmu.imgId);
            drawable.setBounds(0, 0, 100, 100);
            SpannableStringBuilder spannable = createSpannable(drawable);
            showDanmu(spannable);
        }else {
            showDanmu(danmu.content);
        }
    }



    //danmuControl.showLiveDanma(new Danmu("测试测试", R.mipmap.ic_launcher));
    public void showLiveDanma(Danmu danmu) {
        if(danmu.imgId>0) {
            Bitmap bitmap = getDefaultBitmap(danmu.imgId);
            CircleDrawable circleDrawable = new CircleDrawable(mContext, bitmap, true);
            circleDrawable.setBounds(0, 0, BITMAP_WIDTH, BITMAP_HEIGHT);
            SpannableStringBuilder spannable = createSpannable(circleDrawable, danmu.content);
            showDanmu(spannable);
        }else {
            showDanmu(danmu.content);
        }
    }

    private Bitmap getDefaultBitmap(int drawableId) {
        Bitmap mDefauleBitmap = null;
        Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), drawableId);
        if (bitmap != null) {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            Log.d(TAG, "width = " + width);
            Log.d(TAG, "height = " + height);
            Matrix matrix = new Matrix();
            matrix.postScale(((float) BITMAP_WIDTH) / width, ((float) BITMAP_HEIGHT) / height);
            mDefauleBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
            Log.d(TAG, "mDefauleBitmap getWidth = " + mDefauleBitmap.getWidth());
            Log.d(TAG, "mDefauleBitmap getHeight = " + mDefauleBitmap.getHeight());
        }
        return mDefauleBitmap;
    }

    private SpannableStringBuilder createSpannable(Drawable drawable) {
        String text = "bitmap";
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(text);
        ImageSpan span = new ImageSpan(drawable);//ImageSpan.ALIGN_BOTTOM);
        spannableStringBuilder.setSpan(span, 0, text.length(), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.append("图文混排");
        spannableStringBuilder.setSpan(new BackgroundColorSpan(Color.parseColor("#8A2233B1")), 0, spannableStringBuilder.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        return spannableStringBuilder;
    }

    private SpannableStringBuilder createSpannable(Drawable drawable, String content) {
        String text = "bitmap";
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(text);
        CenteredImageSpan span = new CenteredImageSpan(drawable);
        spannableStringBuilder.setSpan(span, 0, text.length(), Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        if (!TextUtils.isEmpty(content)) {
            spannableStringBuilder.append(" ");
            spannableStringBuilder.append(content.trim());
        }
        return spannableStringBuilder;
    }

    private void showDanmu(CharSequence charSequence) {
        BaseDanmaku danmaku = mDanmakuContext.mDanmakuFactory.createDanmaku(BaseDanmaku.TYPE_SCROLL_RL);
        if (danmaku == null || mDanmakuView == null) {
            return;
        }

//        danmaku.userId = danmu.userId;
//        danmaku.isGuest = danmu.type.equals("Like");//isGuest此处用来判断是赞还是评论

        danmaku.text = charSequence;
        danmaku.padding = DANMU_PADDING;
        danmaku.priority = 0;  //0 表示可能会被各种过滤器过滤并隐藏显示 //1 表示一定会显示, 一般用于本机发送的弹幕
        danmaku.isLive = false; //是否是直播弹幕
        danmaku.setTime(mDanmakuView.getCurrentTime() + 1200); //弹幕显示的时间
        danmaku.textSize = DANMU_TEXT_SIZE;
        danmaku.textColor = DANMU_TEXT_COLOR;
        danmaku.textShadowColor = DANMU_TEXT_SHARDOWCOLOR; //阴影/描边颜色
        // danmaku.underlineColor = Color.GREEN;
        danmaku.borderColor = DANMU_TEXT_BOARDCOLOR; //边框颜色，0表示无边框
        mDanmakuView.addDanmaku(danmaku);
    }



}
