package com.example.share;

import java.util.HashMap;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Toast;
import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.Platform.ShareParams;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.framework.utils.UIHandler;

public class MainActivity extends Activity  implements PlatformActionListener{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}


//	public void onClick(View v){
//		ShareSDK.initSDK(this);
//		Platform plat = ShareSDK.getPlatform("Wechat");
//		ShareParams sp = new ShareParams();
//		sp.setTitle("111");
//		sp.setText("1111");
//		sp.setShareType(Platform.SHARE_TEXT);
//		sp.setShareType(Platform.SHARE_IMAGE);
//		sp.setImageUrl("http://www.wyl.cc/wp-content/uploads/2014/02/10060381306b675f5c5.jpg");
//		plat.share(sp);
//	}
	
	public void onClick(View v){
		ShareSDK.initSDK(this);
		Platform plat = ShareSDK.getPlatform("WechatMoments");
		ShareParams sp = new ShareParams();
		sp.setTitle("111");
		sp.setText("1111");
		sp.setShareType(Platform.SHARE_TEXT);
		sp.setShareType(Platform.SHARE_IMAGE);
		sp.setImageUrl("http://www.wyl.cc/wp-content/uploads/2014/02/10060381306b675f5c5.jpg");
		plat.share(sp);
	}


	@Override
	public void onCancel(Platform plat, int action) {
		Message msg = new Message();
		msg.arg1 = 3;
		msg.arg2 = action;
		msg.obj = plat;
		handler.sendMessage(msg);
	}


	@Override
	public void onComplete(Platform plat, int action, HashMap<String, Object> arg2) {
		Message msg = new Message();
		msg.arg1 = 1;
		msg.arg2 = action;
		msg.obj = plat;
		handler.sendMessage(msg);
		
	}


	@Override
	public void onError(Platform plat, int action, Throwable t) {
		t.printStackTrace();

		Message msg = new Message();
		msg.arg1 = 2;
		msg.arg2 = action;
		msg.obj = t;
		handler.sendMessage(msg);
		
	}

	Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			String text = MainActivity.actionToString(msg.arg2);
			switch (msg.arg1) {
				case 1: {
					// 成功
					Platform plat = (Platform) msg.obj;
					text = plat.getName() + " completed at " + text;
				}
				break;
				case 2: {
					// 失败
					if ("WechatClientNotExistException".equals(msg.obj.getClass().getSimpleName())) {
						text = "111";
					}
					else if ("WechatTimelineNotSupportedException".equals(msg.obj.getClass().getSimpleName())) {
						text = "222";
					}
					else {
						text = "失败";
					}
				}
				break;
				case 3: {
					// 取消
					Platform plat = (Platform) msg.obj;
					text = plat.getName() + " canceled at " + text;
				}
				break;
			}

			Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show();
		}

	};
	
	
	
	/** 将action转换为String */
	public static String actionToString(int action) {
		switch (action) {
			case Platform.ACTION_AUTHORIZING: return "ACTION_AUTHORIZING";
			case Platform.ACTION_GETTING_FRIEND_LIST: return "ACTION_GETTING_FRIEND_LIST";
			case Platform.ACTION_FOLLOWING_USER: return "ACTION_FOLLOWING_USER";
			case Platform.ACTION_SENDING_DIRECT_MESSAGE: return "ACTION_SENDING_DIRECT_MESSAGE";
			case Platform.ACTION_TIMELINE: return "ACTION_TIMELINE";
			case Platform.ACTION_USER_INFOR: return "ACTION_USER_INFOR";
			case Platform.ACTION_SHARE: return "ACTION_SHARE";
			default: {
				return "UNKNOWN";
			}
		}
	}


}
