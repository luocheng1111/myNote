/** Automatically generated file. DO NOT MODIFY */
package com.example.share;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}