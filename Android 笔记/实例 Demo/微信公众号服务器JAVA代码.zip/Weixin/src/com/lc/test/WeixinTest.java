package com.lc.test;

import net.sf.json.JSONObject;

import com.lc.bean.AccessToken;

public class WeixinTest {

	public static void main(String[] args) {
		try {
			AccessToken accessToken = WeixinUtil.getAccessToken();
			String token = accessToken.getToken();
			System.out.println("Ʊ�ݣ�"+token);
			System.out.println("��Чʱ�䣺"+accessToken.getExpiresIn());
			
			//�����˵�
			createMenu(token);
			
			//��ѯ�˵�
//			queryMenu(token);
			
			//ɾ���˵�
//			deleteMenu(token);
			
			//��ȡ�û��б�
//			getUserList(token);
			
			//��ȡĳ�û���Ϣ
//			getUserInfo(token, "ohRjDuEogEvmmi1QlGcTS4xJ5-r8");
			
			//�ϴ�ͼƬ�ز�
//			uploadImage(token);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * �����˵�
	 * @param token
	 */
	public static void createMenu(String token){
		String menu = JSONObject.fromObject(WeixinUtil.initMenu()).toString();
		System.out.println(menu);
		int result = WeixinUtil.createMenu(token, menu);
		if(result == 0){
			System.out.println("�˵������ɹ�");
		}else{
			System.out.println("�����룺"+result);
		}
	}
	
	/**
	 * ��ѯ�˵�
	 * @param token
	 */
	private static void queryMenu(String token) {
		JSONObject jb = WeixinUtil.queryMenu(token);
		System.out.println(jb.toString());
	}
	
	/**
	 * ɾ���˵�
	 * @param token
	 */
	private static void deleteMenu(String token) {
		int result = WeixinUtil.deleteMenu(token);
		if(result == 0){
			System.out.println("�˵�ɾ���ɹ�");
		}else{
			System.out.println("�����룺"+result);
		}
	}

	
	/**
	 * ��ȡ�û��б�
	 * @param token
	 */
	private static void getUserList(String token) {
		JSONObject jb = WeixinUtil.getUserList(token);
		System.out.println(jb.toString());
	}
	
	/**
	 * ��ȡĳ�û���Ϣ
	 * @param token
	 */
	private static void getUserInfo(String token, String openid) {
		JSONObject jb = WeixinUtil.getUserInfo(token, openid);
		System.out.println(jb.toString());
	}
	
	/**
	 * �ϴ�ͼƬ
	 * @param token
	 */
	public static void uploadImage(String token){
		try {
			String path = "D:/imooc.jpg";
			String mediaId = WeixinUtil.upload(path, token, "image");
			System.out.println("mediaId:"+mediaId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
}
