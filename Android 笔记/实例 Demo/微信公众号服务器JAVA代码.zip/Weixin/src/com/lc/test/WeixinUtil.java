package com.lc.test;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import net.sf.json.JSONObject;

import com.lc.bean.AccessToken;
import com.lc.menu.Button;
import com.lc.menu.ClickButton;
import com.lc.menu.Menu;
import com.lc.menu.ViewButton;
import com.lc.util.HttpUtil;
import com.lc.zzz.Config;

public class WeixinUtil {
	
	
	
	/**
	 * ��ȡ access_token
	 * @return
	 */
	public static AccessToken getAccessToken(){
		AccessToken token = new AccessToken();
		String url = Config.ACCESS_TOKEN_URL.replace("APPID", Config.APPID).replace("APPSECRET", Config.APPSECRET);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		if(jsonObject != null){
			token.setToken(jsonObject.getString("access_token"));
			token.setExpiresIn(jsonObject.getInt("expires_in"));
		}
		return token;
		
	}
	
	/**
	 * ��ȡ��ҳ��Ȩaccess_token (��ҳ��Ȩ��ȡ�û�������Ϣ)
	 * @return
	 */
	public static String getWebAccessToken(String code){
		String url = Config.WEB_ACCESS_TOKEN_URL.replace("APPID", Config.APPID).replace("SECRET", Config.APPSECRET)
				.replace("CODE", code);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		System.out.println("access_token_json-->"+jsonObject.toString());
		return jsonObject.toString();
	}
	
	/**
	 * ��ȡ��ҳ��Ȩaccess_token (��ҳ��Ȩ��ȡ�û�������Ϣ)
	 * @return
	 */
	public static String getWebAccessToken1(String code){
		String url = Config.WEB_ACCESS_TOKEN_URL.replace("APPID", Config.APPID).replace("SECRET", Config.APPSECRET)
				.replace("CODE", code);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		String access_token = jsonObject.getString("access_token");
		return access_token;
	}
	
	/**
	 * ��ȡ��ҳ��Ȩaccess_token (��ҳ��Ȩ��ȡ�û�������Ϣ)
	 * @return
	 */
	public static String getWebAccessToken2(String code){
		String url = Config.WEB_ACCESS_TOKEN_URL.replace("APPID", Config.APPID).replace("SECRET", Config.APPSECRET)
				.replace("CODE", code);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		String openid = jsonObject.getString("openid");
		return openid;
	}
	
	/**
	 * ��ȡ�û�������Ϣ (��ҳ��Ȩ��ȡ�û�������Ϣ)
	 * @return
	 */
	public static String getUserInfoByWebAccessToken(String access_token_json){
		JSONObject jsonObject = JSONObject.fromObject(access_token_json);
		String access_token = jsonObject.getString("access_token");
		String openid = jsonObject.getString("openid");
		
		String url = Config.GET_WEBUSERINFO_URL.replace("ACCESS_TOKEN", access_token).replace("OPENID", openid);
		return HttpUtil.doGetStr(url).toString();
	}
	
	/**
	 * ��װ�˵�
	 * @return
	 */
	public static Menu initMenu(){
		
		ClickButton btn10 = new ClickButton();
		btn10.setName("click�˵�");
		btn10.setType("click");
		btn10.setKey("11");
		
		ViewButton btn20 = new ViewButton();
		btn20.setName("view�˵�");
		btn20.setType("view");
//		String url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+Config.APPID+"&redirect_uri="+Config.serverIP+"/Weixin/web/oauth2.php&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
		String url = Config.GET_USERINFO_WEB_URL.replace("APPID", Config.APPID).replace("REDIRECT_URI", Config.USERINFOURL);;
		btn20.setUrl(url);
		
		ClickButton btn31 = new ClickButton();
		btn31.setName("ɨ��1");
		btn31.setType("scancode_push");
		btn31.setKey("ɨ�����¼�");
		
		ClickButton btn32 = new ClickButton();
		btn32.setName("ɨ��2");
		btn32.setType("scancode_waitmsg");
		btn32.setKey("ɨ�����¼��ҵ�������Ϣ�����С���ʾ��");
		
		ClickButton btn33 = new ClickButton();
		btn33.setName("����λ��");
		btn33.setType("location_select");
		btn33.setKey("31");
		
		Button btn30 = new Button();
		btn30.setName("�˵�");
		btn30.setSub_button(new Button[]{btn31, btn32, btn33});
		
		Menu menu = new Menu();
		menu.setButton(new Button[]{btn10, btn20, btn30});
		
		return menu;
		
	}
	
	/**
	 * �����˵�
	 * @param token
	 * @param menu
	 * @return
	 */
	public static int createMenu(String token, String menu){
		int result = 0;
		String url = Config.CREATE_MENU_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = HttpUtil.doPostStr(url, menu);
		if(jsonObject != null){
			result = jsonObject.getInt("errcode");
		}
		
		return result;
	}
	
	/**
	 * ��ѯ�˵�
	 * @param token
	 * @return
	 */
	public static JSONObject queryMenu(String token){
		String url = Config.QUERY_MENU_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		return jsonObject;
	}
	
	/**
	 * ɾ���˵�
	 * @param token
	 * @return
	 */
	public static int deleteMenu(String token){
		int result = 0;
		String url = Config.DELETE_MENU_URL.replace("ACCESS_TOKEN", token);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		if(jsonObject != null){
			result = jsonObject.getInt("errcode");
		}
		return result;
	}
	
	/**
	 * ��ȡ�û��б�
	 * @param token
	 * @return
	 */
	public static JSONObject getUserList(String token){
		String url = Config.GET_USERLIST_URL.replace("ACCESS_TOKEN", token).replace("NEXT_OPENID", "");
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		return jsonObject;
	}
	
	/**
	 * ��ȡĳ�û���Ϣ
	 * @param token
	 * @return
	 */
	public static JSONObject getUserInfo(String token, String openid){
		String url = Config.GET_USERINFO_URL.replace("ACCESS_TOKEN", token).replace("OPENID", openid);
		JSONObject jsonObject = HttpUtil.doGetStr(url);
		return jsonObject;
	}
	
	
	/**
	 * �ļ��ϴ�
	 * @param filePath
	 * @param accessToken
	 * @param type
	 * @return
	 * @throws IOException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws KeyManagementException
	 */
	public static String upload(String filePath, String accessToken, String type) throws IOException, NoSuchAlgorithmException, NoSuchProviderException, KeyManagementException {
		File file = new File(filePath);
		if (!file.exists() || !file.isFile()) {
			throw new IOException("�ļ�������");
		}

		String url = Config.UPLOAD_URL.replace("ACCESS_TOKEN", accessToken).replace("TYPE",type);
		
		URL urlObj = new URL(url);
		//����
		HttpURLConnection con = (HttpURLConnection) urlObj.openConnection();

		con.setRequestMethod("POST"); 
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false); 

		//��������ͷ��Ϣ
		con.setRequestProperty("Connection", "Keep-Alive");
		con.setRequestProperty("Charset", "UTF-8");

		//���ñ߽�
		String BOUNDARY = "----------" + System.currentTimeMillis();
		con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);

		StringBuilder sb = new StringBuilder();
		sb.append("--");
		sb.append(BOUNDARY);
		sb.append("\r\n");
		sb.append("Content-Disposition: form-data;name=\"file\";filename=\"" + file.getName() + "\"\r\n");
		sb.append("Content-Type:application/octet-stream\r\n\r\n");

		byte[] head = sb.toString().getBytes("utf-8");

		//��������
		OutputStream out = new DataOutputStream(con.getOutputStream());
		//�����ͷ
		out.write(head);

		//�ļ����Ĳ���
		//���ļ������ļ��ķ�ʽ ���뵽url��
		DataInputStream in = new DataInputStream(new FileInputStream(file));
		int bytes = 0;
		byte[] bufferOut = new byte[1024];
		while ((bytes = in.read(bufferOut)) != -1) {
			out.write(bufferOut, 0, bytes);
		}
		in.close();

		//��β����
		byte[] foot = ("\r\n--" + BOUNDARY + "--\r\n").getBytes("utf-8");//����������ݷָ���

		out.write(foot);

		out.flush();
		out.close();

		StringBuffer buffer = new StringBuffer();
		BufferedReader reader = null;
		String result = null;
		try {
			//����BufferedReader����������ȡURL����Ӧ
			reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				buffer.append(line);
			}
			if (result == null) {
				result = buffer.toString();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				reader.close();
			}
		}

		JSONObject jsonObj = JSONObject.fromObject(result);
		System.out.println(jsonObj);
		String typeName = "media_id";
		if(!"image".equals(type)){
			typeName = type + "_media_id";
		}
		String mediaId = jsonObj.getString(typeName);
		return mediaId;
	}
	
	
}
