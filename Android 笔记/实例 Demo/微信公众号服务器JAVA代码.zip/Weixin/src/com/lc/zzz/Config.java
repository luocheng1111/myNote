package com.lc.zzz;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.lc.bean.Image;
import com.lc.bean.ImageMessage;
import com.lc.bean.Music;
import com.lc.bean.MusicMessage;
import com.lc.bean.News;
import com.lc.bean.NewsMessage;
import com.lc.bean.TextMessage;
import com.lc.util.MessageUtil;

public class Config {

//	 String url = "http://210.5.155.249:83/LoginM/index?openid="+openid+"&nickname="+nickname+"&sex="+sex+"&city="+city+"&country="+country+"&province="+country;
	
	public static String token = "luoc";
	public static String serverIP = "http://bf0b81da.ngrok.io";
	
	public static String LUOCHENGURL = serverIP+"/Weixin/web/luoc.html";
	public static String USERINFOURL = serverIP+"/Weixin/web/userInfo.jsp";
	public static String TOLOGINURL = serverIP+"/Weixin/web/login.jsp";
	public static String LOGINURL = "http://210.5.155.249:83/LoginM/index";
  	
	public static final String APPID = "wxfcfedda0d424da0e";
	public static final String APPSECRET = "d4624c36b6795d1d99dcf0547af5443d";
	
	public static String MediaId = "AvurStrRhNkbfxUyYIlYYSIAIZwHTwjpsALoLX7M4s5iFFAQ-OEY9tH5CzXNp195";
	public static String ThumbMediaId = "AvurStrRhNkbfxUyYIlYYSIAIZwHTwjpsALoLX7M4s5iFFAQ-OEY9tH5CzXNp195";
	
	public static final String ACCESS_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
	public static final String UPLOAD_URL = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token=ACCESS_TOKEN&type=TYPE";
	public static final String CREATE_MENU_URL = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN";
	public static final String QUERY_MENU_URL = "https://api.weixin.qq.com/cgi-bin/menu/get?access_token=ACCESS_TOKEN";
	public static final String DELETE_MENU_URL = "https://api.weixin.qq.com/cgi-bin/menu/delete?access_token=ACCESS_TOKEN";
	public static final String GET_USERLIST_URL = "https://api.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&next_openid=NEXT_OPENID";
	public static final String GET_USERINFO_URL = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";
	public static final String GET_USERINFO_WEB_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=APPID&redirect_uri=REDIRECT_URI&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
	public static final String WEB_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
	public static final String GET_WEBUSERINFO_URL = "https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";
	
	/**
	 * ��עʱ���ص���Ϣ
	 * @return
	 */
	public static String welcomText(){
		StringBuffer sb = new StringBuffer();
		sb.append("��ӭ���Ĺ�ע���밴�ղ˵���ʾ���в�����\n\n");
		sb.append("1.�γ̽���\n");
		sb.append("2.Ľ��������\n\n");
		sb.append("�ظ��������˲˵���");
		return sb.toString();
	}
	
	/**
	 * �û���1ʱ���ظ�����Ϣ
	 * @return
	 */
	public static String text1(){
		StringBuffer sb = new StringBuffer();
		sb.append("���׿γ�....");
		return sb.toString();
	}
	
	/**
	 * �ı���Ϣ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initText(String toUserName, String fromUserName, String content){
		TextMessage textMessage = new TextMessage();
		textMessage.setFromUserName(toUserName);
		textMessage.setToUserName(fromUserName);
		textMessage.setMsgType(MessageUtil.MESSAGE_TEXT);
		textMessage.setCreateTime(new Date().getTime());
		textMessage.setContent(content);
		return MessageUtil.textMessageToXml(textMessage);
	}
	
	
	/**
	 * ͼ����Ϣ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initNewsMessage(String toUserName, String fromUserName){
		String message = null;
		List<News> newsList = new ArrayList<News>();
		
		News news = new News();
		news.setTitle("Ľ��������");
		news.setDescription("Ľ����(IMOOC)�ǹ�������IT����ѧϰƽ̨��Ľ�����ṩ�˷ḻ���ƶ��˿�����" +
				"php������webǰ�ˡ�android�����Լ�html5����Ƶ�̳���Դ�����Ρ����Ҹ��н����Լ�Ȥζ��...");
		news.setPicUrl(serverIP+"/Weixin/image/imooc.jpg");
		news.setUrl("https://mp.weixin.qq.com");
		newsList.add(news);
		
		NewsMessage newsMessage = new  NewsMessage();
		newsMessage.setToUserName(fromUserName);
		newsMessage.setFromUserName(toUserName);
		newsMessage.setCreateTime(new Date().getTime());
		newsMessage.setMsgType(MessageUtil.MESSAGE_NEWS);
		newsMessage.setArticles(newsList);
		newsMessage.setArticleCount(newsList.size());
		
		message = MessageUtil.newsMessageToXml(newsMessage);
		
		return message;
	}
	
	/**
	 * ��װͼƬ��Ϣ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initImageMessage(String toUserName, String fromUserName){
		String message = null;
		Image image = new Image();
		image.setMediaId(MediaId);
		
		ImageMessage imageMessage = new ImageMessage();
		imageMessage.setFromUserName(toUserName);
		imageMessage.setToUserName(fromUserName);
		imageMessage.setMsgType(MessageUtil.MESSAGE_IMAGE);
		imageMessage.setCreateTime(new Date().getTime());
		imageMessage.setImage(image);
		
		message = MessageUtil.imageMessageToXml(imageMessage);
		
		return message;
	}
	
	/**
	 * ��װ������Ϣ
	 * @param toUserName
	 * @param fromUserName
	 * @return
	 */
	public static String initMusicMessage(String toUserName, String fromUserName){
		String message = null;
		Music music = new Music();
		music.setThumbMediaId("WsHCQr1ftJQwmGUGhCP8gZ13a77XVg5Ah_uHPHVEAQuRE5FEjn-DsZJzFZqZFeFk");
		music.setTitle("see you again");
		music.setDescription("��7Ƭβ��");
		music.setMusicUrl("http://zapper.tunnel.mobi/Weixin/resource/See You Again.mp3");
		music.setHQMusicUrl("http://zapper.tunnel.mobi/Weixin/resource/See You Again.mp3");
		
		MusicMessage musicMessage = new MusicMessage();
		musicMessage.setFromUserName(toUserName);
		musicMessage.setToUserName(fromUserName);
		musicMessage.setMsgType(MessageUtil.MESSAGE_MUSIC);
		musicMessage.setCreateTime(new Date().getTime());
		musicMessage.setMusic(music);
		message = MessageUtil.musicMessageToXml(musicMessage);
		return message;
	}
}
