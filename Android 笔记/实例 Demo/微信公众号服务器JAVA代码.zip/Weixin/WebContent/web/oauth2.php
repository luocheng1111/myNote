<?php
if (isset($_GET['code'])){
    echo $_GET['code']+"asdasd";
}else{
    echo "NO CODE";
}
?>