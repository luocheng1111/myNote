package com.example.applemac.okhttp_demo.okhttp.model;

/**
 * User: hqs
 * Date: 2016/3/18
 * Time: 13:16
 */
public class Response {

    private int code;
    private String msg;
    private String data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
