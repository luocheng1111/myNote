package com.example.applemac.okhttp_demo.okhttp.downloadbigfile;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.util.Log;


import com.example.applemac.okhttp_demo.okhttp.downloadbigfile.DownloadListener;
import com.example.applemac.okhttp_demo.okhttp.downloadbigfile.DownloadResponseBody;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * 作者：Luocheng
 * 功能：实现断点续传下载的功能 适用于下载大文件 APK >20M
 *
 *

  使用示例
   DownloadBigFileUtil  DownloadBigFileUtil =  new DownloadBigFileUtil(MainActivity.this);
   DownloadBigFileUtil.downloadBigFile(url, new DownloadBigFileUtil.OnProgressListener() {
        @Override
        public void onProgress(float progress, long fileSoFar, long fileTotleSize) {
            Log.i("wangshu", progress+","+fileSoFar+","+fileTotleSize);
            //更新频率太快，建议用Handler处理
            mHandler.sendEmptyMessage(200);
        }
    });
    });

 */
public class DownloadBigFileUtil {

    Context context;
    String downloadUrl;
    String apkName;
    long downloadLength;
    Call mCall;
    DownloadListener downloadListener;
    long fileMaxLength;
//    private OnProgressListener onProgressListener;


    public DownloadBigFileUtil(Context context) {
        this.context = context;
    }


    public void downloadBigFile(String url, final OnProgressListener onProgressListener){
        this.downloadUrl = url;
        apkName = url.substring(url.lastIndexOf("/")+1);
//        Log.e("DownloadBigFileUtil", "Apk名字："+apkName);

        //先移除老的APK
        removeOldApk(apkName);

        //下载监听
        downloadListener = new DownloadListener() {
            @Override
            public void start(long max) {
                Log.e("DownloadBigFileUtil", "开始下载监听 :"+max);
            }

            @Override
            public void loading(int dowanloadTotle) {
//                Log.e("DownloadBigFileUtil", "progress:"+progress);
//                Log.e("DownloadBigFileUtil", "下载进度 progress:"+progress);
//                Log.e("111", ((float)26321285/(float)112432178)*100+"");
                float progress = Float.valueOf(format1(((float)dowanloadTotle/(float)fileMaxLength)*100));
                onProgressListener.onProgress(progress, dowanloadTotle, fileMaxLength);
//                tv.setText("progress:"+progress+"/"+fileMaxLength);
            }

            // 说明文件已经下载完，直接跳转安装就好
            @Override
            public void complete(String path) {
                Log.e("DownloadBigFileUtil","下载完成 path:"+path);
                installApk(path);
                if(!mCall.isCanceled()){
                    mCall.cancel();
                }
                context = null;
            }

            @Override
            public void fail(int code, String message) {
                Log.e("DownloadBigFileUtil","失败 message:"+message);
            }

            @Override
            public void loadfail(String message) {
                Log.e("DownloadBigFileUtil","下载失败 message:"+message);
            }
        };

        //开始下载APK
        download();
    }

    public String format1(float value) {
        return String.format("%.1f", value).toString();
    }

    public String format2(float value) {
        return String.format("%.2f", value).toString();
    }


    private void download(){
        Log.e("DownloadBigFileUtil", "下载开始");
        final long startsPoint = getFileStart() > 0 ? getFileStart()-1 : getFileStart();
        Log.e("DownloadBigFileUtil","开始下载的位置->"+startsPoint);
        downloadLength = startsPoint;

        mCall = download(downloadUrl, downloadListener,  startsPoint, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("DownloadBigFileUtil","onFailure->"+e.getMessage());
                downloadListener.loadfail(e.getMessage());
                mCall.cancel();
                download();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                long length = response.body().contentLength();
                Log.e("DownloadBigFileUtil","本次下载文件长度："+length);
                if(fileMaxLength==0){
                    fileMaxLength = length;
                }
                Log.e("DownloadBigFileUtil","文件总长度->"+fileMaxLength);
                if (length == 0){
                    // 说明文件已经下载完，直接跳转安装就好
                    downloadListener.complete(String.valueOf(getApkFile(apkName).getAbsoluteFile()));
                    return;
                }
                downloadListener.start(length+startsPoint);
                // 保存文件到本地
                InputStream is = null;
                RandomAccessFile randomAccessFile = null;
                BufferedInputStream bis = null;

                byte[] buff = new byte[2048];
                int len = 0;
                try {
                    is = response.body().byteStream();
                    bis  =new BufferedInputStream(is);

                    File file = getApkFile(apkName);
                    // 随机访问文件，可以指定断点续传的起始位置
                    randomAccessFile =  new RandomAccessFile(file, "rwd");
                    randomAccessFile.seek (startsPoint);
                    while ((len = bis.read(buff)) != -1) {
                        randomAccessFile.write(buff, 0, len);
                        downloadLength += len;
//                        downloadListener.loading((int)downloadLength);
                    }
                    // 下载完成
                    downloadListener.complete(String.valueOf(file.getAbsoluteFile()));
                } catch (Exception e) {
//                    e.printStackTrace();
                    Log.e("DownloadBigFileUtil", "下载异常: "+e.getMessage());
                    downloadListener.loadfail(e.getMessage());
                    mCall.cancel();

                    download();
                } finally {
                    try {
                        if (is != null) {
                            is.close();
                        }
                        if (bis != null){
                            bis.close();
                        }
                        if (randomAccessFile != null) {
                            randomAccessFile.close();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            }

        });
    }



    private Call download(String url, final DownloadListener downloadListener, final long startsPoint, Callback callback){
        Request request = new Request.Builder()
                .url(url)
                .header("RANGE", "bytes=" + startsPoint + "-")//断点续传
                .build();

        // 重写ResponseBody监听请求
        Interceptor interceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Response originalResponse = chain.proceed(chain.request());
                return originalResponse.newBuilder()
                        .body(new DownloadResponseBody(originalResponse, startsPoint, downloadListener))
                        .build();
            }
        };

        OkHttpClient.Builder dlOkhttp = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)//设置连接超时时间
                .readTimeout(10, TimeUnit.SECONDS)//设置读取超时时间
                .addNetworkInterceptor(interceptor);
        // 绕开证书
        try {
            setSSL(dlOkhttp);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 发起请求
        Call call = dlOkhttp.build().newCall(request);
        call.enqueue(callback);
        return call;
    }

    private void setSSL(OkHttpClient.Builder dlOkhttp){
        X509TrustManager trustManager = new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {

            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {

            }

            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };

        SSLSocketFactory sslSocketFactory;
        try {
            SSLContext sslContext;
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null,new X509TrustManager[]{trustManager},null);
            sslSocketFactory = sslContext.getSocketFactory();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }


        HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        dlOkhttp.sslSocketFactory(sslSocketFactory, trustManager);

    }


    private File getApkFile(String apkName) {
        String root = Environment.getExternalStorageDirectory().getPath();
        File file = new File(root,apkName);
        return file;
    }


    private long getFileStart(){
        String root = Environment.getExternalStorageDirectory().getPath();
        File file = new File(root,apkName);
        if(file==null){
            return 0;
        }
        return file.length();
    }


    private void removeOldApk(String apkName){
        File file = getApkFile(apkName);
        if(file!=null){
            file.delete();
        }
    }

    private void installApk(String path) {
        File file = new File(path);
        Intent intent =new Intent(Intent.ACTION_VIEW);
        //判断是否是AndroidN以及更高的版本
        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.N) {
            Uri contentUri = FileProvider.getUriForFile(context,context.getPackageName()+".fileprovider",file);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(contentUri,"application/vnd.android.package-archive");
        }else{
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setDataAndType(Uri.fromFile(file),"application/vnd.android.package-archive");
        }
        context.startActivity(intent);
    }


    public interface OnProgressListener {
        /**
         * 下载进度
         * @param progress 比例
         * @param fileSoFar 已下载大小
         * @param fileTotleSize 总大小
         */
        void onProgress(float progress,long fileSoFar, long fileTotleSize);

    }
//
//    /**
//     * 对外开发的方法
//     *
//     * @param onProgressListener
//     */
//    public void setOnProgressListener(OnProgressListener onProgressListener) {
//        this.onProgressListener = onProgressListener;
//    }

}
