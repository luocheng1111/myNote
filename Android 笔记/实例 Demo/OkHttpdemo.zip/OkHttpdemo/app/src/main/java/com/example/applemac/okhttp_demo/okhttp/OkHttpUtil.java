package com.example.applemac.okhttp_demo.okhttp;


import android.util.Log;

import com.example.applemac.okhttp_demo.okhttp.callback.DownloadCallback;
import com.example.applemac.okhttp_demo.okhttp.callback.ProgressCallback;
import com.example.applemac.okhttp_demo.okhttp.callback.UploadFileCallback;
import com.example.applemac.okhttp_demo.okhttp.progress.ProgressRequestBody;
import com.example.applemac.okhttp_demo.okhttp.progress.ProgressResponseBody;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by appleMac on 2019/3/26.
 */

public class OkHttpUtil {

    private static OkHttpClient mOkHttpClient = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build();

    public static OkHttpClient getOkHttpClient() {
        return mOkHttpClient;
    }

    //Get请求
    public static void doGet(String url, Callback callback){
        Request request = new Request.Builder().url(url).get().build();
        doGet(request, callback, true);
    }

    /**
     使用的例子:
      RequestParam requestParam = new RequestParam("http://www.baidu.com");
      requestParam.put("username", "zhangsan");
      requestParam.addHeader("111","111");
      OkHttpUtil.doGet(requestParam, new StringCallback() {
        ...
      });
     */
    //Get请求 此方法可以添加头部 可使用键值对当参数
    public static void doGet(RequestParam param, Callback callback){
        Request.Builder builder = new Request.Builder();
        builder.url(param.getFullUrl());
        if (param.getHeaders() != null)
            builder.headers(param.getHeaders());
        Request request = builder.get().build();

        doGet(request, callback, true);
    }

    /**
      使用的例子:
      RequestParam requestParam = new RequestParam("http://www.baidu.com");
      requestParam.put("username", "zhangsan");
      requestParam.addHeader("111","111");
      OkHttpUtil.doPost(requestParam, new StringCallback() {
         ...
      });
     */
    //Post请求
    public static void doPost(RequestParam param, Callback callback){
        RequestBody requestBody = BuildUtil.postRequestBody(param);
        doPost(param.getUrl(), param.getHeaders(), requestBody, callback, true);
    }

    //Post Json请求
    public static void doJsonPost(String url , String json, Callback callback){
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json);
        doPost(url, null, requestBody, callback, true);
    }

    //下载文件 path为全名 eg:/storage/emulated/0/AAA/ccc.png
    public static void doDownlond(String url, DownloadCallback downloadCallback){
        Request request = new Request.Builder().url(url).addHeader("Connection","close").get().build();
        doGet(request, downloadCallback, true);
    }

    /**
     上传文件的例子:
     RequestParam params = new RequestParam(url);
     params.put("token", BaseSocket.getInstance().getToken());
     params.put("albumtype", typePhoto);//1：随拍  2：私照
     for (int i = 0; i < filesList.size(); i++) {
       params.put("picture" + i, files(i)); //添加文件
     }
     OkHttpUtil.doUploadFile(params, new UploadFileCallback<PhotoUploadSuccess>() {
       ...
     }
     */
    //上传文件
    public static void doUploadFile(RequestParam param, UploadFileCallback uploadFileCallback){
        RequestBody requestBody = BuildUtil.postRequestBody(param);
        doPost(param.getUrl(), param.getHeaders(), requestBody, uploadFileCallback, true);
    }


    //所有的GET请求最终都会走到这里,enqueue代表是否异步
    private static void doGet(Request request, Callback callback, boolean enqueue) {
        OkHttpClient okHttpClient;
        if (callback instanceof ProgressCallback) {
            okHttpClient = clone((ProgressCallback) callback);
        } else {
            okHttpClient = mOkHttpClient;
        }

        if (enqueue) {
            enqueue(okHttpClient, request, callback);
        } else {
            execute(okHttpClient, request, callback);
        }
    }



    //所有的Post请求最终都会走到这里,enqueue代表是否异步
    private static void doPost(String url, Headers headers, RequestBody requestBody, Callback callback, boolean enqueue) {
        Log.e("111",url);
        if(callback instanceof ProgressCallback) {
            Log.e("111","111");
            requestBody = new ProgressRequestBody((RequestBody)requestBody, (ProgressCallback)callback);
        }

        Request.Builder builder = new Request.Builder();
        builder.url(url);
        if(headers != null) {
            builder.headers(headers);
        }
        if(requestBody != null) {
            builder.post((RequestBody)requestBody);
        }
        Request request = builder.build();

        if(enqueue) {
            enqueue(mOkHttpClient, request, callback);
        } else {
            execute(mOkHttpClient, request, callback);
        }

    }


    //克隆一个OkHttpClient,用于监听下载进度
    private static OkHttpClient clone(final ProgressCallback progressCallback) {
        return mOkHttpClient.newBuilder().addNetworkInterceptor(new Interceptor() {
            public Response intercept(Chain chain) throws IOException {
                Response originalResponse = chain.proceed(chain.request());
                return originalResponse.newBuilder().body(new ProgressResponseBody(originalResponse.body(), progressCallback)).build();
            }
        }).build();
    }


    //异步执行请求
    private static void enqueue(OkHttpClient okHttpClient, Request request, Callback callback) {
        okHttpClient.newCall(request).enqueue(callback);
    }

    //同步执行请求
    private static void execute(OkHttpClient okHttpClient, Request request, Callback callback) {
        Call call = okHttpClient.newCall(request);
        try {
            Response response = call.execute();
            callback.onResponse(call, response);
        } catch (IOException e) {
            callback.onFailure(call, e);
        }
    }

}

