package com.example.applemac.okhttp_demo.okhttp.callback;



import com.example.applemac.okhttp_demo.IOUtil;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.ResponseBody;

/**
 * 文件下载回调类
 * User: ljx
 * Date: 2017/12/1
 * Time: 20:04
 */
public abstract class DownloadCallback extends FailureCallback implements ProgressCallback {

    private final boolean callbackInUIThread;//回调是否在主线程

    private final String localFilePath;

    public DownloadCallback(String localFilePath) {
        this(localFilePath, true);
    }

    public DownloadCallback(String localFilePath, boolean callbackInUIThread) {
        this.localFilePath = localFilePath;
        this.callbackInUIThread = callbackInUIThread;
    }

    @Override
    public final void onResponse(Call call, okhttp3.Response response) {
        try {
            if (!response.isSuccessful())
                throw new IOException(String.valueOf(response.code()));
            ResponseBody body = response.body();
            if (body == null)
                throw new IOException("download empty");
            boolean isSuccess = IOUtil.write(body.byteStream(), localFilePath);
            if (!isSuccess)
                throw new IOException("download failure");
            if (!callbackInUIThread) {
                onResponse(true, localFilePath);
                return;
            }
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    onResponse(true, localFilePath);
                }
            });
        } catch (IOException e) {
            onFailure(call, e);
        }
    }

    @Override
    public void onFailure(String error) {
        onResponse(false, localFilePath);
    }

    public abstract void onResponse(boolean success, String filePath);

    @Override
    public void onProgress(int progress, long currentSize, long totalSize) {
    }
}
