package com.example.applemac.okhttp_demo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.applemac.okhttp_demo.R;
import com.example.applemac.okhttp_demo.okhttp.OkHttpUtil;
import com.example.applemac.okhttp_demo.okhttp.RequestParam;
import com.example.applemac.okhttp_demo.okhttp.callback.DownloadCallback;
import com.example.applemac.okhttp_demo.okhttp.callback.StringCallback;
import com.example.applemac.okhttp_demo.okhttp.downloadbigfile.DownloadBigFileUtil;
import com.example.applemac.okhttp_demo.okhttp.downloadbigfile.DownloadListener;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MainActivity extends AppCompatActivity {

    TextView tv;
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView) findViewById(R.id.tv);
        iv = (ImageView) findViewById(R.id.iv);

        Log.e("111", ((float)26321285/(float)112432178)+"");
        Log.e("111", ((float)26321285/(float)112432178)*100+"");
        Log.e("111", format1(((float)26321285/(float)112432178)*100)+"");

    }
    public String format1(float value) {
        return String.format("%.1f", value).toString();
    }

    public String format2(float value) {
        return String.format("%.2f", value).toString();
    }


    //Get请求
    public void doGet(View v) {
        tv.setText("");
        iv.setImageBitmap(null);
//        //1.创建okHttpClient对象
//        OkHttpClient mOkHttpClient = new OkHttpClient();
//
//        //2.构建Request
//        Request request = new Request.Builder()
//                .url("https://www.baidu.com/")
//                .build();
//
//        //3.将Request封装为Call
//        mOkHttpClient.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                final String res = response.body().string();
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        tv.setText(res);
//                    }
//                });
//            }
//        });

        OkHttpUtil.doGet("https://www.baidu.com/", new StringCallback() {
            @Override
            public void onSuccess(String result) {
                tv.setText(result);
            }
        });
    }

    //Post方式请求 提交键值对格式的数据
    public void doPost(View v) {
        Log.e("111", "doPost: ");
        tv.setText("");
        iv.setImageBitmap(null);


        RequestParam requestParam = new RequestParam("http://www.baidu.com");
        requestParam.put("username", "zhangsan");
        requestParam.addHeader("111","111");
        OkHttpUtil.doPost(requestParam, new StringCallback() {
            @Override
            public void onSuccess(String result) {
                Log.e("111", result);
                tv.setText(result);
            }
        });
    }

    //Post方式请求 提交Json格式的数据
    public void doPostString(View v) {
        tv.setText("");
        iv.setImageBitmap(null);

        //1.创建okHttpClient对象
        OkHttpClient okHttpClient = new OkHttpClient();

        String url = "http://10.1.1.59:8080/tthparking/webresources/task/requestforanswer";
        MediaType JsonMediaType = MediaType.parse("application/json; charset=utf-8");
        String jsonString = "{\"userCd\":\"15103743308\"}";

        //2.构建RequestBody 往Body中添加数据
        RequestBody requestBody = RequestBody.create(JsonMediaType, jsonString);

        //3.构建Request
        Request request = new Request.Builder().url(url).post(requestBody).addHeader("Content-Type", "application/json").build();

        //4.将Request封装为Call
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String str = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tv.setText(str);
                    }
                });
            }
        });
    }

    //Post方式请求 提交流格式的数据 提交单个文件
    public void doPostFile(View v) {
        tv.setText("");
        iv.setImageBitmap(null);
        //1.创建okHttpClient对象
        OkHttpClient okHttpClient = new OkHttpClient();

        File file = new File(Environment.getExternalStorageDirectory() + "test.txt");
        MediaType MEDIATYPE = MediaType.parse("text/plain; charset=utf-8");
        //2.构建RequestBody 往Body中添加数据
        RequestBody requestBody = RequestBody.create(MEDIATYPE, file);

        //3.构建Request
        Request request = new Request.Builder().url("http://www.baidu.com")
                .post(requestBody)
                .build();

        //4.将Request封装为Call
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String str = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tv.setText(str);
                    }
                });
            }
        });


    }

    //上传表单数据 有时上传文件同时还需要传其他类型的字段
    public void doUploadMultipart(View v) {
        tv.setText("");
        iv.setImageBitmap(null);
//        //1.创建okHttpClient对象
//        OkHttpClient mOkHttpClient = new OkHttpClient();
//
//        //2.构建RequestBody 往Body中添加表单数据
//        RequestBody requestBody = new MultipartBody.Builder()
//                .setType(MultipartBody.FORM)
//                .addFormDataPart("title", "wangshu")
//                .addFormDataPart("image", "wangshu.jpg", RequestBody.create(MediaType.parse("image/png"), new File("/sdcard/wangshu.jpg")))
//                .build();
//
//        //3.构建Request
//        Request request = new Request.Builder()
//                .header("Authorization", "Client-ID " + "...")
//                .url("https://api.imgur.com/3/image")
//                .post(requestBody)
//                .build();
//
//        //4.将Request封装为Call
//        mOkHttpClient.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                Log.i("wangshu", response.body().string());
//            }
//        });

        String url = "http://dev.static.goddess021.com/official.apk";

        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+ File.separator +"AAA"+File.separator+"bbb.apk";
        Log.i("wangshu", path);
//        OkHttpUtil.doDownlond(url, new DownloadCallback(path) {
//            @Override
//            public void onResponse(boolean success, String filePath) {
//                Log.i("wangshu", success+","+filePath);
//                if (success) {
//
//                } else {
////                    Log.i("wangshu", response.body().string());
//                }
//            }
//
//            @Override
//            public void onProgress(int progress, long currentSize, long totalSize) {
//                super.onProgress(progress, currentSize, totalSize);
//                Log.e("wangshu", progress+","+currentSize+","+totalSize);
//            }
//        });

        DownloadBigFileUtil  DownloadBigFileUtil =  new DownloadBigFileUtil(MainActivity.this);
        DownloadBigFileUtil.downloadBigFile(url, new DownloadBigFileUtil.OnProgressListener() {
            @Override
            public void onProgress(float progress, long fileSoFar, long fileTotleSize) {
                Log.i("wangshu", progress+","+fileSoFar+","+fileTotleSize);
            }
        });
    }


    //下载文件 写法个Get请求一样
    public void doDownload(View v) {
        tv.setText("");
        iv.setImageBitmap(null);

//        String url = "https://upload-images.jianshu.io/upload_images/727790-f69f2927e6a9a9e2.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/700";

//        //1.创建okHttpClient对象
//        OkHttpClient mOkHttpClient = new OkHttpClient();
//
//
//
//        //2.构建Request
//        Request request = new Request.Builder().url(url).build();
//
//        //3.将Request封装为Call
//        mOkHttpClient.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) {
//                InputStream is = response.body().byteStream();
//                final Bitmap bitmap = BitmapFactory.decodeStream(is);
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        iv.setImageBitmap(bitmap);
//                    }
//                });
//            }
//        });

        String url = "https://downpack.baidu.com/appsearch_AndroidPhone_v8.0.3(1.0.65.172)_1012271b.apk";

        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+ File.separator +"AAA"+File.separator+"aaa.apk";
        Log.i("wangshu", path);
        OkHttpUtil.doDownlond(url, new DownloadCallback(path) {
            @Override
            public void onResponse(boolean success, String filePath) {
                Log.i("wangshu", success+","+filePath);
                if (success) {

                } else {
//                    Log.i("wangshu", response.body().string());
                }
            }

            @Override
            public void onProgress(int progress, long currentSize, long totalSize) {
                super.onProgress(progress, currentSize, totalSize);
                Log.e("wangshu", progress+","+currentSize+","+totalSize);
            }
        });





    }

}


