package com.example.applemac.okhttp_demo.okhttp.callback;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * User: ljx
 * Date: 2017/9/13
 * Time: 9:49
 */
public abstract class StringCallback extends FailureCallback {

    private final boolean callbackInUIThread;//回调是否在主线程

    public StringCallback() {
        this(true);
    }

    public StringCallback(boolean callbackInUIThread) {
        this.callbackInUIThread = callbackInUIThread;
    }

    @Override
    public void onResponse(Call call, Response response) {
        try {
//            if (!response.isSuccessful())
//                throw new IOException(String.valueOf(response.code()));
            ResponseBody body = response.body();
            if (body == null)
                throw new IOException("response empty");

            final String result = body.string();
            if (callbackInUIThread) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        onSuccess(result);
                    }
                });
            } else {
                onSuccess(result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            onFailure(call, e);
        }
    }

    @Override
    public void onFailure(String error) {

    }

    public abstract void onSuccess(String result);
}
