package com.example.applemac.okhttp_demo.okhttp.callback;

import android.text.TextUtils;

import com.example.applemac.okhttp_demo.GsonUtil;
import com.google.gson.reflect.TypeToken;
import okhttp3.ResponseBody;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;

import okhttp3.Call;
import com.example.applemac.okhttp_demo.okhttp.model.Response;

/**
 * User: ljx
 * Date: 2017/9/13
 * Time: 10:01
 */
public abstract class JsonCallback<T> extends FailureCallback {
    private Type type;

    private Response result;

    public JsonCallback() {
        type = getSuperclassTypeParameter(getClass());
    }

    @Override
    public void onResponse(Call call, okhttp3.Response response) {
        try {
            if (!response.isSuccessful())
                throw new IOException(String.valueOf(response.code()));

            ResponseBody body = response.body();
            if (body == null)
                throw new IOException("response empty");
            String content = body.string();
            if (content == null)
                throw new IOException("data is null");

            result = new Response();
            JSONObject json = new JSONObject(content);
            result.setCode(json.optInt("code"));
            result.setMsg(json.optString("msg"));
            result.setData(json.optString("data"));
            TypeToken<T> tTypeToken = (TypeToken<T>) TypeToken.get(type);
            Class<? super T> rawType = tTypeToken.getRawType();
            if (rawType == String.class) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        onSuccess(result.getCode(), (T) result.getData());
                    }
                });
                return;
            }
            int code = result.getCode();
            T t = null;
            if (!TextUtils.isEmpty(result.getData())) {
                t = parser(result.getData());
            }
            if (code == 100 && t == null) {
                throw new IOException("object is null");
            }
            final T tempT = t;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    onSuccess(result.getCode(), tempT);
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
            onFailure(call, e);
        } catch (JSONException e) {
            e.printStackTrace();
            onFailure(call, new IOException("data error"));
        }
    }


    @Override
    public void onFailure(String error) {

    }

    public String getTip() {
        return result == null ? "" : result.getMsg();
    }

    public abstract void onSuccess(int code, T t);

    //此方法在子线程执行
    public T parser(String data) {
        return GsonUtil.getObject(data, type);
    }
}
