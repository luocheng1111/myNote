package com.nanchen.rxjava2examples.model;

/**
 * Author: nanchen
 * Email: liushilin520@foxmail.com
 * Date: 2017-06-20  15:01
 */

public class OperatorModel {

    public String title;
    public String des;

    public OperatorModel(String title, String des) {
        this.title = title;
        this.des = des;
    }
}
