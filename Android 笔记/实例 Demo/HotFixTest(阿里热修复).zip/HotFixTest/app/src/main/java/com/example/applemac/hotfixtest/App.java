package com.example.applemac.hotfixtest;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.taobao.sophix.PatchStatus;
import com.taobao.sophix.SophixManager;
import com.taobao.sophix.listener.PatchLoadStatusListener;

/**
 * Created by appleMac on 2019/1/30.
 */

public class App extends Application {

//    public interface MsgDisplayListener {
//        void handle(String msg);
//    }
//
//    public static MsgDisplayListener msgDisplayListener = null;
//    public static StringBuilder cacheMsg = new StringBuilder();

    @Override
    public void onCreate() {
        super.onCreate();


    }

//    private void initHotfix() {
//        String appVersion;
//        try {
//            appVersion = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
//        } catch (Exception e) {
//            appVersion = "1.0.0";
//        }
//
//        SophixManager.getInstance().setContext(this)
//                .setAppVersion(appVersion)
//                .setAesKey(null)
//                //.setAesKey("0123456789123456")
//                .setEnableDebug(true)
//                .setPatchLoadStatusStub(new PatchLoadStatusListener() {
//                    @Override
//                    public void onLoad(final int mode, final int code, final String info, final int handlePatchVersion) {
//                        Log.e("App", "3333");
//                        String msg = new StringBuilder("").append("Mode:").append(mode)
//                                .append(" Code:").append(code)
//                                .append(" Info:").append(info)
//                                .append(" HandlePatchVersion:").append(handlePatchVersion).toString();
//                        if (msgDisplayListener != null) {
//                            msgDisplayListener.handle(msg);
//                        } else {
//                            cacheMsg.append("\n").append(msg);
//                        }
//                    }
//                }).initialize();
//    }
//

//    @Override
//    protected void attachBaseContext(Context base) {
//        super.attachBaseContext(base);
//
//        SophixManager.getInstance().setContext(this)
//                .setAppVersion("1.1.1")
//                .setEnableDebug(true)
//                .setPatchLoadStatusStub(new PatchLoadStatusListener() {
//                    @Override
//                    public void onLoad(final int mode, final int code, final String info, final int handlePatchVersion) {
//                        if (code == PatchStatus.CODE_LOAD_SUCCESS) {
//                            Log.e("App", "sophix load patch success!");
//                        } else if (code == PatchStatus.CODE_LOAD_RELAUNCH) {
//                            // 如果需要在后台重启，建议此处用SharePreference保存状态。
//                            Log.e("App", "sophix preload patch success. restart app to make effect.");
//                        }else {
//                            Log.e("App", "error!" + info);
//                        }
//                    }
//                }).initialize();
//    }
}
