package com.example.applemac.hotfixtest;

import android.os.Environment;


import java.io.File;


public class Constant {


    //热修复
    public static String HotfixAppKey = "25650074";
    public static String HotfixAppsecret = "620844fb56e1bdaa26313b8ae504efb9";
    public static String HotfixRsasecret = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCWtbaPkYEgiIKSBIEkGFqeWVKpsxBqvb073J0mx";


}
