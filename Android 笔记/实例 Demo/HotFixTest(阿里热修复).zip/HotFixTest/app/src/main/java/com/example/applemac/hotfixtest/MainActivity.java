package com.example.applemac.hotfixtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.taobao.sophix.SophixManager;

public class MainActivity extends AppCompatActivity {

    TextView tv;
//    private String mStatusStr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SophixManager.getInstance().queryAndLoadNewPatch();

        tv = findViewById(R.id.tv_);

        tv.setText("V-1");

//        Toast.makeText(MainActivity.this,"热修复成功", Toast.LENGTH_SHORT).show();

//        App.msgDisplayListener = new App.MsgDisplayListener() {
//            @Override
//            public void handle(final String msg) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        updateConsole(msg);
//                    }
//                });
//            }
//        };
    }
//
//    private void updateConsole(String content) {
//        mStatusStr += content + "\n";
//        if (tv != null) {
//            tv.setText(mStatusStr);
//        }
//    }
}
