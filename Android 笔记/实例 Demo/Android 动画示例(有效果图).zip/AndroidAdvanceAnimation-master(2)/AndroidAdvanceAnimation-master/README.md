# AndroidAdvanceAnimation
安卓高级动画，总结了到目前为止Android中所有的动画框架，代码实现，demo应用。

整合所有动画封装了通用动画库，并封装了三个自定义PathView。

为了解决矢量动画中“同形Path”生成困难的问题，尝试开发了一个桌面小工具PathController，辅助构建矢量路径。
